import 'package:flutter/material.dart';

// ── Palette Twitch-inspired ─────────────────────────────────────────────────
const kPurple      = Color(0xFF9146FF); // Primary purple
const kPurpleDark  = Color(0xFF772CE8); // Deep purple
const kPurpleDeep  = Color(0xFF0E0029); // Near-black purple (splash bg)
const kPurpleLight = Color(0xFFBF94FF); // Light purple accent
const kDarkBg      = Color(0xFF0E0E10); // Twitch dark
const kDarkCard    = Color(0xFF18181B); // Card dark
const kDarkSurf    = Color(0xFF1F1F23); // Surface dark
const kTextWhite   = Color(0xFFEFEFF1); // Twitch white
const kTextMuted   = Color(0xFFADADB8); // Muted grey
const kGreen       = Color(0xFF00C853); // Success
const kRed         = Color(0xFFE53935); // Error

// Light surface colors (for product browsing)
const kBgLight  = Color(0xFFF5F3FF); // Very light purple tint
const kCardBg   = Color(0xFFFFFFFF); // White card

class AppTheme {
  static ThemeData get theme => ThemeData(
    useMaterial3: true,
    fontFamily: 'Roboto',
    colorScheme: ColorScheme.fromSeed(
      seedColor: kPurple,
      primary: kPurple,
      secondary: kPurpleLight,
      surface: kCardBg,
      background: kBgLight,
    ),
    scaffoldBackgroundColor: kBgLight,
    appBarTheme: const AppBarTheme(
      backgroundColor: kDarkBg,
      foregroundColor: kTextWhite,
      elevation: 0,
      centerTitle: false,
      titleTextStyle: TextStyle(
        color: kTextWhite,
        fontSize: 20,
        fontWeight: FontWeight.w700,
        letterSpacing: 0.3,
      ),
    ),
    bottomNavigationBarTheme: const BottomNavigationBarThemeData(
      backgroundColor: kDarkCard,
      selectedItemColor: kPurple,
      unselectedItemColor: kTextMuted,
      showUnselectedLabels: true,
      type: BottomNavigationBarType.fixed,
      elevation: 0,
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: kPurple,
        foregroundColor: Colors.white,
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        padding: const EdgeInsets.symmetric(vertical: 16),
        textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: kDarkSurf.withOpacity(0.05),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: Colors.grey.shade300),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: Colors.grey.shade300),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: kPurple, width: 2),
      ),
      labelStyle: const TextStyle(color: kTextMuted),
      prefixIconColor: kPurple,
    ),
    cardTheme: CardThemeData(
      color: kCardBg,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: Colors.grey.shade100, width: 1),
      ),
    ),
    snackBarTheme: SnackBarThemeData(
      backgroundColor: kDarkCard,
      contentTextStyle: const TextStyle(color: kTextWhite),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      behavior: SnackBarBehavior.floating,
    ),
  );
}
