import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_sound/flutter_sound.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:path_provider/path_provider.dart';
import 'package:image_picker/image_picker.dart';
import '../providers/panier_provider.dart';
import '../services/commande_service.dart';
import '../data/quartiers_libreville.dart';
import '../theme/app_theme.dart';
import 'commandes_screen.dart';

class PanierScreen extends StatefulWidget {
  const PanierScreen({super.key});

  @override
  State<PanierScreen> createState() => _PanierScreenState();
}

class _PanierScreenState extends State<PanierScreen> {
  QuartierLibreville? _quartierSelectionne;
  bool _commandeEnCours = false;
  String? _audioBase64;
  String? _photoRepere;

  Future<void> _choisirQuartier() async {
    final result = await showModalBottomSheet<QuartierLibreville>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => const _QuartierSelector(),
    );
    if (result != null) setState(() => _quartierSelectionne = result);
  }

  Future<void> _commander() async {
    if (_quartierSelectionne == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Sélectionnez un quartier de livraison'),
        backgroundColor: Colors.red,
      ));
      return;
    }
    final panier = context.read<PanierProvider>();
    if (panier.estVide) return;

    setState(() => _commandeEnCours = true);
    try {
      await CommandeService().creerCommande(
        articles: panier.toArticlesCommande(),
        adresseLivraison: _quartierSelectionne!.nom,
        latLivraison: _quartierSelectionne!.latitude,
        lngLivraison: _quartierSelectionne!.longitude,
        audioBase64: _audioBase64,
        photoRepere: _photoRepere,
      );
      panier.vider();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Commande passée avec succès ! 🎉'),
        backgroundColor: kGreen,
      ));
      Navigator.pushReplacement(context,
          MaterialPageRoute(builder: (_) => const CommandesScreen()));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString()), backgroundColor: Colors.red));
    }
    setState(() => _commandeEnCours = false);
  }

  @override
  Widget build(BuildContext context) {
    final panier = context.watch<PanierProvider>();

    return Scaffold(
      backgroundColor: kBgLight,
      appBar: AppBar(
        backgroundColor: kDarkBg,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded, color: kTextWhite),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('Mon panier',
            style: TextStyle(color: kTextWhite, fontWeight: FontWeight.w700)),
        actions: [
          if (!panier.estVide)
            TextButton(
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (_) => AlertDialog(
                    backgroundColor: kDarkCard,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    title: const Text('Vider le panier ?',
                        style: TextStyle(color: kTextWhite, fontWeight: FontWeight.w700)),
                    content: const Text('Tous les articles seront retirés.',
                        style: TextStyle(color: kTextMuted)),
                    actions: [
                      TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: const Text('Annuler', style: TextStyle(color: kTextMuted))),
                      TextButton(
                          onPressed: () { Navigator.pop(context); panier.vider(); },
                          child: const Text('Vider', style: TextStyle(color: Colors.red, fontWeight: FontWeight.w700))),
                    ],
                  ),
                );
              },
              child: const Text('Vider', style: TextStyle(color: kPurpleLight, fontWeight: FontWeight.w600)),
            ),
        ],
      ),
      body: panier.estVide
          ? Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 110, height: 110,
                    decoration: BoxDecoration(
                      color: kPurple.withOpacity(0.08),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.shopping_cart_outlined,
                        size: 56, color: kPurpleLight),
                  ),
                  const SizedBox(height: 18),
                  const Text('Votre panier est vide',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: kDarkBg)),
                  const SizedBox(height: 6),
                  const Text('Ajoutez des produits depuis le catalogue',
                      style: TextStyle(color: kTextMuted, fontSize: 13)),
                ],
              ),
            )
          : Column(
              children: [
                // Liste articles
                Expanded(
                  child: ListView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                    itemCount: panier.articles.length,
                    itemBuilder: (_, i) {
                      final article = panier.articles[i];
                      return Container(
                        margin: const EdgeInsets.only(bottom: 10),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(14),
                          boxShadow: [BoxShadow(
                            color: kPurple.withOpacity(0.05),
                            blurRadius: 10, offset: const Offset(0, 3),
                          )],
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Row(
                            children: [
                              // Icône produit
                              Container(
                                width: 56, height: 56,
                                decoration: BoxDecoration(
                                  color: kPurple.withOpacity(0.08),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: const Icon(Icons.shopping_bag_outlined,
                                    color: kPurpleLight, size: 28),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(article.produit.nom,
                                        style: const TextStyle(
                                            fontWeight: FontWeight.w700,
                                            fontSize: 14, color: kDarkBg)),
                                    const SizedBox(height: 2),
                                    Text(
                                      '${article.produit.prix.toStringAsFixed(0)} FCFA',
                                      style: const TextStyle(
                                          color: kPurple,
                                          fontWeight: FontWeight.w600,
                                          fontSize: 13),
                                    ),
                                  ],
                                ),
                              ),
                              // Quantité
                              Row(children: [
                                _QtyBtn(
                                  icon: Icons.remove_rounded,
                                  onTap: () => panier.retirer(article.produit.id),
                                ),
                                Padding(
                                  padding: const EdgeInsets.symmetric(horizontal: 12),
                                  child: Text('${article.quantite}',
                                      style: const TextStyle(
                                          fontWeight: FontWeight.w800,
                                          fontSize: 16, color: kDarkBg)),
                                ),
                                _QtyBtn(
                                  icon: Icons.add_rounded,
                                  onTap: () => panier.ajouter(article.produit),
                                  filled: true,
                                ),
                              ]),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),

                // Bas de page : quartier + commande
                Container(
                  padding: const EdgeInsets.fromLTRB(20, 20, 20, 28),
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
                    boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 16, offset: Offset(0, -4))],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Sélecteur quartier
                      GestureDetector(
                        onTap: _choisirQuartier,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                          decoration: BoxDecoration(
                            color: kBgLight,
                            border: Border.all(
                              color: _quartierSelectionne != null
                                  ? kPurple
                                  : Colors.grey.shade200,
                              width: _quartierSelectionne != null ? 1.5 : 1,
                            ),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Row(children: [
                            Icon(Icons.location_on_rounded,
                                color: _quartierSelectionne != null
                                    ? kPurple
                                    : kTextMuted),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                _quartierSelectionne != null
                                    ? _quartierSelectionne!.nom
                                    : 'Sélectionner le quartier de livraison',
                                style: TextStyle(
                                  color: _quartierSelectionne != null
                                      ? kDarkBg
                                      : kTextMuted,
                                  fontSize: 14,
                                  fontWeight: _quartierSelectionne != null
                                      ? FontWeight.w600
                                      : FontWeight.normal,
                                ),
                              ),
                            ),
                            const Icon(Icons.arrow_drop_down_rounded, color: kTextMuted),
                          ]),
                        ),
                      ),
                      const SizedBox(height: 12),

                      // Instructions vocales
                      _EnregistreurInstructions(
                        onAudioChange: (v) => setState(() => _audioBase64 = v),
                        onPhotoChange: (v) => setState(() => _photoRepere = v),
                      ),
                      const SizedBox(height: 16),

                      // Total
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('Total',
                              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: kTextMuted)),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(
                                '${panier.total.toStringAsFixed(0)}',
                                style: const TextStyle(
                                    fontSize: 24, fontWeight: FontWeight.w900, color: kPurple),
                              ),
                              const Text('FCFA',
                                  style: TextStyle(color: kTextMuted, fontSize: 11, fontWeight: FontWeight.w600)),
                            ],
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),

                      // Bouton commander
                      SizedBox(
                        width: double.infinity,
                        height: 54,
                        child: ElevatedButton(
                          onPressed: _commandeEnCours ? null : _commander,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: kPurple,
                            disabledBackgroundColor: kPurple.withOpacity(0.4),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(14)),
                          ),
                          child: _commandeEnCours
                              ? const SizedBox(width: 22, height: 22,
                                  child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5))
                              : const Text('Commander',
                                  style: TextStyle(
                                      fontSize: 17, fontWeight: FontWeight.w700, color: Colors.white)),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
    );
  }
}

// ── Bouton quantité ───────────────────────────────────────────────────────────
class _QtyBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final bool filled;
  const _QtyBtn({required this.icon, required this.onTap, this.filled = false});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      width: 30, height: 30,
      decoration: BoxDecoration(
        color: filled ? kPurple : kPurple.withOpacity(0.08),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Icon(icon, size: 16, color: filled ? Colors.white : kPurple),
    ),
  );
}

// ── Enregistreur instructions ─────────────────────────────────────────────────
class _EnregistreurInstructions extends StatefulWidget {
  final ValueChanged<String?> onAudioChange;
  final ValueChanged<String?> onPhotoChange;

  const _EnregistreurInstructions({
    required this.onAudioChange,
    required this.onPhotoChange,
  });

  @override
  State<_EnregistreurInstructions> createState() => _EnregistreurInstructionsState();
}

class _EnregistreurInstructionsState extends State<_EnregistreurInstructions> {
  static const int _dureeMax = 60;

  final _recorder = FlutterSoundRecorder();
  final _player   = FlutterSoundPlayer();

  bool    _recorderOuvert = false;
  bool    _playerOuvert   = false;
  bool    _enregistrement = false;
  bool    _lecture        = false;
  String? _audioBase64;
  String? _photoBase64;
  String? _cheminFichier;
  int     _secondes       = _dureeMax;
  Timer?  _timer;

  @override
  void dispose() {
    _timer?.cancel();
    if (_recorderOuvert) _recorder.closeRecorder();
    if (_playerOuvert) _player.closePlayer();
    super.dispose();
  }

  Future<void> _demarrer() async {
    final status = await Permission.microphone.request();
    if (!status.isGranted) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Permission micro refusée.'), backgroundColor: Colors.red),
      );
      return;
    }
    if (!_recorderOuvert) {
      await _recorder.openRecorder();
      _recorderOuvert = true;
    }
    final dir = await getTemporaryDirectory();
    _cheminFichier = '${dir.path}/instruction_livraison.m4a';
    await _recorder.startRecorder(
      toFile: _cheminFichier, codec: Codec.aacMP4,
      bitRate: 32000, sampleRate: 16000, numChannels: 1,
    );
    setState(() { _enregistrement = true; _secondes = _dureeMax; });
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) { t.cancel(); return; }
      setState(() => _secondes--);
      if (_secondes <= 0) { t.cancel(); _arreter(); }
    });
  }

  Future<void> _arreter() async {
    _timer?.cancel();
    await _recorder.stopRecorder();
    if (_recorderOuvert) { await _recorder.closeRecorder(); _recorderOuvert = false; }
    if (_cheminFichier == null) { setState(() => _enregistrement = false); return; }
    final bytes = await File(_cheminFichier!).readAsBytes();
    final b64 = base64Encode(bytes);
    setState(() { _enregistrement = false; _audioBase64 = b64; });
    widget.onAudioChange(b64);
  }

  void _supprimer() {
    if (_playerOuvert) _player.stopPlayer();
    setState(() { _audioBase64 = null; _lecture = false; });
    widget.onAudioChange(null);
  }

  Future<void> _toggleLecture() async {
    if (_cheminFichier == null) return;
    if (_lecture) {
      await _player.stopPlayer();
      setState(() => _lecture = false);
    } else {
      if (!_playerOuvert) { await _player.openPlayer(); _playerOuvert = true; }
      await _player.startPlayer(
        fromURI: _cheminFichier, codec: Codec.aacMP4,
        whenFinished: () { if (mounted) setState(() => _lecture = false); },
      );
      setState(() => _lecture = true);
    }
  }

  Future<void> _ajouterPhoto() async {
    final picked = await ImagePicker().pickImage(
      source: ImageSource.gallery, maxWidth: 800, maxHeight: 800, imageQuality: 70,
    );
    if (picked == null || !mounted) return;
    final bytes = await picked.readAsBytes();
    final b64 = base64Encode(bytes);
    setState(() => _photoBase64 = b64);
    widget.onPhotoChange(b64);
  }

  void _supprimerPhoto() {
    setState(() => _photoBase64 = null);
    widget.onPhotoChange(null);
  }

  String get _formatTimer {
    final m = _secondes ~/ 60;
    final s = _secondes % 60;
    return '$m:${s.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: kPurple.withOpacity(0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: kPurple.withOpacity(0.2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            const Icon(Icons.mic_rounded, color: kPurple, size: 16),
            const SizedBox(width: 6),
            const Expanded(
              child: Text('Guidez votre livreur (optionnel)',
                  style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: kDarkBg)),
            ),
          ]),
          const SizedBox(height: 4),
          const Text('Décrivez l\'itinéraire ou les repères pour trouver votre adresse.',
              style: TextStyle(fontSize: 11, color: kTextMuted)),
          const SizedBox(height: 12),

          // Zone audio
          if (!_enregistrement && _audioBase64 == null)
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: _demarrer,
                icon: const Icon(Icons.mic_none_rounded, color: Colors.white, size: 16),
                label: const Text('Enregistrer (max 1 min)',
                    style: TextStyle(color: Colors.white, fontSize: 12)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: kPurple,
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
              ),
            ),

          if (_enregistrement)
            Row(children: [
              Container(width: 10, height: 10,
                  decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle)),
              const SizedBox(width: 8),
              const Text('Enregistrement...',
                  style: TextStyle(color: Colors.red, fontWeight: FontWeight.w600, fontSize: 13)),
              const Spacer(),
              Text(_formatTimer,
                  style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15, color: kDarkBg)),
              const SizedBox(width: 10),
              ElevatedButton(
                onPressed: _arreter,
                style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red,
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8))),
                child: const Text('Stop', style: TextStyle(color: Colors.white, fontSize: 12)),
              ),
            ]),

          if (_audioBase64 != null)
            Row(children: [
              IconButton(
                onPressed: _toggleLecture,
                icon: Icon(
                  _lecture ? Icons.stop_circle_rounded : Icons.play_circle_filled_rounded,
                  color: kPurple, size: 34,
                ),
                padding: EdgeInsets.zero, constraints: const BoxConstraints(),
              ),
              const SizedBox(width: 8),
              const Expanded(
                child: Text('Instruction enregistrée ✓',
                    style: TextStyle(color: kGreen, fontWeight: FontWeight.w600, fontSize: 13)),
              ),
              IconButton(
                onPressed: _supprimer,
                icon: const Icon(Icons.delete_outline_rounded, color: Colors.red, size: 18),
                padding: EdgeInsets.zero, constraints: const BoxConstraints(),
              ),
            ]),

          const SizedBox(height: 10),
          Divider(height: 1, color: kPurple.withOpacity(0.15)),
          const SizedBox(height: 10),

          // Photo repère
          if (_photoBase64 == null)
            GestureDetector(
              onTap: _ajouterPhoto,
              child: const Row(children: [
                Icon(Icons.add_a_photo_outlined, color: kPurple, size: 16),
                SizedBox(width: 6),
                Text('Ajouter une photo du repère',
                    style: TextStyle(color: kPurple, fontSize: 13, fontWeight: FontWeight.w600)),
              ]),
            )
          else
            Row(children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.memory(
                  base64Decode(_photoBase64!),
                  width: 56, height: 56, fit: BoxFit.cover,
                ),
              ),
              const SizedBox(width: 10),
              const Expanded(
                child: Text('Photo du repère ajoutée ✓',
                    style: TextStyle(color: kGreen, fontWeight: FontWeight.w600, fontSize: 13)),
              ),
              IconButton(
                onPressed: _supprimerPhoto,
                icon: const Icon(Icons.delete_outline_rounded, color: Colors.red, size: 18),
                padding: EdgeInsets.zero, constraints: const BoxConstraints(),
              ),
            ]),
        ],
      ),
    );
  }
}

// ── Bottom sheet sélecteur quartier ──────────────────────────────────────────
class _QuartierSelector extends StatefulWidget {
  const _QuartierSelector();

  @override
  State<_QuartierSelector> createState() => _QuartierSelectorState();
}

class _QuartierSelectorState extends State<_QuartierSelector> {
  String _recherche = '';

  List<QuartierLibreville> get _filtres => quartiersLibreville
      .where((q) => q.nom.toLowerCase().contains(_recherche.toLowerCase()))
      .toList();

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.75,
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: Column(
        children: [
          const SizedBox(height: 12),
          Container(
            width: 40, height: 4,
            decoration: BoxDecoration(
                color: Colors.grey.shade300, borderRadius: BorderRadius.circular(2)),
          ),
          const SizedBox(height: 16),

          // Titre
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: kPurple.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Icon(Icons.location_on_rounded, color: kPurple, size: 18),
              ),
              const SizedBox(width: 10),
              const Text('Choisir votre quartier',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: kDarkBg)),
            ],
          ),
          const SizedBox(height: 14),

          // Recherche
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: TextField(
              autofocus: true,
              style: const TextStyle(color: kDarkBg),
              onChanged: (v) => setState(() => _recherche = v),
              decoration: InputDecoration(
                hintText: 'Rechercher un quartier…',
                hintStyle: const TextStyle(color: kTextMuted),
                prefixIcon: const Icon(Icons.search_rounded, color: kPurple),
                filled: true,
                fillColor: kBgLight,
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none),
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
              ),
            ),
          ),
          const SizedBox(height: 8),

          // Liste
          Expanded(
            child: ListView.builder(
              itemCount: _filtres.length,
              itemBuilder: (_, i) {
                final q = _filtres[i];
                return ListTile(
                  leading: Container(
                    width: 36, height: 36,
                    decoration: BoxDecoration(
                      color: kPurple.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Icon(Icons.place_rounded, color: kPurple, size: 18),
                  ),
                  title: Text(q.nom,
                      style: const TextStyle(fontWeight: FontWeight.w600, color: kDarkBg, fontSize: 14)),
                  subtitle: const Text('Libreville, Gabon',
                      style: TextStyle(color: kTextMuted, fontSize: 12)),
                  onTap: () => Navigator.pop(context, q),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
