import 'package:flutter/material.dart';
import '../models/commande.dart';
import '../services/commande_service.dart';
import '../theme/app_theme.dart';
import 'suivi_commande_screen.dart';

class CommandesScreen extends StatefulWidget {
  const CommandesScreen({super.key});

  @override
  State<CommandesScreen> createState() => _CommandesScreenState();
}

class _CommandesScreenState extends State<CommandesScreen> {
  final CommandeService _service = CommandeService();
  List<Commande> _commandes = [];
  bool _chargement = true;
  String? _erreur;

  @override
  void initState() {
    super.initState();
    _charger();
  }

  Future<void> _charger() async {
    setState(() { _chargement = true; _erreur = null; });
    try {
      final commandes = await _service.mesCommandes();
      setState(() { _commandes = commandes; _chargement = false; });
    } catch (e) {
      setState(() { _chargement = false; _erreur = e.toString(); });
    }
  }

  Color _couleurStatut(String statut) {
    switch (statut) {
      case 'livree':       return kGreen;
      case 'annulee':      return Colors.red;
      case 'en_livraison': return const Color(0xFF1E88E5);
      case 'en_preparation': return kPurple;
      default:             return kTextMuted;
    }
  }

  IconData _iconeStatut(String statut) {
    switch (statut) {
      case 'livree':         return Icons.check_circle_rounded;
      case 'annulee':        return Icons.cancel_rounded;
      case 'en_livraison':   return Icons.delivery_dining_rounded;
      case 'en_preparation': return Icons.restaurant_rounded;
      default:               return Icons.receipt_long_rounded;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBgLight,
      appBar: AppBar(
        backgroundColor: kDarkBg,
        title: RichText(
          text: const TextSpan(children: [
            TextSpan(text: 'L', style: TextStyle(
                color: kTextWhite, fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: -1)),
            TextSpan(text: 'X', style: TextStyle(
                color: kPurple, fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: -1)),
            TextSpan(text: '  Mes commandes', style: TextStyle(
                color: kTextWhite, fontSize: 16, fontWeight: FontWeight.w600)),
          ]),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: kTextWhite),
            onPressed: _charger,
          ),
        ],
      ),
      body: _chargement
          ? const Center(child: CircularProgressIndicator(color: kPurple))
          : _erreur != null
              ? Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.wifi_off_rounded, size: 64,
                          color: kPurple.withOpacity(0.4)),
                      const SizedBox(height: 12),
                      const Text('Connexion impossible',
                          style: TextStyle(color: kDarkBg, fontWeight: FontWeight.w700, fontSize: 16)),
                      const SizedBox(height: 16),
                      ElevatedButton.icon(
                        onPressed: _charger,
                        icon: const Icon(Icons.refresh_rounded, color: Colors.white),
                        label: const Text('Réessayer', style: TextStyle(color: Colors.white)),
                        style: ElevatedButton.styleFrom(backgroundColor: kPurple,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                      ),
                    ],
                  ),
                )
              : _commandes.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            width: 100, height: 100,
                            decoration: BoxDecoration(
                              color: kPurple.withOpacity(0.08),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(Icons.receipt_long_outlined,
                                size: 52, color: kPurpleLight),
                          ),
                          const SizedBox(height: 16),
                          const Text('Aucune commande',
                              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: kDarkBg)),
                          const SizedBox(height: 6),
                          const Text('Vos commandes apparaîtront ici',
                              style: TextStyle(color: kTextMuted)),
                        ],
                      ),
                    )
                  : RefreshIndicator(
                      color: kPurple,
                      onRefresh: _charger,
                      child: ListView.builder(
                        padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
                        itemCount: _commandes.length,
                        itemBuilder: (_, i) {
                          final c = _commandes[i];
                          final couleur = _couleurStatut(c.statut);
                          return GestureDetector(
                            onTap: () => Navigator.push(context,
                                MaterialPageRoute(builder: (_) =>
                                    SuiviCommandeScreen(commande: c))),
                            child: Container(
                              margin: const EdgeInsets.only(bottom: 12),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(16),
                                boxShadow: [BoxShadow(
                                  color: kPurple.withOpacity(0.06),
                                  blurRadius: 12, offset: const Offset(0, 4),
                                )],
                              ),
                              child: Column(
                                children: [
                                  // Barre couleur statut en haut
                                  Container(
                                    height: 4,
                                    decoration: BoxDecoration(
                                      color: couleur,
                                      borderRadius: const BorderRadius.vertical(
                                          top: Radius.circular(16)),
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.all(16),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text(
                                              '#${c.id.substring(0, 8).toUpperCase()}',
                                              style: const TextStyle(
                                                  fontWeight: FontWeight.w800,
                                                  fontSize: 14,
                                                  color: kDarkBg,
                                                  letterSpacing: .5),
                                            ),
                                            Container(
                                              padding: const EdgeInsets.symmetric(
                                                  horizontal: 10, vertical: 4),
                                              decoration: BoxDecoration(
                                                color: couleur.withOpacity(0.12),
                                                borderRadius:
                                                    BorderRadius.circular(20),
                                                border: Border.all(
                                                    color: couleur.withOpacity(0.35)),
                                              ),
                                              child: Row(
                                                mainAxisSize: MainAxisSize.min,
                                                children: [
                                                  Icon(_iconeStatut(c.statut),
                                                      size: 12, color: couleur),
                                                  const SizedBox(width: 4),
                                                  Text(c.statutLabel,
                                                      style: TextStyle(
                                                          color: couleur,
                                                          fontWeight:
                                                              FontWeight.w700,
                                                          fontSize: 11)),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                        const SizedBox(height: 10),
                                        Row(children: [
                                          const Icon(Icons.shopping_bag_outlined,
                                              size: 14, color: kTextMuted),
                                          const SizedBox(width: 6),
                                          Text(
                                            '${c.articles.length} article${c.articles.length > 1 ? 's' : ''}',
                                            style: const TextStyle(
                                                color: kTextMuted, fontSize: 13),
                                          ),
                                        ]),
                                        const SizedBox(height: 4),
                                        Row(children: [
                                          const Icon(Icons.location_on_outlined,
                                              size: 14, color: kTextMuted),
                                          const SizedBox(width: 6),
                                          Expanded(
                                            child: Text(c.adresseLivraison,
                                              style: const TextStyle(
                                                  color: kTextMuted, fontSize: 13),
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis),
                                          ),
                                        ]),
                                        const SizedBox(height: 12),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  '${c.total.toStringAsFixed(0)}',
                                                  style: const TextStyle(
                                                      fontWeight: FontWeight.w800,
                                                      fontSize: 20,
                                                      color: kPurple),
                                                ),
                                                const Text('FCFA',
                                                    style: TextStyle(
                                                        color: kTextMuted,
                                                        fontSize: 10,
                                                        fontWeight: FontWeight.w600)),
                                              ],
                                            ),
                                            Row(children: [
                                              if (c.statut == 'livree' &&
                                                  c.livreurId != null &&
                                                  c.noteLivreurParClient == null)
                                                Container(
                                                  margin: const EdgeInsets.only(right: 8),
                                                  padding: const EdgeInsets.symmetric(
                                                      horizontal: 8, vertical: 4),
                                                  decoration: BoxDecoration(
                                                    color: Colors.amber.withOpacity(0.15),
                                                    borderRadius: BorderRadius.circular(10),
                                                    border: Border.all(color: Colors.amber.withOpacity(0.4)),
                                                  ),
                                                  child: const Text('⭐ À noter',
                                                    style: TextStyle(
                                                        color: Colors.amber,
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.w700)),
                                                ),
                                              const Icon(Icons.arrow_forward_ios_rounded,
                                                  size: 14, color: kTextMuted),
                                            ]),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
    );
  }
}
