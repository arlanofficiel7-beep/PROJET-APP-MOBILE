import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:provider/provider.dart';
import '../models/produit.dart';
import '../providers/panier_provider.dart';
import '../theme/app_theme.dart';

class ProduitDetailScreen extends StatelessWidget {
  final Produit produit;

  const ProduitDetailScreen({super.key, required this.produit});

  @override
  Widget build(BuildContext context) {
    final enStock = produit.stock > 0;

    return Scaffold(
      backgroundColor: kBgLight,
      body: CustomScrollView(
        slivers: [
          // ── AppBar avec image ──────────────────────────────────────────
          SliverAppBar(
            expandedHeight: 300,
            pinned: true,
            backgroundColor: kDarkBg,
            leading: IconButton(
              icon: Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: kDarkBg.withOpacity(0.6),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.arrow_back_ios_rounded,
                    color: kTextWhite, size: 18),
              ),
              onPressed: () => Navigator.pop(context),
            ),
            flexibleSpace: FlexibleSpaceBar(
              background: Stack(
                fit: StackFit.expand,
                children: [
                  produit.imageUrl.isNotEmpty
                      ? CachedNetworkImage(
                          imageUrl: produit.imageUrl,
                          fit: BoxFit.cover,
                          placeholder: (_, __) => Container(
                            color: kPurple.withOpacity(0.1),
                            child: const Center(
                              child: CircularProgressIndicator(color: kPurple, strokeWidth: 2),
                            ),
                          ),
                          errorWidget: (_, __, ___) => Container(
                            color: kPurple.withOpacity(0.08),
                            child: const Icon(Icons.shopping_bag_outlined,
                                size: 80, color: kPurpleLight),
                          ),
                        )
                      : Container(
                          color: kPurple.withOpacity(0.08),
                          child: const Icon(Icons.shopping_bag_outlined,
                              size: 80, color: kPurpleLight),
                        ),
                  // Dégradé du bas
                  Positioned.fill(
                    child: DecoratedBox(
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [Colors.transparent, Colors.black45],
                          stops: [0.6, 1.0],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // ── Corps ──────────────────────────────────────────────────────
          SliverToBoxAdapter(
            child: Container(
              decoration: const BoxDecoration(
                color: kBgLight,
                borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
              ),
              padding: const EdgeInsets.fromLTRB(24, 28, 24, 32),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Nom + catégorie
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Text(produit.nom,
                          style: const TextStyle(
                              fontSize: 22, fontWeight: FontWeight.w800, color: kDarkBg, height: 1.2)),
                      ),
                      const SizedBox(width: 12),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: kPurple.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: kPurple.withOpacity(0.25)),
                        ),
                        child: Text(produit.categorie,
                          style: const TextStyle(
                              color: kPurple, fontWeight: FontWeight.w700, fontSize: 12)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),

                  // Prix
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        produit.prix.toStringAsFixed(0),
                        style: const TextStyle(
                            fontSize: 34, fontWeight: FontWeight.w900, color: kPurple, height: 1),
                      ),
                      const Padding(
                        padding: EdgeInsets.only(left: 6, bottom: 4),
                        child: Text('FCFA',
                          style: TextStyle(fontSize: 14, color: kTextMuted, fontWeight: FontWeight.w700)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),

                  // Badge stock
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                    decoration: BoxDecoration(
                      color: enStock
                          ? kGreen.withOpacity(0.1)
                          : Colors.red.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: enStock
                            ? kGreen.withOpacity(0.3)
                            : Colors.red.withOpacity(0.3),
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          enStock ? Icons.check_circle_rounded : Icons.cancel_rounded,
                          size: 16,
                          color: enStock ? kGreen : Colors.red,
                        ),
                        const SizedBox(width: 6),
                        Text(
                          enStock
                              ? 'En stock · ${produit.stock} disponibles'
                              : 'Rupture de stock',
                          style: TextStyle(
                            color: enStock ? kGreen : Colors.red,
                            fontWeight: FontWeight.w700,
                            fontSize: 13,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),

                  // Séparateur
                  Container(height: 1, color: Colors.grey.shade200),
                  const SizedBox(height: 20),

                  // Description
                  const Text('Description',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: kDarkBg)),
                  const SizedBox(height: 10),
                  Text(produit.description,
                    style: const TextStyle(color: kTextMuted, fontSize: 14, height: 1.65)),
                  const SizedBox(height: 40),
                ],
              ),
            ),
          ),
        ],
      ),

      // ── Bouton ajouter ─────────────────────────────────────────────────
      bottomNavigationBar: Container(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
        decoration: const BoxDecoration(
          color: Colors.white,
          boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 12, offset: Offset(0, -3))],
        ),
        child: SizedBox(
          height: 54,
          child: ElevatedButton.icon(
            onPressed: enStock
                ? () {
                    context.read<PanierProvider>().ajouter(produit);
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                      content: Row(children: [
                        const Icon(Icons.check_circle_rounded, color: kPurpleLight, size: 18),
                        const SizedBox(width: 8),
                        Text('${produit.nom} ajouté au panier !'),
                      ]),
                      backgroundColor: kDarkCard,
                      duration: const Duration(seconds: 2),
                    ));
                  }
                : null,
            style: ElevatedButton.styleFrom(
              backgroundColor: kPurple,
              disabledBackgroundColor: Colors.grey.shade300,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            ),
            icon: const Icon(Icons.shopping_bag_rounded, color: Colors.white),
            label: Text(
              enStock ? 'Ajouter au panier' : 'Indisponible',
              style: const TextStyle(
                  fontSize: 16, fontWeight: FontWeight.w700, color: Colors.white),
            ),
          ),
        ),
      ),
    );
  }
}
