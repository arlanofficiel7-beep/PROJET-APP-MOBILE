import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../theme/app_theme.dart';
import 'register_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey   = GlobalKey<FormState>();
  final _emailCtrl = TextEditingController();
  final _mdpCtrl   = TextEditingController();
  bool _mdpVisible = false;

  @override
  void dispose() {
    _emailCtrl.dispose();
    _mdpCtrl.dispose();
    super.dispose();
  }

  Future<void> _seConnecter() async {
    if (!_formKey.currentState!.validate()) return;
    final auth = context.read<AuthProvider>();
    final succes = await auth.connexion(_emailCtrl.text.trim(), _mdpCtrl.text);
    if (!mounted) return;
    if (succes) {
      Navigator.pushReplacementNamed(context, '/accueil');
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(auth.erreur ?? 'Erreur de connexion')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();

    return Scaffold(
      backgroundColor: kDarkBg,
      body: SafeArea(
        child: SingleChildScrollView(
          child: SizedBox(
            height: MediaQuery.of(context).size.height - MediaQuery.of(context).padding.top,
            child: Column(
              children: [
                // ── Header dark avec logo ──────────────────────────────
                Expanded(
                  flex: 4,
                  child: Container(
                    width: double.infinity,
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [Color(0xFF1A0040), kDarkBg],
                      ),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        // Logo LX
                        Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: kPurple.withOpacity(0.4),
                                blurRadius: 40,
                                spreadRadius: 10,
                              ),
                            ],
                          ),
                          child: RichText(
                            text: const TextSpan(children: [
                              TextSpan(text: 'L', style: TextStyle(
                                color: kTextWhite, fontSize: 60,
                                fontWeight: FontWeight.w900, letterSpacing: -2,
                              )),
                              TextSpan(text: 'X', style: TextStyle(
                                color: kPurple, fontSize: 60,
                                fontWeight: FontWeight.w900, letterSpacing: -2,
                              )),
                            ]),
                          ),
                        ),
                        const SizedBox(height: 12),
                        const Text('Livraison Express',
                          style: TextStyle(color: kTextWhite, fontSize: 22, fontWeight: FontWeight.w700)),
                        const SizedBox(height: 6),
                        const Text('Libreville, Gabon',
                          style: TextStyle(color: kTextMuted, fontSize: 13, letterSpacing: 1)),
                      ],
                    ),
                  ),
                ),

                // ── Formulaire ─────────────────────────────────────────
                Expanded(
                  flex: 6,
                  child: Container(
                    width: double.infinity,
                    decoration: const BoxDecoration(
                      color: kBgLight,
                      borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
                    ),
                    padding: const EdgeInsets.fromLTRB(28, 36, 28, 24),
                    child: Form(
                      key: _formKey,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          const Text('Connexion',
                            style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: kDarkBg)),
                          const SizedBox(height: 6),
                          const Text('Bienvenue ! Entrez vos identifiants.',
                            style: TextStyle(color: kTextMuted, fontSize: 14)),
                          const SizedBox(height: 28),

                          // Email
                          TextFormField(
                            controller: _emailCtrl,
                            keyboardType: TextInputType.emailAddress,
                            style: const TextStyle(color: kDarkBg),
                            decoration: const InputDecoration(
                              labelText: 'Adresse email',
                              prefixIcon: Icon(Icons.email_outlined),
                            ),
                            validator: (v) => v!.contains('@') ? null : 'Email invalide',
                          ),
                          const SizedBox(height: 16),

                          // Mot de passe
                          TextFormField(
                            controller: _mdpCtrl,
                            obscureText: !_mdpVisible,
                            style: const TextStyle(color: kDarkBg),
                            decoration: InputDecoration(
                              labelText: 'Mot de passe',
                              prefixIcon: const Icon(Icons.lock_outline_rounded),
                              suffixIcon: IconButton(
                                icon: Icon(_mdpVisible
                                    ? Icons.visibility_off_rounded
                                    : Icons.visibility_rounded,
                                    color: kTextMuted),
                                onPressed: () => setState(() => _mdpVisible = !_mdpVisible),
                              ),
                            ),
                            validator: (v) => v!.length >= 6 ? null : 'Minimum 6 caractères',
                          ),
                          const SizedBox(height: 28),

                          // Bouton connexion
                          SizedBox(
                            height: 54,
                            child: ElevatedButton(
                              onPressed: auth.chargement ? null : _seConnecter,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: kPurple,
                                disabledBackgroundColor: kPurple.withOpacity(0.4),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                              ),
                              child: auth.chargement
                                  ? const SizedBox(width: 22, height: 22,
                                      child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5))
                                  : const Text('Se connecter',
                                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: Colors.white)),
                            ),
                          ),
                          const Spacer(),

                          // Lien inscription
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Text('Pas encore de compte ? ',
                                style: TextStyle(color: kTextMuted, fontSize: 14)),
                              GestureDetector(
                                onTap: () => Navigator.push(context,
                                    MaterialPageRoute(builder: (_) => const RegisterScreen())),
                                child: const Text("S'inscrire",
                                  style: TextStyle(
                                    color: kPurple, fontSize: 14, fontWeight: FontWeight.w700)),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
