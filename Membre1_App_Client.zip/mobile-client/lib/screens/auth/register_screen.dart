import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../services/auth_service.dart';
import '../../theme/app_theme.dart';
import 'otp_screen.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nomCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _telCtrl = TextEditingController();
  final _mdpCtrl = TextEditingController();
  bool _mdpVisible = false;
  bool _envoiOtp = false;

  @override
  void dispose() {
    _nomCtrl.dispose(); _emailCtrl.dispose();
    _telCtrl.dispose(); _mdpCtrl.dispose();
    super.dispose();
  }

  Future<void> _sInscrire() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _envoiOtp = true);
    try {
      // Envoyer le code OTP à l'email
      final result = await AuthService().envoyerOtp(_emailCtrl.text.trim());
      if (!mounted) return;

      final msg = (result['message'] ?? '').toString().toLowerCase();
      if (msg.contains('envoy') || msg.contains('code')) {
        // Naviguer vers l'écran de vérification OTP
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => OtpScreen(
              email:      _emailCtrl.text.trim(),
              nom:        _nomCtrl.text.trim(),
              telephone:  _telCtrl.text.trim(),
              motDePasse: _mdpCtrl.text,
            ),
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(result['message'] ?? "Erreur d'envoi"),
            backgroundColor: Colors.red,
          ),
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erreur réseau : $e'), backgroundColor: Colors.red),
      );
    } finally {
      if (mounted) setState(() => _envoiOtp = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kDarkBg,
      appBar: AppBar(
        backgroundColor: kDarkBg,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded, color: kTextWhite),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('Créer un compte',
            style: TextStyle(color: kTextWhite, fontWeight: FontWeight.w700)),
      ),
      body: Column(
        children: [
          // Barre violette décorative
          Container(
            height: 4,
            decoration: const BoxDecoration(
              gradient: LinearGradient(colors: [kPurple, kPurpleLight]),
            ),
          ),
          Expanded(
            child: Container(
              color: kBgLight,
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(24, 28, 24, 24),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const Text('Vos informations',
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: kDarkBg)),
                      const SizedBox(height: 4),
                      const Text('Tous les champs sont obligatoires.',
                        style: TextStyle(color: kTextMuted, fontSize: 13)),
                      const SizedBox(height: 24),

                      _champ(
                        controller: _nomCtrl,
                        label: 'Nom complet',
                        hint: 'Ex : NGUEMA Jean-Pierre',
                        icon: Icons.person_rounded,
                        validator: (v) => v!.length >= 2 ? null : 'Nom trop court',
                      ),
                      const SizedBox(height: 14),
                      _champ(
                        controller: _emailCtrl,
                        label: 'Adresse email',
                        icon: Icons.email_rounded,
                        type: TextInputType.emailAddress,
                        validator: (v) => v!.contains('@') ? null : 'Email invalide',
                      ),
                      const SizedBox(height: 14),
                      _champ(
                        controller: _telCtrl,
                        label: 'Téléphone',
                        hint: '+241 07 12 34 56',
                        icon: Icons.phone_rounded,
                        type: TextInputType.phone,
                        validator: (v) {
                          if (v == null || v.trim().isEmpty) return 'Numéro obligatoire';
                          if (v.trim().length < 8) return 'Numéro trop court';
                          return null;
                        },
                      ),
                      const SizedBox(height: 14),

                      // Mot de passe
                      TextFormField(
                        controller: _mdpCtrl,
                        obscureText: !_mdpVisible,
                        style: const TextStyle(color: kDarkBg),
                        decoration: InputDecoration(
                          labelText: 'Mot de passe',
                          prefixIcon: const Icon(Icons.lock_rounded),
                          suffixIcon: IconButton(
                            icon: Icon(_mdpVisible
                                ? Icons.visibility_off_rounded
                                : Icons.visibility_rounded,
                                color: kTextMuted),
                            onPressed: () => setState(() => _mdpVisible = !_mdpVisible),
                          ),
                        ),
                        validator: (v) => v!.length >= 6 ? null : 'Minimum 6 caractères',
                      ),
                      const SizedBox(height: 32),

                      // Bouton
                      SizedBox(
                        height: 54,
                        child: ElevatedButton(
                          onPressed: _envoiOtp ? null : _sInscrire,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: kPurple,
                            disabledBackgroundColor: kPurple.withOpacity(0.4),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                          ),
                          child: _envoiOtp
                              ? const SizedBox(width: 22, height: 22,
                                  child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5))
                              : const Text("S'inscrire",
                                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: Colors.white)),
                        ),
                      ),
                      const SizedBox(height: 20),

                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Text('Déjà un compte ? ',
                              style: TextStyle(color: kTextMuted, fontSize: 14)),
                          GestureDetector(
                            onTap: () => Navigator.pop(context),
                            child: const Text('Se connecter',
                                style: TextStyle(color: kPurple, fontSize: 14, fontWeight: FontWeight.w700)),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _champ({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    String? hint,
    TextInputType? type,
    String? Function(String?)? validator,
  }) {
    return TextFormField(
      controller: controller,
      keyboardType: type,
      style: const TextStyle(color: kDarkBg),
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        prefixIcon: Icon(icon),
      ),
      validator: validator,
    );
  }
}
