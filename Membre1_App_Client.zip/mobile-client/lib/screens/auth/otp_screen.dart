import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../services/auth_service.dart';
import '../../theme/app_theme.dart';

class OtpScreen extends StatefulWidget {
  final String email;
  final String nom;
  final String telephone;
  final String motDePasse;

  const OtpScreen({
    super.key,
    required this.email,
    required this.nom,
    required this.telephone,
    required this.motDePasse,
  });

  @override
  State<OtpScreen> createState() => _OtpScreenState();
}

class _OtpScreenState extends State<OtpScreen> {
  final List<TextEditingController> _ctrl =
      List.generate(6, (_) => TextEditingController());
  final List<FocusNode> _focus = List.generate(6, (_) => FocusNode());

  int _secondesRestantes = 120;
  Timer? _timer;
  bool _chargement = false;

  @override
  void initState() {
    super.initState();
    _demarrerTimer();
    for (final f in _focus) {
      f.addListener(() { if (mounted) setState(() {}); });
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    for (final c in _ctrl) c.dispose();
    for (final f in _focus) f.dispose();
    super.dispose();
  }

  void _demarrerTimer() {
    _secondesRestantes = 120;
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) { t.cancel(); return; }
      setState(() => _secondesRestantes--);
      if (_secondesRestantes <= 0) t.cancel();
    });
  }

  String get _codeComplet => _ctrl.map((c) => c.text).join();

  void _onDigitChanged(int index, String value) {
    if (value.isEmpty) {
      if (index > 0) _focus[index - 1].requestFocus();
      return;
    }
    if (value.length == 6) {
      for (int i = 0; i < 6; i++) _ctrl[i].text = value[i];
      _focus[5].requestFocus();
      _verifier();
      return;
    }
    if (index < 5) {
      _focus[index + 1].requestFocus();
    } else {
      _focus[index].unfocus();
      _verifier();
    }
  }

  Future<void> _verifier() async {
    final code = _codeComplet;
    if (code.length < 6) {
      _showSnack('Entrez les 6 chiffres du code', isError: true);
      return;
    }
    setState(() => _chargement = true);
    try {
      final result = await AuthService().verifierOtp(widget.email, code);
      if (!mounted) return;
      if ((result['statusCode'] ?? 0) == 200) {
        final auth = context.read<AuthProvider>();
        final succes = await auth.inscription(
          widget.nom, widget.email, widget.motDePasse, widget.telephone,
        );
        if (!mounted) return;
        if (succes) {
          Navigator.pushNamedAndRemoveUntil(context, '/accueil', (_) => false);
        } else {
          _showSnack(auth.erreur ?? "Erreur lors de l'inscription", isError: true);
        }
      } else {
        _showSnack(result['message'] ?? 'Code incorrect', isError: true);
        for (final c in _ctrl) c.clear();
        _focus[0].requestFocus();
      }
    } catch (e) {
      if (mounted) _showSnack('Erreur réseau', isError: true);
    } finally {
      if (mounted) setState(() => _chargement = false);
    }
  }

  Future<void> _renvoyerCode() async {
    setState(() => _chargement = true);
    try {
      final result = await AuthService().envoyerOtp(widget.email);
      if (!mounted) return;
      _showSnack(result['message'] ?? 'Code renvoyé');
      _demarrerTimer();
      for (final c in _ctrl) c.clear();
      _focus[0].requestFocus();
    } catch (_) {
      if (mounted) _showSnack('Erreur envoi', isError: true);
    } finally {
      if (mounted) setState(() => _chargement = false);
    }
  }

  void _showSnack(String msg, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: isError ? Colors.red : kGreen,
    ));
  }

  @override
  Widget build(BuildContext context) {
    final parts = widget.email.split('@');
    final local = parts[0];
    final domain = parts.length > 1 ? '@${parts[1]}' : '';
    final emailAffiche = local.length > 3
        ? '${local.substring(0, 3)}***$domain'
        : '***$domain';

    return Scaffold(
      backgroundColor: kDarkBg,
      appBar: AppBar(
        backgroundColor: kDarkBg,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded, color: kTextWhite),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('Confirmation email',
            style: TextStyle(color: kTextWhite, fontWeight: FontWeight.w700)),
      ),
      body: Column(
        children: [
          Container(
            height: 4,
            decoration: const BoxDecoration(
              gradient: LinearGradient(colors: [kPurple, kPurpleLight]),
            ),
          ),
          Expanded(
            child: Container(
              color: kBgLight,
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(28, 40, 28, 28),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    // Icône
                    Container(
                      width: 84, height: 84,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [kPurple, kPurpleDark],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        shape: BoxShape.circle,
                        boxShadow: [BoxShadow(
                          color: kPurple.withOpacity(0.35),
                          blurRadius: 24, offset: const Offset(0, 8),
                        )],
                      ),
                      child: const Icon(Icons.mark_email_read_outlined,
                          size: 40, color: Colors.white),
                    ),
                    const SizedBox(height: 24),

                    const Text('Vérifiez votre email',
                      style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: kDarkBg)),
                    const SizedBox(height: 10),
                    Text(
                      'Code à 6 chiffres envoyé à\n$emailAffiche',
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 14, color: kTextMuted, height: 1.5),
                    ),
                    const SizedBox(height: 6),
                    const Text('(Vérifiez aussi vos spams)',
                      style: TextStyle(fontSize: 12, color: kTextMuted)),
                    const SizedBox(height: 36),

                    // 6 cases
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(6, (i) => _buildCase(i)),
                    ),
                    const SizedBox(height: 36),

                    // Bouton vérifier
                    SizedBox(
                      width: double.infinity,
                      height: 54,
                      child: ElevatedButton(
                        onPressed: (_chargement || _codeComplet.length < 6)
                            ? null
                            : _verifier,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: kPurple,
                          disabledBackgroundColor: kPurple.withOpacity(0.35),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14)),
                        ),
                        child: _chargement
                            ? const SizedBox(width: 22, height: 22,
                                child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5))
                            : const Text('Confirmer le code',
                                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: Colors.white)),
                      ),
                    ),
                    const SizedBox(height: 28),

                    // Timer / renvoi
                    if (_secondesRestantes > 0)
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.timer_outlined, size: 15, color: kTextMuted),
                          const SizedBox(width: 6),
                          Text(
                            'Renvoyer dans $_secondesRestantes s',
                            style: const TextStyle(color: kTextMuted, fontSize: 14),
                          ),
                        ],
                      )
                    else
                      GestureDetector(
                        onTap: _chargement ? null : _renvoyerCode,
                        child: const Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.refresh_rounded, color: kPurple, size: 18),
                            SizedBox(width: 6),
                            Text('Renvoyer le code',
                              style: TextStyle(color: kPurple, fontWeight: FontWeight.w700, fontSize: 15)),
                          ],
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCase(int index) {
    final hasFocus = _focus[index].hasFocus;
    return Container(
      width: 46, height: 58,
      margin: const EdgeInsets.symmetric(horizontal: 4),
      decoration: BoxDecoration(
        color: hasFocus ? kPurple.withOpacity(0.06) : Colors.white,
        border: Border.all(
          color: hasFocus ? kPurple : Colors.grey.shade300,
          width: hasFocus ? 2.5 : 1.5,
        ),
        borderRadius: BorderRadius.circular(12),
        boxShadow: hasFocus ? [BoxShadow(
          color: kPurple.withOpacity(0.2), blurRadius: 8, offset: const Offset(0, 3),
        )] : null,
      ),
      child: TextField(
        controller: _ctrl[index],
        focusNode: _focus[index],
        textAlign: TextAlign.center,
        keyboardType: TextInputType.number,
        maxLength: 6,
        inputFormatters: [FilteringTextInputFormatter.digitsOnly],
        decoration: const InputDecoration(counterText: '', border: InputBorder.none),
        style: TextStyle(
          fontSize: 22, fontWeight: FontWeight.w800,
          color: hasFocus ? kPurple : kDarkBg,
        ),
        onChanged: (v) => _onDigitChanged(index, v),
      ),
    );
  }
}
