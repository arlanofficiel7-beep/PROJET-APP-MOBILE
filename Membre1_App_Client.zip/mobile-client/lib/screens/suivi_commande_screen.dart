import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:http/http.dart' as http;
import '../models/commande.dart';
import '../services/commande_service.dart';
import '../config/constantes.dart';
import '../theme/app_theme.dart';

bool _horsGabon(double lat, double lng) =>
    lat < -4 || lat > 4 || lng < 8 || lng > 15;

class SuiviCommandeScreen extends StatefulWidget {
  final Commande commande;
  const SuiviCommandeScreen({super.key, required this.commande});

  @override
  State<SuiviCommandeScreen> createState() => _SuiviCommandeScreenState();
}

class _SuiviCommandeScreenState extends State<SuiviCommandeScreen> {
  final CommandeService _service = CommandeService();
  final MapController _mapController = MapController();

  LatLng? _positionLivreur;
  List<LatLng> _routeComplete  = [];
  List<LatLng> _routeParcourue = [];
  List<LatLng> _routeRestante  = [];
  Timer? _timer;
  bool _enCours = false;
  bool _aNote   = false;

  final List<Map<String, dynamic>> _etapes = [
    {'statut': 'en_attente',     'label': 'Commande reçue',  'icone': Icons.receipt_rounded},
    {'statut': 'confirmee',      'label': 'Confirmée',        'icone': Icons.check_circle_rounded},
    {'statut': 'en_preparation', 'label': 'En préparation',   'icone': Icons.restaurant_rounded},
    {'statut': 'en_livraison',   'label': 'En livraison',     'icone': Icons.delivery_dining_rounded},
    {'statut': 'livree',         'label': 'Livrée',           'icone': Icons.home_rounded},
  ];

  @override
  void initState() {
    super.initState();
    _initialiserRoute();
    if (widget.commande.statut == 'en_livraison') {
      _mettreAJourPosition();
      _timer = Timer.periodic(
          const Duration(seconds: 10), (_) => _mettreAJourPosition());
    }
    if (widget.commande.statut == 'livree' &&
        widget.commande.noteLivreurParClient == null &&
        widget.commande.livreurId != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _ouvrirDialogNotation();
      });
    }
  }

  void _initialiserRoute() {
    final lat = widget.commande.latLivraison;
    final lng = widget.commande.lngLivraison;
    if (lat == null || lng == null) return;
    final dest = LatLng(lat, lng);
    setState(() {
      _routeComplete  = [Entrepot.position, dest];
      _routeRestante  = [Entrepot.position, dest];
      _routeParcourue = [];
    });
    _chargerOSRM(dest);
  }

  Future<void> _chargerOSRM(LatLng dest) async {
    try {
      final d = Entrepot.position;
      final url =
          'https://router.project-osrm.org/route/v1/driving/'
          '${d.longitude},${d.latitude};'
          '${dest.longitude},${dest.latitude}'
          '?overview=full&geometries=geojson';
      final r = await http.get(Uri.parse(url)).timeout(const Duration(seconds: 8));
      if (r.statusCode != 200) return;
      final data = jsonDecode(r.body);
      final coords = data['routes'][0]['geometry']['coordinates'] as List;
      final pts = coords
          .map<LatLng>((c) => LatLng(c[1].toDouble(), c[0].toDouble()))
          .toList();
      if (!mounted || pts.length < 2) return;
      setState(() {
        _routeComplete = pts;
        _routeRestante = List.from(pts);
        _routeParcourue = [];
      });
      if (_positionLivreur != null) _diviserRoute(_positionLivreur!);
    } catch (_) {}
  }

  int _indexPlusProche(LatLng pos) {
    if (_routeComplete.isEmpty) return 0;
    double minD = double.infinity;
    int minI = 0;
    for (int i = 0; i < _routeComplete.length; i++) {
      final dx = _routeComplete[i].latitude  - pos.latitude;
      final dy = _routeComplete[i].longitude - pos.longitude;
      final d  = dx * dx + dy * dy;
      if (d < minD) { minD = d; minI = i; }
    }
    return minI;
  }

  void _diviserRoute(LatLng pos) {
    if (_routeComplete.length < 2) return;
    final idx = _indexPlusProche(pos);
    if (!mounted) return;
    setState(() {
      _routeParcourue = _routeComplete.sublist(0, idx + 1);
      _routeRestante  = _routeComplete.sublist(idx);
    });
  }

  Future<void> _mettreAJourPosition() async {
    try {
      final pos = await _service.getPositionLivreur(widget.commande.id);
      if (pos != null && mounted) {
        final lat = (pos['latitude'] as num).toDouble();
        final lng = (pos['longitude'] as num).toDouble();
        if (_horsGabon(lat, lng)) return;
        final p = LatLng(lat, lng);
        setState(() => _positionLivreur = p);
        _diviserRoute(p);
        _mapController.move(p, _mapController.camera.zoom);
      }
    } catch (_) {}
  }

  Future<void> _ouvrirDialogNotation() async {
    int stars = 0;
    final note = await showDialog<int>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          backgroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: const Text('Notez votre livreur',
              style: TextStyle(fontWeight: FontWeight.w800, color: kDarkBg)),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            if (widget.commande.livreurNom != null)
              Text(widget.commande.livreurNom!,
                  style: const TextStyle(color: kTextMuted, fontSize: 14)),
            const SizedBox(height: 18),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(5, (i) => GestureDetector(
                onTap: () => setS(() => stars = i + 1),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: Icon(
                    i < stars ? Icons.star_rounded : Icons.star_outline_rounded,
                    color: Colors.amber, size: 46,
                  ),
                ),
              )),
            ),
            const SizedBox(height: 10),
            Text(
              stars == 0 ? 'Appuyez sur une étoile' :
              stars == 1 ? '😞 Très mauvais' :
              stars == 2 ? '😕 Mauvais' :
              stars == 3 ? '😐 Correct' :
              stars == 4 ? '😊 Bien' : '🤩 Excellent !',
              style: TextStyle(
                  color: stars > 0 ? kPurple : kTextMuted,
                  fontWeight: FontWeight.w600),
            ),
          ]),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, null),
              child: const Text('Plus tard', style: TextStyle(color: kTextMuted)),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                  backgroundColor: kPurple, foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
              onPressed: stars == 0 ? null : () => Navigator.pop(ctx, stars),
              child: const Text('Envoyer'),
            ),
          ],
        ),
      ),
    );

    if (note == null || !mounted) return;
    try {
      await _service.noterCommande(widget.commande.id, 'livreur', note);
      setState(() => _aNote = true);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Merci pour votre note ! ⭐'),
        backgroundColor: kGreen,
      ));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString()), backgroundColor: Colors.red));
    }
  }

  Future<void> _annulerCommande() async {
    final raisons = [
      'Trop de temps d\'attente',
      'Erreur dans la commande',
      'Changement d\'avis',
      'Produit non disponible',
      'Autre',
    ];
    String? raison;
    final autreCtrl = TextEditingController();

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, set) => AlertDialog(
          backgroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: const Text('Annuler la commande',
              style: TextStyle(fontWeight: FontWeight.w800, color: kDarkBg)),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Motif de l\'annulation :',
                    style: TextStyle(fontWeight: FontWeight.w700, color: kDarkBg, fontSize: 14)),
                const SizedBox(height: 8),
                ...raisons.map((r) => RadioListTile<String>(
                      value: r, groupValue: raison, dense: true,
                      activeColor: kPurple,
                      title: Text(r, style: const TextStyle(fontSize: 14, color: kDarkBg)),
                      onChanged: (v) => set(() => raison = v),
                    )),
                if (raison == 'Autre') ...[
                  const SizedBox(height: 8),
                  TextField(
                    controller: autreCtrl, maxLines: 2,
                    decoration: InputDecoration(
                      hintText: 'Précisez…',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                      focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                          borderSide: const BorderSide(color: kPurple, width: 2)),
                      contentPadding: const EdgeInsets.all(10),
                    ),
                  ),
                ],
              ],
            ),
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('Retour', style: TextStyle(color: kTextMuted))),
            TextButton(
              onPressed: raison == null ? null : () => Navigator.pop(ctx, true),
              child: const Text('Confirmer', style: TextStyle(color: Colors.red, fontWeight: FontWeight.w700)),
            ),
          ],
        ),
      ),
    );

    if (confirmed != true || raison == null) return;
    final motif = raison == 'Autre'
        ? (autreCtrl.text.trim().isEmpty ? 'Autre' : autreCtrl.text.trim())
        : raison!;

    setState(() => _enCours = true);
    try {
      await _service.annulerCommande(widget.commande.id, motif);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Commande annulée'), backgroundColor: Colors.red));
      Navigator.pop(context);
    } catch (e) {
      setState(() => _enCours = false);
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString()), backgroundColor: Colors.red));
    }
  }

  void _zoom(double delta) {
    _mapController.move(
        _mapController.camera.center, _mapController.camera.zoom + delta);
  }

  int get _etapeActuelle {
    const ordre = ['en_attente', 'confirmee', 'en_preparation', 'en_livraison', 'livree'];
    return ordre.indexOf(widget.commande.statut);
  }

  bool get _peutAnnuler => !['livree', 'annulee'].contains(widget.commande.statut);

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final hasDestination = widget.commande.latLivraison != null;
    final showMap = ['confirmee', 'en_preparation', 'en_livraison']
        .contains(widget.commande.statut);

    return Scaffold(
      backgroundColor: kBgLight,
      appBar: AppBar(
        backgroundColor: kDarkBg,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded, color: kTextWhite),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          '#${widget.commande.id.substring(0, 8).toUpperCase()}',
          style: const TextStyle(
              color: kTextWhite, fontWeight: FontWeight.w800,
              fontSize: 16, letterSpacing: .5),
        ),
        actions: [
          if (_peutAnnuler && !_enCours)
            IconButton(
              icon: const Icon(Icons.cancel_outlined, color: Colors.red),
              tooltip: 'Annuler',
              onPressed: _annulerCommande,
            ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ── Carte ───────────────────────────────────────────────────
            if (showMap)
              SizedBox(
                height: 280,
                child: Stack(
                  children: [
                    FlutterMap(
                      mapController: _mapController,
                      options: MapOptions(
                        initialCenter: Entrepot.position,
                        initialZoom: 13,
                      ),
                      children: [
                        TileLayer(
                          urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                          userAgentPackageName: 'com.livraison.livraison_client',
                        ),
                        PolylineLayer(polylines: [
                          if (_routeRestante.length >= 2)
                            Polyline(
                              points: _routeRestante,
                              color: Colors.grey.shade400, strokeWidth: 4,
                            ),
                          if (_routeParcourue.length >= 2)
                            Polyline(
                              points: _routeParcourue,
                              color: kPurple, strokeWidth: 4,
                            ),
                        ]),
                        MarkerLayer(markers: [
                          Marker(
                            point: Entrepot.position, width: 44, height: 44,
                            child: _Pin(color: kDarkCard, icon: Icons.warehouse_rounded),
                          ),
                          if (hasDestination)
                            Marker(
                              point: LatLng(widget.commande.latLivraison!, widget.commande.lngLivraison!),
                              width: 44, height: 44,
                              child: _Pin(color: kGreen, icon: Icons.home_rounded),
                            ),
                          if (_positionLivreur != null)
                            Marker(
                              point: _positionLivreur!, width: 44, height: 44,
                              child: _Pin(color: kPurple, icon: Icons.delivery_dining_rounded),
                            ),
                        ]),
                      ],
                    ),

                    Positioned(top: 10, left: 10,
                      child: _Badge(icone: Icons.warehouse_rounded, label: 'Départ', couleur: kDarkBg)),
                    if (hasDestination)
                      Positioned(top: 10, right: 10,
                        child: _Badge(icone: Icons.home_rounded,
                            label: widget.commande.adresseLivraison, couleur: kGreen)),

                    Positioned(right: 10, bottom: 10,
                      child: Column(children: [
                        _ZoomBtn(icon: Icons.add_rounded, onTap: () => _zoom(1)),
                        const SizedBox(height: 6),
                        _ZoomBtn(icon: Icons.remove_rounded, onTap: () => _zoom(-1)),
                      ])),

                    if (widget.commande.statut == 'en_livraison' && _positionLivreur == null)
                      Positioned(bottom: 10, left: 0, right: 60,
                        child: Center(
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                            decoration: BoxDecoration(
                                color: kPurple.withOpacity(0.9),
                                borderRadius: BorderRadius.circular(20)),
                            child: const Row(mainAxisSize: MainAxisSize.min, children: [
                              SizedBox(width: 12, height: 12,
                                child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2)),
                              SizedBox(width: 8),
                              Text('Localisation livreur…',
                                  style: TextStyle(color: Colors.white, fontSize: 12)),
                            ]),
                          ),
                        )),
                  ],
                ),
              ),

            // ── Progression ──────────────────────────────────────────────
            Container(
              margin: const EdgeInsets.fromLTRB(16, 16, 16, 0),
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [BoxShadow(
                  color: kPurple.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, 3),
                )],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Suivi de la commande',
                          style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: kDarkBg)),
                      if (_peutAnnuler)
                        GestureDetector(
                          onTap: _enCours ? null : _annulerCommande,
                          child: const Row(mainAxisSize: MainAxisSize.min, children: [
                            Icon(Icons.cancel_outlined, color: Colors.red, size: 14),
                            SizedBox(width: 4),
                            Text('Annuler', style: TextStyle(color: Colors.red, fontSize: 12, fontWeight: FontWeight.w700)),
                          ]),
                        ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  ..._etapes.asMap().entries.map((entry) {
                    final i     = entry.key;
                    final etape = entry.value;
                    final passe  = i <= _etapeActuelle;
                    final actuel = i == _etapeActuelle;
                    return Row(children: [
                      Column(children: [
                        Container(
                          width: 38, height: 38,
                          decoration: BoxDecoration(
                            gradient: passe
                                ? const LinearGradient(colors: [kPurple, kPurpleDark])
                                : null,
                            color: passe ? null : Colors.grey.shade100,
                            shape: BoxShape.circle,
                            boxShadow: passe && actuel ? [BoxShadow(
                              color: kPurple.withOpacity(0.35),
                              blurRadius: 8, offset: const Offset(0, 3),
                            )] : null,
                          ),
                          child: Icon(etape['icone'] as IconData,
                              color: passe ? Colors.white : Colors.grey.shade400,
                              size: 18),
                        ),
                        if (i < _etapes.length - 1)
                          Container(
                              width: 2, height: 28,
                              color: passe ? kPurple : Colors.grey.shade200),
                      ]),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.only(bottom: 28),
                          child: Text(
                            etape['label'] as String,
                            style: TextStyle(
                              fontWeight: actuel ? FontWeight.w800 : FontWeight.w500,
                              color: passe ? kDarkBg : Colors.grey.shade400,
                              fontSize: actuel ? 15 : 13,
                            ),
                          ),
                        ),
                      ),
                      if (actuel)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 28, right: 4),
                          child: Container(
                            width: 8, height: 8,
                            decoration: BoxDecoration(color: kPurple, shape: BoxShape.circle,
                              boxShadow: [BoxShadow(color: kPurple.withOpacity(0.4), blurRadius: 6)],
                            ),
                          ),
                        ),
                    ]);
                  }),
                ],
              ),
            ),

            // ── Note du livreur ──────────────────────────────────────────
            if (widget.commande.livreurId != null && widget.commande.livreurNoteMoyenne != null)
              Container(
                margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                decoration: BoxDecoration(
                  color: Colors.amber.withOpacity(0.08),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.amber.withOpacity(0.3)),
                ),
                child: Row(children: [
                  const Icon(Icons.star_rounded, color: Colors.amber, size: 20),
                  const SizedBox(width: 6),
                  Text(widget.commande.livreurNoteMoyenne!.toStringAsFixed(1),
                      style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15, color: kDarkBg)),
                  const SizedBox(width: 4),
                  Text('(${widget.commande.livreurNbNotes} avis)',
                      style: const TextStyle(color: kTextMuted, fontSize: 13)),
                  const Spacer(),
                  Text(widget.commande.livreurNom ?? 'Livreur',
                      style: const TextStyle(color: kTextMuted, fontSize: 13)),
                ]),
              ),

            // ── Section notation client ───────────────────────────────────
            if (widget.commande.statut == 'livree' &&
                widget.commande.livreurId != null &&
                widget.commande.noteLivreurParClient == null &&
                !_aNote)
              Container(
                margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [kPurple.withOpacity(0.08), kPurpleLight.withOpacity(0.06)],
                  ),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: kPurple.withOpacity(0.2)),
                ),
                child: Column(children: [
                  const Row(children: [
                    Icon(Icons.star_border_rounded, color: kPurple),
                    SizedBox(width: 8),
                    Text('Comment s\'est passée la livraison ?',
                        style: TextStyle(fontWeight: FontWeight.w700, color: kDarkBg)),
                  ]),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity, height: 46,
                    child: ElevatedButton(
                      onPressed: _ouvrirDialogNotation,
                      style: ElevatedButton.styleFrom(
                          backgroundColor: kPurple,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                      child: const Text('Notez votre livreur ⭐',
                          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                    ),
                  ),
                ]),
              ),

            if (_aNote || (widget.commande.statut == 'livree' && widget.commande.noteLivreurParClient != null))
              Container(
                margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: kGreen.withOpacity(0.08),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: kGreen.withOpacity(0.3)),
                ),
                child: Row(children: [
                  const Icon(Icons.check_circle_rounded, color: kGreen, size: 18),
                  const SizedBox(width: 8),
                  Text(
                    _aNote
                        ? 'Merci pour votre note !'
                        : 'Vous avez noté ${widget.commande.noteLivreurParClient} étoile${(widget.commande.noteLivreurParClient ?? 1) > 1 ? 's' : ''}',
                    style: const TextStyle(color: kGreen, fontWeight: FontWeight.w600),
                  ),
                  if (!_aNote && widget.commande.noteLivreurParClient != null) ...[
                    const Spacer(),
                    Row(
                      children: List.generate(widget.commande.noteLivreurParClient!, (i) =>
                        const Icon(Icons.star_rounded, color: Colors.amber, size: 16)),
                    ),
                  ],
                ]),
              ),

            // ── Articles ─────────────────────────────────────────────────
            Container(
              margin: const EdgeInsets.fromLTRB(16, 12, 16, 24),
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [BoxShadow(
                  color: kPurple.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, 3),
                )],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Articles commandés',
                      style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: kDarkBg)),
                  const SizedBox(height: 14),
                  ...widget.commande.articles.map((a) => Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(children: [
                          Container(
                            width: 6, height: 6,
                            decoration: const BoxDecoration(color: kPurple, shape: BoxShape.circle),
                          ),
                          const SizedBox(width: 10),
                          Text('${a.quantite}× ${a.nom}',
                              style: const TextStyle(color: kDarkBg, fontSize: 14)),
                        ]),
                        Text(
                          '${(a.prix * a.quantite).toStringAsFixed(0)} FCFA',
                          style: const TextStyle(fontWeight: FontWeight.w700, color: kDarkBg, fontSize: 14),
                        ),
                      ],
                    ),
                  )),
                  const SizedBox(height: 8),
                  Divider(color: Colors.grey.shade200),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Total',
                          style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15, color: kDarkBg)),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            widget.commande.total.toStringAsFixed(0),
                            style: const TextStyle(
                                fontWeight: FontWeight.w900, fontSize: 22, color: kPurple),
                          ),
                          const Text('FCFA',
                              style: TextStyle(color: kTextMuted, fontSize: 10, fontWeight: FontWeight.w600)),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Row(children: [
                    const Icon(Icons.location_on_outlined, size: 14, color: kTextMuted),
                    const SizedBox(width: 4),
                    Text(widget.commande.adresseLivraison,
                        style: const TextStyle(color: kTextMuted, fontSize: 13)),
                  ]),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Helpers map ───────────────────────────────────────────────────────────────
class _Pin extends StatelessWidget {
  final Color color;
  final IconData icon;
  const _Pin({required this.color, required this.icon});

  @override
  Widget build(BuildContext context) => Container(
    decoration: BoxDecoration(
      color: color, shape: BoxShape.circle,
      border: Border.all(color: Colors.white, width: 2.5),
      boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 6)],
    ),
    child: Icon(icon, color: Colors.white, size: 20),
  );
}

class _Badge extends StatelessWidget {
  final IconData icone;
  final String label;
  final Color couleur;
  const _Badge({required this.icone, required this.label, required this.couleur});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
    decoration: BoxDecoration(
      color: couleur.withOpacity(0.92),
      borderRadius: BorderRadius.circular(20),
      boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 4)],
    ),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      Icon(icone, color: Colors.white, size: 12),
      const SizedBox(width: 4),
      Text(label,
          style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600),
          maxLines: 1, overflow: TextOverflow.ellipsis),
    ]),
  );
}

class _ZoomBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _ZoomBtn({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      width: 38, height: 38,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 4)],
      ),
      child: Icon(icon, size: 20, color: kDarkBg),
    ),
  );
}
