import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/produit.dart';
import '../services/produit_service.dart';
import '../providers/panier_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/produit_card.dart';
import 'produit_detail_screen.dart';
import 'panier_screen.dart';

class CatalogueScreen extends StatefulWidget {
  const CatalogueScreen({super.key});
  @override
  State<CatalogueScreen> createState() => _CatalogueScreenState();
}

class _CatalogueScreenState extends State<CatalogueScreen> {
  final ProduitService _service = ProduitService();
  List<Produit> _produits = [];
  List<Produit> _filtres  = [];
  bool _chargement = true;
  String? _erreur;
  String _cat = 'Tous';
  String _recherche = '';
  final _searchCtrl = TextEditingController();

  static const _cats = [
    'Tous', 'Alimentation', 'Boissons',
    'Hygiène & Beauté', 'Maison & Entretien', 'Électronique',
  ];

  static const _catIcons = {
    'Tous':              Icons.apps_rounded,
    'Alimentation':      Icons.restaurant_rounded,
    'Boissons':          Icons.local_drink_rounded,
    'Hygiène & Beauté':  Icons.spa_rounded,
    'Maison & Entretien':Icons.home_rounded,
    'Électronique':      Icons.devices_rounded,
  };

  @override
  void initState() {
    super.initState();
    _charger();
    _searchCtrl.addListener(() {
      setState(() { _recherche = _searchCtrl.text.toLowerCase(); });
      _filtrer();
    });
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _charger() async {
    setState(() { _chargement = true; _erreur = null; });
    try {
      final p = await _service.listerProduits();
      setState(() { _produits = p; _chargement = false; });
      _filtrer();
    } catch (e) {
      setState(() { _erreur = e.toString(); _chargement = false; });
    }
  }

  void _filtrer() {
    setState(() {
      _filtres = _produits.where((p) {
        final matchCat = _cat == 'Tous' || p.categorie == _cat;
        final matchSearch = _recherche.isEmpty ||
            p.nom.toLowerCase().contains(_recherche) ||
            p.description.toLowerCase().contains(_recherche);
        return matchCat && matchSearch;
      }).toList();
    });
  }

  void _selectCat(String cat) {
    setState(() => _cat = cat);
    _filtrer();
  }

  @override
  Widget build(BuildContext context) {
    final panier = context.watch<PanierProvider>();

    return Scaffold(
      backgroundColor: kBgLight,
      body: CustomScrollView(
        slivers: [
          // ── AppBar dark sticky ─────────────────────────────────────
          SliverAppBar(
            backgroundColor: kDarkBg,
            pinned: true,
            expandedHeight: 130,
            elevation: 0,
            flexibleSpace: FlexibleSpaceBar(
              titlePadding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
              title: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  RichText(
                    text: const TextSpan(children: [
                      TextSpan(text: 'L', style: TextStyle(
                        color: kTextWhite, fontSize: 22, fontWeight: FontWeight.w900, letterSpacing: -1)),
                      TextSpan(text: 'X', style: TextStyle(
                        color: kPurple, fontSize: 22, fontWeight: FontWeight.w900, letterSpacing: -1)),
                      TextSpan(text: '  Catalogue', style: TextStyle(
                        color: kTextWhite, fontSize: 16, fontWeight: FontWeight.w600)),
                    ]),
                  ),
                ],
              ),
              background: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Color(0xFF1A0040), kDarkBg],
                  ),
                ),
              ),
            ),
            actions: [
              // Icône panier avec badge
              Padding(
                padding: const EdgeInsets.only(right: 12),
                child: Stack(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.shopping_bag_rounded, color: kTextWhite),
                      onPressed: () => Navigator.push(context,
                          MaterialPageRoute(builder: (_) => const PanierScreen())),
                    ),
                    if (panier.nombreArticles > 0)
                      Positioned(
                        right: 6, top: 6,
                        child: Container(
                          width: 18, height: 18,
                          decoration: BoxDecoration(
                            color: kPurple,
                            shape: BoxShape.circle,
                            border: Border.all(color: kDarkBg, width: 1.5),
                          ),
                          child: Center(
                            child: Text(
                              '${panier.nombreArticles}',
                              style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w800),
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ],
          ),

          SliverToBoxAdapter(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 16),

                // ── Barre de recherche ──────────────────────────────────
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: TextField(
                    controller: _searchCtrl,
                    style: const TextStyle(color: kDarkBg),
                    decoration: InputDecoration(
                      hintText: 'Rechercher un produit...',
                      hintStyle: const TextStyle(color: kTextMuted),
                      prefixIcon: const Icon(Icons.search_rounded, color: kPurple),
                      filled: true,
                      fillColor: kCardBg,
                      contentPadding: const EdgeInsets.symmetric(vertical: 14),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                        borderSide: BorderSide.none,
                      ),
                      suffixIcon: _recherche.isNotEmpty
                          ? IconButton(
                              icon: const Icon(Icons.close_rounded, color: kTextMuted),
                              onPressed: () { _searchCtrl.clear(); _filtrer(); },
                            )
                          : null,
                    ),
                  ),
                ),
                const SizedBox(height: 16),

                // ── Filtres catégories ──────────────────────────────────
                SizedBox(
                  height: 44,
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: _cats.length,
                    itemBuilder: (_, i) {
                      final selected = _cats[i] == _cat;
                      return GestureDetector(
                        onTap: () => _selectCat(_cats[i]),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          margin: const EdgeInsets.only(right: 10),
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                          decoration: BoxDecoration(
                            gradient: selected
                                ? const LinearGradient(colors: [kPurple, kPurpleDark])
                                : null,
                            color: selected ? null : kCardBg,
                            borderRadius: BorderRadius.circular(22),
                            boxShadow: selected
                                ? [BoxShadow(color: kPurple.withOpacity(0.3), blurRadius: 8, offset: const Offset(0, 3))]
                                : null,
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(_catIcons[_cats[i]] ?? Icons.category_rounded,
                                size: 15,
                                color: selected ? Colors.white : kTextMuted),
                              const SizedBox(width: 6),
                              Text(
                                _cats[i],
                                style: TextStyle(
                                  color: selected ? Colors.white : kTextMuted,
                                  fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                                  fontSize: 13,
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 16),

                // Compteur résultats
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Text(
                    _chargement ? '' : '${_filtres.length} produit${_filtres.length > 1 ? 's' : ''}',
                    style: const TextStyle(color: kTextMuted, fontSize: 12, fontWeight: FontWeight.w600),
                  ),
                ),
                const SizedBox(height: 10),
              ],
            ),
          ),

          // ── Grille produits ─────────────────────────────────────────
          if (_chargement)
            const SliverFillRemaining(
              child: Center(child: CircularProgressIndicator(color: kPurple)),
            )
          else if (_erreur != null)
            SliverFillRemaining(
              child: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.wifi_off_rounded, size: 60, color: kPurple.withOpacity(0.4)),
                    const SizedBox(height: 12),
                    const Text('Connexion impossible', style: TextStyle(color: kDarkBg, fontWeight: FontWeight.w700)),
                    const SizedBox(height: 4),
                    const Text('Vérifiez que le backend est démarré', style: TextStyle(color: kTextMuted, fontSize: 13)),
                    const SizedBox(height: 16),
                    ElevatedButton.icon(
                      onPressed: _charger,
                      icon: const Icon(Icons.refresh_rounded, color: Colors.white),
                      label: const Text('Réessayer', style: TextStyle(color: Colors.white)),
                    ),
                  ],
                ),
              ),
            )
          else if (_filtres.isEmpty)
            const SliverFillRemaining(
              child: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.search_off_rounded, size: 56, color: kPurpleLight),
                    SizedBox(height: 12),
                    Text('Aucun produit trouvé', style: TextStyle(color: kDarkBg, fontWeight: FontWeight.w700)),
                  ],
                ),
              ),
            )
          else
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
              sliver: SliverGrid(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  childAspectRatio: 0.72,
                  crossAxisSpacing: 14,
                  mainAxisSpacing: 14,
                ),
                delegate: SliverChildBuilderDelegate(
                  (_, i) => ProduitCard(
                    produit: _filtres[i],
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => ProduitDetailScreen(produit: _filtres[i]))),
                    onAjouter: () {
                      context.read<PanierProvider>().ajouter(_filtres[i]);
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        content: Row(children: [
                          const Icon(Icons.check_circle_rounded, color: kPurpleLight, size: 18),
                          const SizedBox(width: 8),
                          Expanded(child: Text('${_filtres[i].nom} ajouté !')),
                        ]),
                        duration: const Duration(seconds: 1),
                      ));
                    },
                  ),
                  childCount: _filtres.length,
                ),
              ),
            ),
        ],
      ),
    );
  }
}
