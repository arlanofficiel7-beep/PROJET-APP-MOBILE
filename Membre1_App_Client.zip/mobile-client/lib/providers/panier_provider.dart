import 'package:flutter/material.dart';
import '../models/produit.dart';
import '../models/commande.dart';

class ArticlePanier {
  final Produit produit;
  int quantite;

  ArticlePanier({required this.produit, this.quantite = 1});
}

class PanierProvider extends ChangeNotifier {
  final List<ArticlePanier> _articles = [];

  List<ArticlePanier> get articles => _articles;

  int get nombreArticles => _articles.fold(0, (sum, a) => sum + a.quantite);

  double get total => _articles.fold(0, (sum, a) => sum + a.produit.prix * a.quantite);

  bool get estVide => _articles.isEmpty;

  void ajouter(Produit produit) {
    final index = _articles.indexWhere((a) => a.produit.id == produit.id);
    if (index >= 0) {
      _articles[index].quantite++;
    } else {
      _articles.add(ArticlePanier(produit: produit));
    }
    notifyListeners();
  }

  void retirer(String produitId) {
    final index = _articles.indexWhere((a) => a.produit.id == produitId);
    if (index >= 0) {
      if (_articles[index].quantite > 1) {
        _articles[index].quantite--;
      } else {
        _articles.removeAt(index);
      }
    }
    notifyListeners();
  }

  void supprimer(String produitId) {
    _articles.removeWhere((a) => a.produit.id == produitId);
    notifyListeners();
  }

  void vider() {
    _articles.clear();
    notifyListeners();
  }

  List<ArticleCommande> toArticlesCommande() {
    return _articles.map((a) => ArticleCommande(
      produitId: a.produit.id,
      nom: a.produit.nom,
      prix: a.produit.prix,
      quantite: a.quantite,
      imageUrl: a.produit.imageUrl,
    )).toList();
  }
}
