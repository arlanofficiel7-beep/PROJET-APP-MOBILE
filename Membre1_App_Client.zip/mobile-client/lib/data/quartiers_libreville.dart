import 'package:latlong2/latlong.dart';

class QuartierLibreville {
  final String nom;
  final double latitude;
  final double longitude;

  const QuartierLibreville({
    required this.nom,
    required this.latitude,
    required this.longitude,
  });

  LatLng get position => LatLng(latitude, longitude);
}

const List<QuartierLibreville> quartiersLibreville = [
  QuartierLibreville(nom: 'Centre-Ville',          latitude: 0.3924, longitude: 9.4536),
  QuartierLibreville(nom: 'Batterie IV',            latitude: 0.4021, longitude: 9.4449),
  QuartierLibreville(nom: 'Nombakélé',              latitude: 0.3988, longitude: 9.4412),
  QuartierLibreville(nom: 'Louis',                  latitude: 0.3979, longitude: 9.4534),
  QuartierLibreville(nom: 'Plaine Orety',           latitude: 0.4102, longitude: 9.4234),
  QuartierLibreville(nom: 'Nzeng-Ayong',            latitude: 0.3802, longitude: 9.4398),
  QuartierLibreville(nom: 'Okolassi',               latitude: 0.3756, longitude: 9.4334),
  QuartierLibreville(nom: 'Awendjé',                latitude: 0.3811, longitude: 9.4302),
  QuartierLibreville(nom: 'Charbonnages',           latitude: 0.3992, longitude: 9.4489),
  QuartierLibreville(nom: 'Gros Bouquet',           latitude: 0.3867, longitude: 9.4456),
  QuartierLibreville(nom: 'Alibandeng',             latitude: 0.3924, longitude: 9.4456),
  QuartierLibreville(nom: 'Sotega',                 latitude: 0.4089, longitude: 9.4561),
  QuartierLibreville(nom: 'IAI-Gabon',              latitude: 0.4167, longitude: 9.4289),
  QuartierLibreville(nom: 'PK5',                    latitude: 0.4023, longitude: 9.4599),
  QuartierLibreville(nom: 'PK6',                    latitude: 0.3993, longitude: 9.4687),
  QuartierLibreville(nom: 'PK7',                    latitude: 0.3961, longitude: 9.4776),
  QuartierLibreville(nom: 'PK8',                    latitude: 0.3929, longitude: 9.4864),
  QuartierLibreville(nom: 'PK9',                    latitude: 0.3897, longitude: 9.4953),
  QuartierLibreville(nom: 'PK10',                   latitude: 0.3865, longitude: 9.5042),
  QuartierLibreville(nom: 'PK12',                   latitude: 0.3801, longitude: 9.5220),
  QuartierLibreville(nom: 'Angondjé',               latitude: 0.4388, longitude: 9.4134),
  QuartierLibreville(nom: 'Akanda',                 latitude: 0.4801, longitude: 9.4512),
  QuartierLibreville(nom: 'Owendo',                 latitude: 0.3044, longitude: 9.5034),
  QuartierLibreville(nom: 'Ntoum',                  latitude: 0.3893, longitude: 9.7634),
  QuartierLibreville(nom: 'Mont-Bouët',             latitude: 0.3978, longitude: 9.4601),
  QuartierLibreville(nom: 'Cocotiers',              latitude: 0.4012, longitude: 9.4478),
];
