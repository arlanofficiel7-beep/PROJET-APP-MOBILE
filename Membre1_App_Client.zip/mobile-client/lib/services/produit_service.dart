import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config/api_config.dart';
import '../models/produit.dart';

class ProduitService {
  Future<List<Produit>> listerProduits({String? categorie}) async {
    final url = categorie != null
        ? '${ApiConfig.produits}?categorie=$categorie'
        : ApiConfig.produits;

    final response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      final List data = jsonDecode(response.body);
      return data.map((p) => Produit.fromJson(p)).toList();
    }
    throw Exception('Impossible de charger les produits.');
  }

  Future<Produit> getProduit(String id) async {
    final response = await http.get(Uri.parse('${ApiConfig.produits}/$id'));
    if (response.statusCode == 200) {
      return Produit.fromJson(jsonDecode(response.body));
    }
    throw Exception('Produit introuvable.');
  }
}
