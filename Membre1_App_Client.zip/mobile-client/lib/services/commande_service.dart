import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config/api_config.dart';
import '../models/commande.dart';
import 'auth_service.dart';

class CommandeService {
  final AuthService _auth = AuthService();

  Future<Map<String, String>> _headers() async {
    final token = await _auth.getToken();
    return {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };
  }

  Future<Commande> creerCommande({
    required List<ArticleCommande> articles,
    required String adresseLivraison,
    double? latLivraison,
    double? lngLivraison,
    String? audioBase64,
    String? photoRepere,
  }) async {
    final body = <String, dynamic>{
      'articles': articles.map((a) => a.toJson()).toList(),
      'adresseLivraison': adresseLivraison,
    };
    if (latLivraison != null) body['latLivraison'] = latLivraison;
    if (lngLivraison != null) body['lngLivraison'] = lngLivraison;
    if (audioBase64 != null) body['audioBase64'] = audioBase64;
    if (photoRepere != null) body['photoRepere'] = photoRepere;

    final response = await http.post(
      Uri.parse(ApiConfig.commandes),
      headers: await _headers(),
      body: jsonEncode(body),
    );
    final data = jsonDecode(response.body);
    if (response.statusCode == 201) {
      return Commande.fromJson(data['commande']);
    }
    throw Exception(data['message'] ?? 'Erreur lors de la commande.');
  }

  Future<List<Commande>> mesCommandes() async {
    final response = await http.get(
      Uri.parse('${ApiConfig.commandes}/mes-commandes'),
      headers: await _headers(),
    );
    if (response.statusCode == 200) {
      final List data = jsonDecode(response.body);
      return data.map((c) => Commande.fromJson(c)).toList();
    }
    throw Exception('Impossible de charger vos commandes.');
  }

  Future<Commande> getCommande(String id) async {
    final response = await http.get(
      Uri.parse('${ApiConfig.commandes}/$id'),
      headers: await _headers(),
    );
    if (response.statusCode == 200) {
      return Commande.fromJson(jsonDecode(response.body));
    }
    throw Exception('Commande introuvable.');
  }

  Future<void> annulerCommande(String commandeId, String motif) async {
    final response = await http.put(
      Uri.parse('${ApiConfig.commandes}/$commandeId/annuler'),
      headers: await _headers(),
      body: jsonEncode({'motifAnnulation': motif}),
    );
    if (response.statusCode != 200) {
      final data = jsonDecode(response.body);
      throw Exception(data['message'] ?? 'Impossible d\'annuler.');
    }
  }

  /// Soumettre une note (cible='livreur' pour le client, 'client' pour le livreur)
  Future<void> noterCommande(String commandeId, String cible, int note) async {
    final response = await http.post(
      Uri.parse('${ApiConfig.commandes}/$commandeId/noter'),
      headers: await _headers(),
      body: jsonEncode({'cible': cible, 'note': note}),
    );
    if (response.statusCode != 200) {
      final data = jsonDecode(response.body);
      throw Exception(data['message'] ?? 'Erreur lors de la notation.');
    }
  }

  Future<Map<String, dynamic>?> getPositionLivreur(String commandeId) async {
    final response = await http.get(
      Uri.parse('${ApiConfig.livreurs}/position/$commandeId'),
      headers: await _headers(),
    );
    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    }
    return null;
  }
}
