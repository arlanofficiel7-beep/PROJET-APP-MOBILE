import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../config/api_config.dart';

class AuthService {
  static const _tokenKey = 'jwt_token';
  static const _userKey = 'user_data';

  /// Envoie un code OTP à l'adresse email
  Future<Map<String, dynamic>> envoyerOtp(String email) async {
    final response = await http.post(
      Uri.parse('${ApiConfig.auth}/envoyer-otp'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'email': email}),
    );
    return jsonDecode(response.body) as Map<String, dynamic>;
  }

  /// Vérifie le code OTP saisi par l'utilisateur
  Future<Map<String, dynamic>> verifierOtp(String email, String code) async {
    final response = await http.post(
      Uri.parse('${ApiConfig.auth}/verifier-otp'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'email': email, 'code': code}),
    );
    return {
      ...jsonDecode(response.body) as Map<String, dynamic>,
      'statusCode': response.statusCode,
    };
  }

  Future<Map<String, dynamic>> inscription({
    required String nom,
    required String email,
    required String motDePasse,
    String telephone = '',
  }) async {
    final response = await http.post(
      Uri.parse('${ApiConfig.auth}/register'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'nom': nom,
        'email': email,
        'motDePasse': motDePasse,
        'telephone': telephone,
        'role': 'client',
      }),
    );
    final data = jsonDecode(response.body);
    if (response.statusCode == 201) {
      await _sauvegarderSession(data['token'], data['utilisateur']);
    }
    return data;
  }

  Future<Map<String, dynamic>> connexion({
    required String email,
    required String motDePasse,
  }) async {
    final response = await http.post(
      Uri.parse('${ApiConfig.auth}/login'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'email': email, 'motDePasse': motDePasse}),
    );
    final data = jsonDecode(response.body);
    if (response.statusCode == 200) {
      await _sauvegarderSession(data['token'], data['utilisateur']);
    }
    return data;
  }

  Future<void> _sauvegarderSession(String token, Map<String, dynamic> user) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_tokenKey, token);
    await prefs.setString(_userKey, jsonEncode(user));
  }

  /// Met à jour le profil : nom, téléphone, photo, et/ou mot de passe
  Future<Map<String, dynamic>> mettreAJourProfil({
    String? nom,
    String? telephone,
    String? photoBase64,
    String? motDePasseActuel,
    String? nouveauMotDePasse,
  }) async {
    final token = await getToken();
    final response = await http.put(
      Uri.parse('${ApiConfig.auth}/profil'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
      body: jsonEncode({
        if (nom != null) 'nom': nom,
        if (telephone != null) 'telephone': telephone,
        if (photoBase64 != null) 'photoBase64': photoBase64,
        if (motDePasseActuel != null) 'motDePasseActuel': motDePasseActuel,
        if (nouveauMotDePasse != null) 'nouveauMotDePasse': nouveauMotDePasse,
      }),
    );
    final data = jsonDecode(response.body);
    if (response.statusCode == 200) {
      final user = data['utilisateur'] as Map<String, dynamic>;
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_userKey, jsonEncode({
        'id': user['id'],
        'nom': user['nom'],
        'email': user['email'],
        'telephone': user['telephone'] ?? '',
        'role': user['role'],
        'photoBase64': user['photoBase64'],
      }));
    }
    return data;
  }

  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_tokenKey);
  }

  Future<Map<String, dynamic>?> getUtilisateur() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getString(_userKey);
    if (data == null) return null;
    return jsonDecode(data);
  }

  Future<void> deconnexion() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_tokenKey);
    await prefs.remove(_userKey);
  }

  Future<bool> estConnecte() async {
    final token = await getToken();
    return token != null;
  }

  /// Rafraîchit le profil depuis le serveur et met à jour le cache local.
  /// Retourne les données fraîches, ou null si hors ligne / token invalide.
  Future<Map<String, dynamic>?> rafraichirProfil() async {
    final token = await getToken();
    if (token == null) return null;
    try {
      final response = await http.get(
        Uri.parse('${ApiConfig.auth}/profil'),
        headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer $token'},
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body) as Map<String, dynamic>;
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString(_userKey, jsonEncode({
          'id': data['id'],
          'nom': data['nom'],
          'email': data['email'],
          'telephone': data['telephone'] ?? '',
          'role': data['role'],
          'photoBase64': data['photoBase64'],
          'noteMoyenne': data['noteMoyenne'],
          'nbNotes': data['nbNotes'] ?? 0,
        }));
        return data;
      }
    } catch (_) {}
    return null;
  }
}
