import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

// ─────────────────────────────────────────────────────────────────────────────
// Widget principal du splash animé : logo LX + moto + texte
// ─────────────────────────────────────────────────────────────────────────────
class LxSplash extends StatefulWidget {
  const LxSplash({super.key});

  @override
  State<LxSplash> createState() => _LxSplashState();
}

class _LxSplashState extends State<LxSplash> with TickerProviderStateMixin {
  late final AnimationController _wheelCtrl;
  late final AnimationController _fadeCtrl;
  late final AnimationController _dotsCtrl;

  late final Animation<double> _fadeAnim;
  late final Animation<double> _scaleAnim;

  @override
  void initState() {
    super.initState();

    // Rotation des roues (continu)
    _wheelCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat();

    // Fade-in + scale de l'ensemble
    _fadeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..forward();

    _fadeAnim  = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _scaleAnim = Tween<double>(begin: 0.85, end: 1.0)
        .animate(CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOutBack));

    // Points de chargement
    _dotsCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat();
  }

  @override
  void dispose() {
    _wheelCtrl.dispose();
    _fadeCtrl.dispose();
    _dotsCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF0A0015), Color(0xFF0E0E10)],
        ),
      ),
      child: FadeTransition(
        opacity: _fadeAnim,
        child: ScaleTransition(
          scale: _scaleAnim,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // ── Logo LX ───────────────────────────────────────────────
              _LogoLX(),
              const SizedBox(height: 12),

              // ── Sous-titre ─────────────────────────────────────────────
              const Text(
                'LIVRAISON EXPRESS',
                style: TextStyle(
                  color: kTextMuted,
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 4,
                ),
              ),
              const SizedBox(height: 52),

              // ── Moto animée ────────────────────────────────────────────
              AnimatedBuilder(
                animation: _wheelCtrl,
                builder: (_, __) => SizedBox(
                  width: 240,
                  height: 110,
                  child: CustomPaint(
                    painter: _MotoPainter(
                      wheelAngle: _wheelCtrl.value * 2 * math.pi,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 48),

              // ── Points de chargement ───────────────────────────────────
              AnimatedBuilder(
                animation: _dotsCtrl,
                builder: (_, __) => _LoadingDots(progress: _dotsCtrl.value),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── Logo LX ─────────────────────────────────────────────────────────────────
class _LogoLX extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.center,
      children: [
        // Halo violet derrière le texte
        Container(
          width: 160,
          height: 100,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: kPurple.withOpacity(0.35),
                blurRadius: 60,
                spreadRadius: 20,
              ),
            ],
          ),
        ),
        RichText(
          text: const TextSpan(
            children: [
              TextSpan(
                text: 'L',
                style: TextStyle(
                  color: kTextWhite,
                  fontSize: 86,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -4,
                  height: 1,
                ),
              ),
              TextSpan(
                text: 'X',
                style: TextStyle(
                  color: kPurple,
                  fontSize: 86,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -4,
                  height: 1,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// ─── Points de chargement ────────────────────────────────────────────────────
class _LoadingDots extends StatelessWidget {
  final double progress;
  const _LoadingDots({required this.progress});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(3, (i) {
        final phase = (progress - i * 0.25).clamp(0.0, 1.0);
        final opacity = math.sin(phase * math.pi).clamp(0.2, 1.0);
        return Container(
          margin: const EdgeInsets.symmetric(horizontal: 5),
          width: 8,
          height: 8,
          decoration: BoxDecoration(
            color: kPurple.withOpacity(opacity),
            shape: BoxShape.circle,
          ),
        );
      }),
    );
  }
}

// ─── Dessin de la moto ───────────────────────────────────────────────────────
class _MotoPainter extends CustomPainter {
  final double wheelAngle;
  _MotoPainter({required this.wheelAngle});

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;

    // Positions clés
    final wr    = w * 0.165;   // rayon roue
    final rearX = w * 0.235;   // centre roue arrière
    final frtX  = w * 0.765;   // centre roue avant
    final axleY = h * 0.80;    // hauteur des axes

    // ── Carrosserie / silhouette ──────────────────────────────────
    final bodyPurple = Paint()
      ..shader = LinearGradient(
        colors: [kPurple, kPurpleDark],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ).createShader(Rect.fromLTWH(rearX, 0, frtX - rearX, axleY));

    final body = Path();
    // Point de départ : dessus de la roue arrière
    body.moveTo(rearX + wr * 0.45, axleY - wr * 0.85);
    // Courbe vers le sommet de la selle
    body.quadraticBezierTo(
      rearX + (frtX - rearX) * 0.28, axleY - wr * 1.58,
      rearX + (frtX - rearX) * 0.50, axleY - wr * 1.45,
    );
    // Vers l'avant, légèrement descendant
    body.lineTo(frtX - wr * 0.48, axleY - wr * 1.05);
    // Fourche avant — descend vers la roue avant
    body.lineTo(frtX - wr * 0.22, axleY - wr * 0.30);
    // Base avant
    body.lineTo(frtX - wr * 0.35, axleY - wr * 0.05);
    // Cadre bas
    body.lineTo(rearX + wr * 0.35, axleY - wr * 0.05);
    body.close();
    canvas.drawPath(body, bodyPurple);

    // ── Selle (carré arrondi sombre) ─────────────────────────────
    final saddlePaint = Paint()..color = kDarkSurf;
    final saddle = Path();
    saddle.moveTo(rearX + wr * 0.45, axleY - wr * 0.85);
    saddle.quadraticBezierTo(
      rearX + (frtX - rearX) * 0.22, axleY - wr * 1.65,
      rearX + (frtX - rearX) * 0.50, axleY - wr * 1.48,
    );
    saddle.lineTo(rearX + (frtX - rearX) * 0.44, axleY - wr * 1.26);
    saddle.quadraticBezierTo(
      rearX + (frtX - rearX) * 0.20, axleY - wr * 1.15,
      rearX + wr * 0.50, axleY - wr * 0.92,
    );
    saddle.close();
    canvas.drawPath(saddle, saddlePaint);

    // ── Guidon ────────────────────────────────────────────────────
    final handlePaint = Paint()
      ..color = kPurpleLight
      ..strokeWidth = 3.2
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke;
    canvas.drawLine(
      Offset(frtX - wr * 0.48, axleY - wr * 1.05),
      Offset(frtX - wr * 0.15, axleY - wr * 1.42),
      handlePaint,
    );
    // Poignée horizontale
    canvas.drawLine(
      Offset(frtX - wr * 0.05, axleY - wr * 1.35),
      Offset(frtX - wr * 0.28, axleY - wr * 1.48),
      handlePaint,
    );

    // ── Pot d'échappement ─────────────────────────────────────────
    final exhaustPaint = Paint()
      ..color = kPurpleLight
      ..strokeWidth = 4.5
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke;
    canvas.drawLine(
      Offset(rearX + wr * 0.10, axleY - wr * 0.22),
      Offset(rearX - wr * 0.30, axleY - wr * 0.22),
      exhaustPaint,
    );

    // ── Phare ─────────────────────────────────────────────────────
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(frtX - wr * 0.12, axleY - wr * 0.65),
        width: wr * 0.28,
        height: wr * 0.22,
      ),
      Paint()..color = const Color(0xFFFFF176).withOpacity(0.9),
    );
    // Halo du phare
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(frtX - wr * 0.12, axleY - wr * 0.65),
        width: wr * 0.42,
        height: wr * 0.34,
      ),
      Paint()
        ..color = const Color(0xFFFFF176).withOpacity(0.15)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
    );

    // ── Roues ─────────────────────────────────────────────────────
    _drawWheel(canvas, Offset(rearX, axleY), wr);
    _drawWheel(canvas, Offset(frtX, axleY), wr);
  }

  void _drawWheel(Canvas canvas, Offset c, double r) {
    // Pneu (fond sombre)
    canvas.drawCircle(c, r, Paint()..color = const Color(0xFF111111));

    // Jante intérieure
    canvas.drawCircle(
      c, r * 0.72,
      Paint()..color = kDarkCard,
    );

    // Cercle de rim violet
    canvas.drawCircle(
      c, r,
      Paint()
        ..color = kPurple
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3.5,
    );
    canvas.drawCircle(
      c, r * 0.72,
      Paint()
        ..color = kPurpleLight.withOpacity(0.4)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.5,
    );

    // Rayons (8 rayons qui tournent)
    final spokePaint = Paint()
      ..color = kPurpleLight
      ..strokeWidth = 1.8
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke;

    for (int i = 0; i < 8; i++) {
      final a = wheelAngle + (i * math.pi / 4);
      canvas.drawLine(
        Offset(c.dx + math.cos(a) * r * 0.14, c.dy + math.sin(a) * r * 0.14),
        Offset(c.dx + math.cos(a) * r * 0.68, c.dy + math.sin(a) * r * 0.68),
        spokePaint,
      );
    }

    // Moyeu centre
    canvas.drawCircle(c, r * 0.17, Paint()..color = kPurple);
    canvas.drawCircle(c, r * 0.08, Paint()..color = kPurpleLight);
  }

  @override
  bool shouldRepaint(_MotoPainter old) => old.wheelAngle != wheelAngle;
}
