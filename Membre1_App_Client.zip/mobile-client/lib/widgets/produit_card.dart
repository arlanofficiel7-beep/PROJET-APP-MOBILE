import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../models/produit.dart';
import '../theme/app_theme.dart';

class ProduitCard extends StatelessWidget {
  final Produit produit;
  final VoidCallback? onAjouter;
  final VoidCallback? onTap;

  const ProduitCard({
    super.key,
    required this.produit,
    this.onAjouter,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: kCardBg,
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(
              color: kPurple.withOpacity(0.06),
              blurRadius: 16,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ── Image ──────────────────────────────────────────────────
            ClipRRect(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(18)),
              child: Stack(
                children: [
                  produit.imageUrl.isNotEmpty
                      ? CachedNetworkImage(
                          imageUrl: produit.imageUrl,
                          height: 125,
                          width: double.infinity,
                          fit: BoxFit.cover,
                          placeholder: (_, __) => _shimmer(),
                          errorWidget: (_, __, ___) => _placeholder(),
                        )
                      : _placeholder(),
                  // Badge catégorie
                  Positioned(
                    top: 8, left: 8,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: kDarkBg.withOpacity(0.75),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        produit.categorie,
                        style: const TextStyle(color: kTextWhite, fontSize: 10, fontWeight: FontWeight.w600),
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // ── Infos ──────────────────────────────────────────────────
            Expanded(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      produit.nom,
                      style: const TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 13,
                        color: kDarkBg,
                        height: 1.3,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const Spacer(),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        // Prix
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '${produit.prix.toStringAsFixed(0)}',
                              style: const TextStyle(
                                color: kPurple,
                                fontWeight: FontWeight.w800,
                                fontSize: 16,
                              ),
                            ),
                            const Text('FCFA',
                              style: TextStyle(color: kTextMuted, fontSize: 10, fontWeight: FontWeight.w600)),
                          ],
                        ),
                        // Bouton +
                        GestureDetector(
                          onTap: onAjouter,
                          child: Container(
                            width: 36, height: 36,
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                colors: [kPurple, kPurpleDark],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              borderRadius: BorderRadius.circular(10),
                              boxShadow: [
                                BoxShadow(
                                  color: kPurple.withOpacity(0.35),
                                  blurRadius: 8,
                                  offset: const Offset(0, 3),
                                ),
                              ],
                            ),
                            child: const Icon(Icons.add_rounded, color: Colors.white, size: 20),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _placeholder() => Container(
    height: 125,
    width: double.infinity,
    color: kPurple.withOpacity(0.08),
    child: const Icon(Icons.shopping_bag_outlined, size: 48, color: kPurpleLight),
  );

  Widget _shimmer() => Container(
    height: 125,
    width: double.infinity,
    color: kBgLight,
    child: const Center(
      child: SizedBox(width: 24, height: 24,
        child: CircularProgressIndicator(color: kPurple, strokeWidth: 2)),
    ),
  );
}
