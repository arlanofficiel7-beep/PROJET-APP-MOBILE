import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'providers/auth_provider.dart';
import 'providers/panier_provider.dart';
import 'screens/auth/login_screen.dart';
import 'screens/catalogue_screen.dart';
import 'screens/commandes_screen.dart';
import 'screens/panier_screen.dart';
import 'theme/app_theme.dart';
import 'widgets/lx_splash.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
  ));
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthProvider()),
        ChangeNotifierProvider(create: (_) => PanierProvider()),
      ],
      child: const MonApp(),
    ),
  );
}

class MonApp extends StatelessWidget {
  const MonApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Livraison Express',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.theme,
      home: const SplashScreen(),
      routes: {
        '/accueil': (_) => const AccueilScreen(),
        '/login':   (_) => const LoginScreen(),
      },
    );
  }
}

/// Écran de démarrage : vérifie si l'utilisateur est connecté
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _verifierSession();
  }

  Future<void> _verifierSession() async {
    final auth = context.read<AuthProvider>();
    await auth.verifierSession();

    if (!mounted) return;
    if (auth.estConnecte) {
      Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (_) => const AccueilScreen()),
      );
    } else {
      Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (_) => const LoginScreen()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: LxSplash(),
    );
  }
}

/// Écran principal avec navigation par onglets
class AccueilScreen extends StatefulWidget {
  const AccueilScreen({super.key});

  @override
  State<AccueilScreen> createState() => _AccueilScreenState();
}

class _AccueilScreenState extends State<AccueilScreen> {
  int _ongletActuel = 0;

  final List<Widget> _ecrans = const [
    CatalogueScreen(),
    CommandesScreen(),
    ProfilScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _ecrans[_ongletActuel],
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          color: kDarkCard,
          border: Border(top: BorderSide(color: Color(0xFF2D2D35), width: 1)),
        ),
        child: BottomNavigationBar(
          currentIndex: _ongletActuel,
          backgroundColor: kDarkCard,
          selectedItemColor: kPurple,
          unselectedItemColor: kTextMuted,
          showUnselectedLabels: true,
          type: BottomNavigationBarType.fixed,
          elevation: 0,
          onTap: (i) => setState(() => _ongletActuel = i),
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.storefront_rounded), label: 'Catalogue'),
            BottomNavigationBarItem(icon: Icon(Icons.receipt_long_rounded), label: 'Commandes'),
            BottomNavigationBarItem(icon: Icon(Icons.person_rounded), label: 'Profil'),
          ],
        ),
      ),
    );
  }
}

/// Écran Profil
class ProfilScreen extends StatefulWidget {
  const ProfilScreen({super.key});

  @override
  State<ProfilScreen> createState() => _ProfilScreenState();
}

class _ProfilScreenState extends State<ProfilScreen> {
  bool _uploading = false;

  @override
  void initState() {
    super.initState();
    // Rafraîchir depuis le serveur : reflète les modifs faites par l'admin
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) context.read<AuthProvider>().rafraichirDepuisServeur();
    });
  }

  Future<void> _choisirPhoto() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(
      source: ImageSource.gallery,
      maxWidth: 400,
      maxHeight: 400,
      imageQuality: 75,
    );
    if (picked == null || !mounted) return;

    setState(() => _uploading = true);
    final bytes = await picked.readAsBytes();
    final base64Str = base64Encode(bytes);

    final auth = context.read<AuthProvider>();
    final erreur = await auth.mettreAJourPhoto(base64Str);
    if (!mounted) return;
    setState(() => _uploading = false);

    if (erreur != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(erreur), backgroundColor: Colors.red),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Photo mise à jour !'), backgroundColor: Colors.green),
      );
    }
  }

  Future<void> _ouvrirEdition() async {
    final auth = context.read<AuthProvider>();
    final user = auth.utilisateur;

    final nomCtrl       = TextEditingController(text: user?['nom'] ?? '');
    final telCtrl       = TextEditingController(text: user?['telephone'] ?? '');
    final ancienMdpCtrl = TextEditingController();
    final nvMdpCtrl     = TextEditingController();
    final nvMdpConfCtrl = TextEditingController();
    bool changerMdp = false;
    bool saving     = false;
    String? erreur;

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: kDarkCard,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setModalState) => Padding(
          padding: EdgeInsets.only(
            left: 24, right: 24, top: 24,
            bottom: MediaQuery.of(ctx).viewInsets.bottom + 32,
          ),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                // Handle
                Center(
                  child: Container(
                    width: 40, height: 4,
                    margin: const EdgeInsets.only(bottom: 20),
                    decoration: BoxDecoration(
                      color: kTextMuted.withOpacity(0.3),
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
                const Text('Modifier mon profil',
                    style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                        color: kTextWhite)),
                const SizedBox(height: 20),
                _darkField(controller: nomCtrl, label: 'Nom complet', icon: Icons.person_outline),
                const SizedBox(height: 14),
                _darkField(controller: telCtrl, label: 'Téléphone', icon: Icons.phone_outlined, type: TextInputType.phone),
                const SizedBox(height: 14),
                Row(
                  children: [
                    SizedBox(
                      width: 24, height: 24,
                      child: Checkbox(
                        value: changerMdp,
                        activeColor: kPurple,
                        checkColor: Colors.white,
                        side: const BorderSide(color: kTextMuted),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
                        onChanged: (v) => setModalState(() => changerMdp = v ?? false),
                      ),
                    ),
                    const SizedBox(width: 10),
                    const Text('Changer le mot de passe', style: TextStyle(color: kTextWhite)),
                  ],
                ),
                if (changerMdp) ...[
                  const SizedBox(height: 14),
                  _darkField(controller: ancienMdpCtrl, label: 'Mot de passe actuel', icon: Icons.lock_outline, obscure: true),
                  const SizedBox(height: 12),
                  _darkField(controller: nvMdpCtrl, label: 'Nouveau mot de passe', icon: Icons.lock_reset, obscure: true),
                  const SizedBox(height: 12),
                  _darkField(controller: nvMdpConfCtrl, label: 'Confirmer le nouveau mot de passe', icon: Icons.lock_reset, obscure: true),
                ],
                if (erreur != null) ...[
                  const SizedBox(height: 10),
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: Colors.red.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(erreur!, style: const TextStyle(color: Colors.red, fontSize: 13)),
                  ),
                ],
                const SizedBox(height: 24),
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: kPurple,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    onPressed: saving ? null : () async {
                      final nom = nomCtrl.text.trim();
                      if (nom.isEmpty) {
                        setModalState(() => erreur = 'Le nom est requis.');
                        return;
                      }
                      if (changerMdp) {
                        if (nvMdpCtrl.text != nvMdpConfCtrl.text) {
                          setModalState(() => erreur = 'Les mots de passe ne correspondent pas.');
                          return;
                        }
                        if (nvMdpCtrl.text.length < 6) {
                          setModalState(() => erreur = 'Mot de passe trop court (6 caractères min).');
                          return;
                        }
                      }
                      setModalState(() { saving = true; erreur = null; });
                      final e = await auth.mettreAJourInfos(
                        nom: nom,
                        telephone: telCtrl.text.trim(),
                        motDePasseActuel: changerMdp ? ancienMdpCtrl.text : null,
                        nouveauMotDePasse: changerMdp ? nvMdpCtrl.text : null,
                      );
                      setModalState(() => saving = false);
                      if (e != null) {
                        setModalState(() => erreur = e);
                      } else {
                        if (ctx.mounted) Navigator.pop(ctx);
                        if (mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Profil mis à jour ✅'),
                              backgroundColor: kPurple),
                          );
                        }
                      }
                    },
                    child: saving
                        ? const SizedBox(width: 20, height: 20,
                            child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                        : const Text('Enregistrer', style: TextStyle(fontWeight: FontWeight.w700)),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _darkField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    TextInputType type = TextInputType.text,
    bool obscure = false,
  }) {
    return TextField(
      controller: controller,
      keyboardType: type,
      obscureText: obscure,
      style: const TextStyle(color: kTextWhite),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: const TextStyle(color: kTextMuted, fontSize: 13),
        prefixIcon: Icon(icon, color: kPurple, size: 20),
        filled: true,
        fillColor: const Color(0xFF1F1F23),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: kPurple, width: 1.5),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final user = auth.utilisateur;
    final photoB64 = user?['photoBase64'] as String?;
    Uint8List? photoBytes;
    if (photoB64 != null && photoB64.isNotEmpty) {
      try { photoBytes = base64Decode(photoB64); } catch (_) {}
    }

    return Scaffold(
      backgroundColor: kBgLight,
      appBar: AppBar(
        backgroundColor: kDarkBg,
        elevation: 0,
        title: RichText(
          text: const TextSpan(children: [
            TextSpan(text: 'L', style: TextStyle(color: kTextWhite, fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: -1)),
            TextSpan(text: 'X', style: TextStyle(color: kPurple,    fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: -1)),
            TextSpan(text: '  Mon profil', style: TextStyle(color: kTextWhite, fontSize: 16, fontWeight: FontWeight.w600)),
          ]),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // ── En-tête sombre ────────────────────────────────────────────
            Container(
              width: double.infinity,
              color: kDarkBg,
              padding: const EdgeInsets.fromLTRB(24, 0, 24, 32),
              child: Column(
                children: [
                  // Avatar
                  GestureDetector(
                    onTap: _uploading ? null : _choisirPhoto,
                    child: Stack(
                      children: [
                        Container(
                          width: 100, height: 100,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: kPurple, width: 3),
                            color: kDarkCard,
                          ),
                          child: ClipOval(
                            child: photoBytes != null
                                ? Image.memory(photoBytes, fit: BoxFit.cover, width: 100, height: 100)
                                : const Icon(Icons.person_rounded, size: 56, color: kPurple),
                          ),
                        ),
                        Positioned(
                          bottom: 0, right: 0,
                          child: Container(
                            padding: const EdgeInsets.all(6),
                            decoration: const BoxDecoration(color: kPurple, shape: BoxShape.circle),
                            child: _uploading
                                ? const SizedBox(width: 14, height: 14,
                                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                                : const Icon(Icons.camera_alt, size: 14, color: Colors.white),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 6),
                  const Text('Appuyer pour changer', style: TextStyle(fontSize: 11, color: kTextMuted)),
                  const SizedBox(height: 12),
                  Text(user?['nom'] ?? '',
                      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: kTextWhite)),
                  const SizedBox(height: 4),
                  Text(user?['email'] ?? '',
                      style: const TextStyle(color: kTextMuted, fontSize: 13)),
                  if ((user?['telephone'] ?? '').isNotEmpty) ...[
                    const SizedBox(height: 4),
                    Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      const Icon(Icons.phone, size: 14, color: kTextMuted),
                      const SizedBox(width: 4),
                      Text(user!['telephone'], style: const TextStyle(color: kTextMuted, fontSize: 13)),
                    ]),
                  ],
                  const SizedBox(height: 10),
                  if (user?['noteMoyenne'] != null)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                      decoration: BoxDecoration(
                        color: Colors.amber.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: Colors.amber.withOpacity(0.35)),
                      ),
                      child: Row(mainAxisSize: MainAxisSize.min, children: [
                        const Icon(Icons.star_rounded, color: Colors.amber, size: 16),
                        const SizedBox(width: 6),
                        Text(
                          '${(user!['noteMoyenne'] as num).toStringAsFixed(1)} (${user['nbNotes'] ?? 0} avis)',
                          style: const TextStyle(fontWeight: FontWeight.w600, color: Colors.amber, fontSize: 13),
                        ),
                      ]),
                    )
                  else
                    const Text('Pas encore de note', style: TextStyle(color: kTextMuted, fontSize: 13)),
                  const SizedBox(height: 12),
                  // Badge rôle
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                    decoration: BoxDecoration(
                      color: kPurple.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: kPurple.withOpacity(0.4)),
                    ),
                    child: const Text('Client', style: TextStyle(color: kPurple, fontWeight: FontWeight.w700, fontSize: 13)),
                  ),
                  const SizedBox(height: 16),
                  // Bouton édition
                  SizedBox(
                    width: double.infinity,
                    height: 44,
                    child: OutlinedButton.icon(
                      onPressed: _ouvrirEdition,
                      icon: const Icon(Icons.edit_rounded, color: kPurple, size: 18),
                      label: const Text('Modifier mon profil',
                          style: TextStyle(color: kPurple, fontWeight: FontWeight.w600)),
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: kPurple),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // ── Raccourcis ────────────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Navigation rapide',
                      style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: kDarkBg)),
                  const SizedBox(height: 12),
                  Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [BoxShadow(color: kPurple.withOpacity(0.06), blurRadius: 12, offset: const Offset(0, 4))],
                    ),
                    child: Column(
                      children: [
                        _raccourci(
                          icon: Icons.receipt_long_rounded,
                          label: 'Mes commandes',
                          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CommandesScreen())),
                        ),
                        const Divider(height: 1, color: Color(0xFFF5F3FF)),
                        _raccourci(
                          icon: Icons.shopping_bag_rounded,
                          label: 'Mon panier',
                          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PanierScreen())),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),

                  // Bouton déconnexion
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: OutlinedButton.icon(
                      onPressed: () async {
                        await auth.deconnexion();
                        if (!context.mounted) return;
                        Navigator.pushNamedAndRemoveUntil(context, '/login', (route) => false);
                      },
                      icon: const Icon(Icons.logout_rounded, color: Colors.red, size: 20),
                      label: const Text('Se déconnecter',
                          style: TextStyle(color: Colors.red, fontWeight: FontWeight.w600)),
                      style: OutlinedButton.styleFrom(
                        side: BorderSide(color: Colors.red.shade400),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _raccourci({required IconData icon, required String label, required VoidCallback onTap}) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        child: Row(children: [
          Container(
            width: 38, height: 38,
            decoration: BoxDecoration(
              color: kPurple.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: kPurple, size: 20),
          ),
          const SizedBox(width: 14),
          Expanded(child: Text(label, style: const TextStyle(fontWeight: FontWeight.w600, color: kDarkBg))),
          const Icon(Icons.arrow_forward_ios_rounded, size: 14, color: kTextMuted),
        ]),
      ),
    );
  }
}
