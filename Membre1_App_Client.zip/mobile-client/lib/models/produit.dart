class Produit {
  final String id;
  final String nom;
  final String description;
  final double prix;
  final String categorie;
  final String imageUrl;
  final int stock;
  final bool disponible;

  Produit({
    required this.id,
    required this.nom,
    required this.description,
    required this.prix,
    required this.categorie,
    required this.imageUrl,
    required this.stock,
    required this.disponible,
  });

  factory Produit.fromJson(Map<String, dynamic> json) {
    return Produit(
      id: json['id'] ?? '',
      nom: json['nom'] ?? '',
      description: json['description'] ?? '',
      prix: (json['prix'] ?? 0).toDouble(),
      categorie: json['categorie'] ?? '',
      imageUrl: json['imageUrl'] ?? '',
      stock: json['stock'] ?? 0,
      disponible: json['disponible'] ?? true,
    );
  }
}
