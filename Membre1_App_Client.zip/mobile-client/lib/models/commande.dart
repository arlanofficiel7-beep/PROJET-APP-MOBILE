class ArticleCommande {
  final String produitId;
  final String nom;
  final double prix;
  final int quantite;
  final String imageUrl;

  ArticleCommande({
    required this.produitId,
    required this.nom,
    required this.prix,
    required this.quantite,
    required this.imageUrl,
  });

  factory ArticleCommande.fromJson(Map<String, dynamic> json) {
    return ArticleCommande(
      produitId: json['produitId'] ?? '',
      nom: json['nom'] ?? '',
      prix: (json['prix'] ?? 0).toDouble(),
      quantite: json['quantite'] ?? 1,
      imageUrl: json['imageUrl'] ?? '',
    );
  }

  Map<String, dynamic> toJson() => {
    'produitId': produitId,
    'quantite': quantite,
  };
}

class Commande {
  final String id;
  final String clientId;
  final List<ArticleCommande> articles;
  final String adresseLivraison;
  final double? latLivraison;
  final double? lngLivraison;
  final double total;
  final String statut;
  final String? livreurId;
  final String creeLe;

  // Instructions vocales + photo repère
  final String? audioBase64;
  final String? photoRepere;

  // Notation : le client a-t-il déjà noté le livreur ?
  final int? noteLivreurParClient;
  // Infos du livreur enrichies par le backend
  final String? livreurNom;
  final double? livreurNoteMoyenne;
  final int livreurNbNotes;

  Commande({
    required this.id,
    required this.clientId,
    required this.articles,
    required this.adresseLivraison,
    this.latLivraison,
    this.lngLivraison,
    required this.total,
    required this.statut,
    this.livreurId,
    required this.creeLe,
    this.audioBase64,
    this.photoRepere,
    this.noteLivreurParClient,
    this.livreurNom,
    this.livreurNoteMoyenne,
    this.livreurNbNotes = 0,
  });

  factory Commande.fromJson(Map<String, dynamic> json) {
    return Commande(
      id: json['id'] ?? '',
      clientId: json['clientId'] ?? '',
      articles: (json['articles'] as List? ?? [])
          .map((a) => ArticleCommande.fromJson(a))
          .toList(),
      adresseLivraison: json['adresseLivraison'] ?? '',
      latLivraison: json['latLivraison'] != null
          ? (json['latLivraison'] as num).toDouble()
          : null,
      lngLivraison: json['lngLivraison'] != null
          ? (json['lngLivraison'] as num).toDouble()
          : null,
      total: (json['total'] ?? 0).toDouble(),
      statut: json['statut'] ?? 'en_attente',
      livreurId: json['livreurId'],
      creeLe: json['creeLe'] ?? '',
      audioBase64: json['audioBase64'] as String?,
      photoRepere: json['photoRepere'] as String?,
      noteLivreurParClient: json['noteLivreurParClient'] as int?,
      livreurNom: json['livreurNom'] as String?,
      livreurNoteMoyenne: json['livreurNoteMoyenne'] != null
          ? (json['livreurNoteMoyenne'] as num).toDouble()
          : null,
      livreurNbNotes: (json['livreurNbNotes'] as int?) ?? 0,
    );
  }

  String get statutLabel {
    const labels = {
      'en_attente': 'En attente',
      'confirmee': 'Confirmée',
      'en_preparation': 'En préparation',
      'en_livraison': 'En livraison',
      'livree': 'Livrée ✅',
      'annulee': 'Annulée ❌',
    };
    return labels[statut] ?? statut;
  }
}
