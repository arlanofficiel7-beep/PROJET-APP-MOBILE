class ApiConfig {
  // 🔧 Changer l'IP si tu testes sur un vrai téléphone (utilise ton IP locale ex: 192.168.1.x)
  static const String baseUrl = 'http://10.0.2.2:3000/api'; // Émulateur Android → PC hôte

  static const String auth = '$baseUrl/auth';
  static const String produits = '$baseUrl/produits';
  static const String commandes = '$baseUrl/commandes';
  static const String livreurs = '$baseUrl/livreurs';
}
