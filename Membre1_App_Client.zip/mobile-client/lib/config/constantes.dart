import 'package:latlong2/latlong.dart';

class Entrepot {
  /// Point de départ de tous les livreurs
  /// Rond-Point de la Démocratie, Libreville, Gabon
  static const String nom = 'Entrepôt – Rond-Point Démocratie, Libreville';
  static const double latitude  = 0.3917;
  static const double longitude = 9.4536;
  static LatLng get position => const LatLng(latitude, longitude);
}
