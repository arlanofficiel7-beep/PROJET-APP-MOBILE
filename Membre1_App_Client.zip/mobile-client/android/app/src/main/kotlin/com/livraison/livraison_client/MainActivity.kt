package com.livraison.livraison_client

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
