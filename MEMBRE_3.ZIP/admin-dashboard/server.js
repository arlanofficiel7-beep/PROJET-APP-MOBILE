const express = require('express');
const path = require('path');

const app = express();
const PORT = 8080;

// Servir les fichiers statiques du dossier public
app.use(express.static(path.join(__dirname, 'public')));

// Toutes les routes renvoient vers index.html (SPA)
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`✅ Dashboard admin disponible sur http://localhost:${PORT}`);
});
