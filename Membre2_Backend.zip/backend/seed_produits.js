/**
 * Script d'initialisation des produits — Livraison Express
 * Exécuter depuis le dossier backend/ :
 *   node seed_produits.js
 */

require('dotenv').config();
const { db } = require('./src/config/firebase');

const produits = [

  // ──────────────────────────────────────────────────────────────
  // 🍚 ALIMENTATION
  // ──────────────────────────────────────────────────────────────
  {
    nom: 'Riz parfumé long grain (5 kg)',
    description: 'Riz thaïlandais long grain de qualité supérieure, parfumé au jasmin. Idéal pour les plats de fête et la cuisine quotidienne. Cuisson rapide et moelleux garanti.',
    prix: 4500,
    categorie: 'Alimentation',
    imageUrl: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?w=400&q=80&auto=format&fit=crop',
    stock: 50,
  },
  {
    nom: 'Huile de palme raffinée (1 L)',
    description: 'Huile de palme raffinée 100% végétale, riche en vitamine A et E. Sans cholestérol, parfaite pour la friture et la cuisson de tous vos plats africains.',
    prix: 1200,
    categorie: 'Alimentation',
    imageUrl: 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=400&q=80&auto=format&fit=crop',
    stock: 80,
  },
  {
    nom: 'Sardines à la tomate (boîte 425g)',
    description: 'Sardines entières en sauce tomate épicée. Riche en oméga-3 et en protéines. Produit conservé, prêt à consommer, idéal avec du pain ou du riz.',
    prix: 850,
    categorie: 'Alimentation',
    imageUrl: 'https://images.unsplash.com/photo-1584267385494-9fdd9a71ad75?w=400&q=80&auto=format&fit=crop',
    stock: 120,
  },
  {
    nom: 'Lait en poudre entier (500 g)',
    description: 'Lait entier en poudre enrichi en vitamines A et D. Dissolution rapide dans l\'eau chaude ou froide. Parfait pour le café, le thé, les bouillies et la pâtisserie.',
    prix: 2200,
    categorie: 'Alimentation',
    imageUrl: 'https://images.unsplash.com/photo-1550583724-b2692b85b150?w=400&q=80&auto=format&fit=crop',
    stock: 60,
  },
  {
    nom: 'Sucre blanc raffiné (1 kg)',
    description: 'Sucre blanc cristallisé de canne à sucre, finement raffiné. Idéal pour le café, le thé, la pâtisserie et toutes vos préparations culinaires sucrées.',
    prix: 800,
    categorie: 'Alimentation',
    imageUrl: 'https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=400&q=80&auto=format&fit=crop',
    stock: 100,
  },
  {
    nom: 'Farine de blé tout usage (1 kg)',
    description: 'Farine de blé tendre finement moulue, enrichie en fer et acide folique. Idéale pour la confection de beignets, pain, pâtes et gâteaux maison.',
    prix: 950,
    categorie: 'Alimentation',
    imageUrl: 'https://images.unsplash.com/photo-1631125915902-d8abe9225ff2?w=400&q=80&auto=format&fit=crop',
    stock: 90,
  },
  {
    nom: 'Bouillon cube de viande (boîte 24 cubes)',
    description: 'Bouillon concentré à base d\'extrait de viande de bœuf, oignon et épices. Apporte une saveur profonde et authentique à vos sauces, soupes et plats mijotés.',
    prix: 600,
    categorie: 'Alimentation',
    imageUrl: 'https://images.unsplash.com/photo-1628689469838-524a4a973b8e?w=400&q=80&auto=format&fit=crop',
    stock: 150,
  },
  {
    nom: 'Haricots blancs secs (1 kg)',
    description: 'Haricots blancs secs de qualité supérieure, riches en protéines végétales et en fibres. Idéaux pour les ragoûts, soupes et plats traditionnels gabonais.',
    prix: 1100,
    categorie: 'Alimentation',
    imageUrl: 'https://images.unsplash.com/photo-1550950158-d0d960dff596?w=400&q=80&auto=format&fit=crop',
    stock: 70,
  },

  // ──────────────────────────────────────────────────────────────
  // 🥤 BOISSONS
  // ──────────────────────────────────────────────────────────────
  {
    nom: 'Eau minérale naturelle (pack 6 x 1,5 L)',
    description: 'Eau minérale naturelle pure, source protégée. Faible teneur en sodium, idéale pour une hydratation quotidienne saine de toute la famille. Livrée fraîche.',
    prix: 3000,
    categorie: 'Boissons',
    imageUrl: 'https://images.unsplash.com/photo-1548839140-29a749e1cf4d?w=400&q=80&auto=format&fit=crop',
    stock: 40,
  },
  {
    nom: 'Jus de fruits tropicaux (1 L)',
    description: 'Jus de fruits tropicaux 100% naturel — mélange mangue, fruit de la passion et goyave. Sans sucres ajoutés, sans conservateurs. Vitaminé et rafraîchissant.',
    prix: 1500,
    categorie: 'Boissons',
    imageUrl: 'https://images.unsplash.com/photo-1600271886742-f049cd451bba?w=400&q=80&auto=format&fit=crop',
    stock: 55,
  },
  {
    nom: 'Coca-Cola (bouteille 2 L)',
    description: 'La boisson gazeuse iconique au goût unique. Servie froide pour une fraîcheur maximale. Parfaite pour accompagner vos repas ou vos moments de détente.',
    prix: 1800,
    categorie: 'Boissons',
    imageUrl: 'https://images.unsplash.com/photo-1554866585-cd94860890b7?w=400&q=80&auto=format&fit=crop',
    stock: 45,
  },
  {
    nom: 'Café soluble (bocal 200 g)',
    description: 'Café soluble 100% arabica à dissolution instantanée. Arôme intense et saveur équilibrée. Prêt en 30 secondes, parfait pour bien commencer la journée.',
    prix: 4200,
    categorie: 'Boissons',
    imageUrl: 'https://images.unsplash.com/photo-1610889556528-9a770e32642f?w=400&q=80&auto=format&fit=crop',
    stock: 35,
  },
  {
    nom: 'Thé au citron (boîte 25 sachets)',
    description: 'Thé noir infusé à l\'arôme naturel de citron. Faible teneur en théine. Idéal chaud le matin ou en boisson glacée rafraîchissante en journée.',
    prix: 900,
    categorie: 'Boissons',
    imageUrl: 'https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=400&q=80&auto=format&fit=crop',
    stock: 80,
  },

  // ──────────────────────────────────────────────────────────────
  // 🧴 HYGIÈNE & BEAUTÉ
  // ──────────────────────────────────────────────────────────────
  {
    nom: 'Savon de toilette (lot de 3 x 90 g)',
    description: 'Savon hydratant enrichi en beurre de karité et huiles végétales. Nettoie en douceur, respecte le pH naturel de la peau. Parfum fleuri longue durée.',
    prix: 1500,
    categorie: 'Hygiène & Beauté',
    imageUrl: 'https://images.unsplash.com/photo-1583209814683-c023dd293cc6?w=400&q=80&auto=format&fit=crop',
    stock: 90,
  },
  {
    nom: 'Shampooing fortifiant (400 ml)',
    description: 'Shampooing enrichi en protéines de kératine et huile d\'argan. Renforce les cheveux fragilisés, apporte brillance et légèreté. Convient à tous types de cheveux.',
    prix: 3500,
    categorie: 'Hygiène & Beauté',
    imageUrl: 'https://images.unsplash.com/photo-1585751119414-ef2636f8aede?w=400&q=80&auto=format&fit=crop',
    stock: 45,
  },
  {
    nom: 'Crème corporelle hydratante (250 ml)',
    description: 'Crème hydratante à la glycérine végétale et à l\'aloé vera. Absorpion rapide, non grasse. Hydrate et nourrit la peau en profondeur pendant 24 heures.',
    prix: 2800,
    categorie: 'Hygiène & Beauté',
    imageUrl: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?w=400&q=80&auto=format&fit=crop',
    stock: 60,
  },
  {
    nom: 'Dentifrice blancheur (lot 2 x 100 ml)',
    description: 'Dentifrice au fluor avec agents blanchissants naturels. Protège contre les caries, combat le tartre et rafraîchit l\'haleine toute la journée. Sans paraben.',
    prix: 1800,
    categorie: 'Hygiène & Beauté',
    imageUrl: 'https://images.unsplash.com/photo-1607613009820-a29f7bb81c04?w=400&q=80&auto=format&fit=crop',
    stock: 75,
  },
  {
    nom: 'Déodorant roll-on 48h (50 ml)',
    description: 'Déodorant anti-transpirant à bille, protection efficace 48 heures. Sans alcool, sans aluminium. Fraîcheur longue durée, peau douce et sèche toute la journée.',
    prix: 2200,
    categorie: 'Hygiène & Beauté',
    imageUrl: 'https://images.unsplash.com/photo-1571781926291-c477ebfd024b?w=400&q=80&auto=format&fit=crop',
    stock: 55,
  },

  // ──────────────────────────────────────────────────────────────
  // 🏠 MAISON & ENTRETIEN
  // ──────────────────────────────────────────────────────────────
  {
    nom: 'Lessive en poudre concentrée (1 kg)',
    description: 'Lessive concentrée formule active, efficace dès 30°C. Élimine les taches difficiles, préserve les couleurs et parfume agréablement le linge. Pour 20 lavages.',
    prix: 2500,
    categorie: 'Maison & Entretien',
    imageUrl: 'https://images.unsplash.com/photo-1582735689369-4fe89db7114c?w=400&q=80&auto=format&fit=crop',
    stock: 50,
  },
  {
    nom: 'Liquide vaisselle citron (500 ml)',
    description: 'Liquide vaisselle ultra-dégraissant au citron. Dissout les graisses cuites, protège les mains et rince facilement. Flacon économique, formule concentrée.',
    prix: 1200,
    categorie: 'Maison & Entretien',
    imageUrl: 'https://images.unsplash.com/photo-1585771724684-38269d6639fd?w=400&q=80&auto=format&fit=crop',
    stock: 70,
  },
  {
    nom: 'Papier hygiénique (lot 6 rouleaux)',
    description: 'Papier toilette double épaisseur, doux et résistant. Cellulose pure 100% recyclable. Blanc, sans parfum, respectueux des peaux sensibles. Lot de 6 rouleaux.',
    prix: 3000,
    categorie: 'Maison & Entretien',
    imageUrl: 'https://images.unsplash.com/photo-1584820927498-cfe5211fd8bf?w=400&q=80&auto=format&fit=crop',
    stock: 40,
  },
  {
    nom: 'Désinfectant multi-surfaces (750 ml)',
    description: 'Nettoyant désinfectant à l\'eucalyptus, élimine 99,9% des bactéries. Convient pour cuisine, salle de bain, sols et surfaces. Prêt à l\'emploi, sans rinçage.',
    prix: 2000,
    categorie: 'Maison & Entretien',
    imageUrl: 'https://images.unsplash.com/photo-1563453392212-326f5e854473?w=400&q=80&auto=format&fit=crop',
    stock: 55,
  },

  // ──────────────────────────────────────────────────────────────
  // 📱 ÉLECTRONIQUE & ACCESSOIRES
  // ──────────────────────────────────────────────────────────────
  {
    nom: 'Chargeur USB-C rapide (20W)',
    description: 'Chargeur secteur USB-C charge rapide 20W compatible tous smartphones Android et iPhone. Technologie PD (Power Delivery), sécurité anti-surtension intégrée.',
    prix: 6500,
    categorie: 'Électronique',
    imageUrl: 'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?w=400&q=80&auto=format&fit=crop',
    stock: 30,
  },
  {
    nom: 'Écouteurs intra-auriculaires',
    description: 'Écouteurs stéréo avec microphone intégré, compatible jack 3,5 mm. Basses profondes, aigus clairs. Câble anti-nœuds 1,2m, embouts silicone 3 tailles inclus.',
    prix: 5500,
    categorie: 'Électronique',
    imageUrl: 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=400&q=80&auto=format&fit=crop',
    stock: 25,
  },
  {
    nom: 'Batterie externe portable (10 000 mAh)',
    description: 'Powerbank 10 000 mAh avec 2 ports USB-A + 1 port USB-C. Charge simultanée de 3 appareils. Indicateur LED de charge, compact et léger (220g). Idéal voyage.',
    prix: 15000,
    categorie: 'Électronique',
    imageUrl: 'https://images.unsplash.com/photo-1609091839311-d5365f9ff1c5?w=400&q=80&auto=format&fit=crop',
    stock: 20,
  },
  {
    nom: 'Câble USB-C / USB-A (2m)',
    description: 'Câble de charge et de données renforcé en nylon tressé, longueur 2 mètres. Compatible charge rapide jusqu\'à 3A. Connecteurs dorés anti-oxydation. Garantie 1 an.',
    prix: 3500,
    categorie: 'Électronique',
    imageUrl: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&q=80&auto=format&fit=crop',
    stock: 40,
  },
];

async function seeder() {
  console.log(`\n🚀 Insertion de ${produits.length} produits dans Firestore...\n`);
  let ok = 0;
  let erreurs = 0;

  for (const p of produits) {
    try {
      const ref = db.collection('produits').doc();
      await ref.set({
        id: ref.id,
        ...p,
        stockFaible: p.stock < 10,
        disponible: true,
        creeLe: new Date().toISOString(),
      });
      console.log(`  ✅ [${p.categorie}] ${p.nom}`);
      ok++;
    } catch (err) {
      console.error(`  ❌ Erreur pour "${p.nom}" : ${err.message}`);
      erreurs++;
    }
  }

  console.log(`\n──────────────────────────────────────`);
  console.log(`✅ ${ok} produits ajoutés`);
  if (erreurs > 0) console.log(`❌ ${erreurs} erreurs`);
  console.log(`──────────────────────────────────────\n`);
  process.exit(0);
}

seeder();
