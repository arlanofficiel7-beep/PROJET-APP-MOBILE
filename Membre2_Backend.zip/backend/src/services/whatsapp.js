// Fichier désactivé — vérification WhatsApp annulée
module.exports = {};
