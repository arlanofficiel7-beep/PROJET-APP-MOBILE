/**
 * Service d'envoi d'emails via SMTP (Gmail)
 *
 * Variables requises dans backend/.env :
 *   SMTP_HOST=smtp.gmail.com
 *   SMTP_PORT=587
 *   SMTP_USER=mboumbaikapi93@gmail.com
 *   SMTP_PASS=rxpkoencdnsxscwk
 *   SMTP_FROM_NAME=Livraison Express
 */

const nodemailer = require('nodemailer');

let _transporter = null;

function getTransporter() {
  if (_transporter) return _transporter;
  _transporter = nodemailer.createTransport({
    host:   process.env.SMTP_HOST || 'smtp.gmail.com',
    port:   parseInt(process.env.SMTP_PORT) || 587,
    secure: false, // TLS (STARTTLS sur port 587)
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS,
    },
  });
  return _transporter;
}

/**
 * Envoie un email HTML
 * @param {string} to      - Destinataire
 * @param {string} subject - Sujet
 * @param {string} html    - Corps HTML
 * @param {string} text    - Corps texte brut (fallback)
 */
async function envoyerEmail({ to, subject, html, text }) {
  const smtpUser = process.env.SMTP_USER;
  const smtpPass = process.env.SMTP_PASS;
  const fromName = process.env.SMTP_FROM_NAME || 'Livraison Express';

  // Mode dev : afficher dans la console si SMTP non configuré
  if (!smtpUser || !smtpPass) {
    console.log('\n─────────────────────────────────────');
    console.log(`📧 [DEV] Email → ${to}`);
    console.log(`Sujet : ${subject}`);
    console.log(text || '(HTML)');
    console.log('─────────────────────────────────────\n');
    return;
  }

  await getTransporter().sendMail({
    from:    `"${fromName}" <${smtpUser}>`,
    to,
    subject,
    html,
    text,
  });
}

module.exports = { envoyerEmail };
