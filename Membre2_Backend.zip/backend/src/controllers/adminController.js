const { db } = require('../config/firebase');

/** GET /api/admin/utilisateurs?role=client|livreur */
const listerUtilisateurs = async (req, res) => {
  try {
    const { role } = req.query;
    let query = db.collection('utilisateurs');
    if (role) query = query.where('role', '==', role);

    const snapshot = await query.get();
    const utilisateurs = snapshot.docs.map(doc => {
      const { motDePasse, ...data } = doc.data();
      return data;
    });
    utilisateurs.sort((a, b) => new Date(b.creeLe) - new Date(a.creeLe));
    res.json(utilisateurs);
  } catch (err) {
    console.error('Erreur listerUtilisateurs:', err.message);
    res.status(500).json({ message: 'Erreur serveur.' });
  }
};

/** PUT /api/admin/utilisateurs/:id */
const modifierUtilisateur = async (req, res) => {
  try {
    const { nom, email, telephone, photoBase64 } = req.body;
    const ref = db.collection('utilisateurs').doc(req.params.id);
    const doc = await ref.get();
    if (!doc.exists) return res.status(404).json({ message: 'Utilisateur introuvable.' });

    // Vérifier unicité email si changé
    if (email && email !== doc.data().email) {
      const existing = await db.collection('utilisateurs').where('email', '==', email).get();
      if (!existing.empty) return res.status(400).json({ message: 'Cet email est déjà utilisé.' });
    }

    const updates = {};
    if (nom)                     updates.nom         = nom;
    if (email)                   updates.email       = email;
    if (telephone !== undefined) updates.telephone   = telephone;
    if (photoBase64 !== undefined) updates.photoBase64 = photoBase64; // null = suppression
    updates.miseAJourLe = new Date().toISOString();

    await ref.update(updates);
    const updated = await ref.get();
    const { motDePasse, ...data } = updated.data();
    res.json({ message: 'Utilisateur mis à jour.', utilisateur: data });
  } catch (err) {
    console.error('Erreur modifierUtilisateur:', err.message);
    res.status(500).json({ message: 'Erreur serveur.' });
  }
};

/** DELETE /api/admin/utilisateurs/:id/photo */
const supprimerPhotoUtilisateur = async (req, res) => {
  try {
    const ref = db.collection('utilisateurs').doc(req.params.id);
    const doc = await ref.get();
    if (!doc.exists) return res.status(404).json({ message: 'Utilisateur introuvable.' });

    await ref.update({ photoBase64: null, miseAJourLe: new Date().toISOString() });
    res.json({ message: 'Photo supprimée.' });
  } catch (err) {
    console.error('Erreur supprimerPhotoUtilisateur:', err.message);
    res.status(500).json({ message: 'Erreur serveur.' });
  }
};

/** DELETE /api/admin/utilisateurs/:id */
const supprimerUtilisateur = async (req, res) => {
  try {
    const ref = db.collection('utilisateurs').doc(req.params.id);
    const doc = await ref.get();
    if (!doc.exists) return res.status(404).json({ message: 'Utilisateur introuvable.' });

    // Empêcher de supprimer un admin
    if (doc.data().role === 'admin') {
      return res.status(403).json({ message: 'Impossible de supprimer un compte admin.' });
    }

    await ref.delete();
    res.json({ message: 'Utilisateur supprimé.' });
  } catch (err) {
    console.error('Erreur supprimerUtilisateur:', err.message);
    res.status(500).json({ message: 'Erreur serveur.' });
  }
};

/**
 * GET /api/admin/analytics
 * Statistiques de vente pour le dashboard admin
 */
const getAnalytics = async (req, res) => {
  try {
    // Récupérer toutes les commandes livrées
    const snapshot = await db.collection('commandes').where('statut', '==', 'livree').get();
    const commandes = snapshot.docs.map(d => d.data());

    // ── Ventes par jour (30 derniers jours) ──────────────────────────────────
    const ventesParJour = {};
    const ventesParSemaine = {};
    const ventesParMois = {};
    const ventesParProduit = {}; // { produitId: { nom, quantite, chiffre } }

    const maintenant = new Date();

    commandes.forEach(c => {
      const date = new Date(c.creeLe);
      const diffJours = Math.floor((maintenant - date) / (1000 * 60 * 60 * 24));

      // Jour (format YYYY-MM-DD)
      if (diffJours <= 29) {
        const cle = date.toISOString().slice(0, 10);
        ventesParJour[cle] = (ventesParJour[cle] || 0) + c.total;
      }

      // Semaine (numéro semaine de l'année)
      if (diffJours <= 83) { // ~12 semaines
        const debutAnnee = new Date(date.getFullYear(), 0, 1);
        const semaine = Math.ceil(((date - debutAnnee) / 86400000 + debutAnnee.getDay() + 1) / 7);
        const cle = `${date.getFullYear()}-S${String(semaine).padStart(2, '0')}`;
        ventesParSemaine[cle] = (ventesParSemaine[cle] || 0) + c.total;
      }

      // Mois (format YYYY-MM)
      const cleMois = date.toISOString().slice(0, 7);
      ventesParMois[cleMois] = (ventesParMois[cleMois] || 0) + c.total;

      // Produits
      (c.articles || []).forEach(a => {
        if (!ventesParProduit[a.produitId]) {
          ventesParProduit[a.produitId] = { nom: a.nom, quantite: 0, chiffre: 0, imageUrl: a.imageUrl || '' };
        }
        ventesParProduit[a.produitId].quantite += a.quantite;
        ventesParProduit[a.produitId].chiffre  += a.prix * a.quantite;
      });
    });

    // Trier et formater les séries temporelles
    const trierCles = obj => Object.keys(obj).sort().map(k => ({ date: k, total: Math.round(obj[k]) }));

    // Top / flop produits
    const produitsTriesQte = Object.entries(ventesParProduit)
      .map(([id, v]) => ({ id, ...v }))
      .sort((a, b) => b.quantite - a.quantite);

    // Produits en stock faible
    const stockSnap = await db.collection('produits').where('stockFaible', '==', true).get();
    const stockFaibles = stockSnap.docs.map(d => {
      const { id, nom, stock, imageUrl } = d.data();
      return { id, nom, stock, imageUrl };
    });

    // Chiffre d'affaires total
    const chiffreAffaires = commandes.reduce((s, c) => s + (c.total || 0), 0);

    res.json({
      totalCommandes: commandes.length,
      chiffreAffaires: Math.round(chiffreAffaires),
      ventesParJour:    trierCles(ventesParJour),
      ventesParSemaine: trierCles(ventesParSemaine).slice(-12),
      ventesParMois:    trierCles(ventesParMois).slice(-12),
      topProduits:  produitsTriesQte.slice(0, 10),
      flopProduits: produitsTriesQte.slice(-5).reverse(),
      stockFaibles,
    });
  } catch (err) {
    console.error('Erreur getAnalytics:', err.message);
    res.status(500).json({ message: 'Erreur serveur.' });
  }
};

/**
 * POST /api/admin/promouvoir
 * Promouvoir un utilisateur en admin via son email
 */
const promouvoirAdmin = async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) return res.status(400).json({ message: 'Email requis.' });

    const snap = await db.collection('utilisateurs').where('email', '==', email.trim()).get();
    if (snap.empty) {
      return res.status(404).json({ message: `Aucun utilisateur trouvé avec l'email : ${email}` });
    }

    const doc = snap.docs[0];
    const user = doc.data();

    if (user.role === 'admin') {
      return res.status(400).json({ message: `${user.nom} est déjà administrateur.` });
    }

    await doc.ref.update({ role: 'admin', miseAJourLe: new Date().toISOString() });
    res.json({ message: `✅ ${user.nom} (${user.email}) est maintenant administrateur.`, nom: user.nom });
  } catch (err) {
    console.error('Erreur promouvoirAdmin:', err.message);
    res.status(500).json({ message: 'Erreur serveur.' });
  }
};

/**
 * POST /api/admin/revoquer
 * Révoquer le rôle admin d'un utilisateur (redevient client)
 */
const revoquerAdmin = async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) return res.status(400).json({ message: 'Email requis.' });

    const snap = await db.collection('utilisateurs').where('email', '==', email.trim()).get();
    if (snap.empty) {
      return res.status(404).json({ message: `Aucun utilisateur trouvé avec l'email : ${email}` });
    }

    const doc = snap.docs[0];
    const user = doc.data();

    // Empêcher de se révoquer soi-même (optionnel mais prudent)
    if (user.role !== 'admin') {
      return res.status(400).json({ message: `${user.nom} n'est pas administrateur.` });
    }

    await doc.ref.update({ role: 'client', miseAJourLe: new Date().toISOString() });
    res.json({ message: `${user.nom} n'est plus administrateur (rôle : client).`, nom: user.nom });
  } catch (err) {
    console.error('Erreur revoquerAdmin:', err.message);
    res.status(500).json({ message: 'Erreur serveur.' });
  }
};

module.exports = {
  listerUtilisateurs, modifierUtilisateur, supprimerUtilisateur,
  supprimerPhotoUtilisateur, getAnalytics, promouvoirAdmin, revoquerAdmin,
};
