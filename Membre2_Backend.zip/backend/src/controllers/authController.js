const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { db } = require('../config/firebase');
const { envoyerEmail } = require('../services/email');

/**
 * POST /api/auth/register
 * Inscription d'un nouvel utilisateur
 */
const inscription = async (req, res) => {
  try {
    const { nom, email, motDePasse, telephone, role } = req.body;

    // Validation téléphone obligatoire pour les clients
    const roleEffectif = role || 'client';
    if (roleEffectif === 'client' && (!telephone || telephone.trim().length < 8)) {
      return res.status(400).json({ message: 'Le numéro de téléphone est obligatoire.' });
    }

    // Vérifier que l'email a été confirmé par OTP (clients uniquement)
    if (roleEffectif === 'client') {
      const otpDoc = await db.collection('otps').doc(email.trim()).get();
      if (!otpDoc.exists || !otpDoc.data().verifie) {
        return res.status(400).json({ message: 'Email non confirmé. Complétez la vérification par email.' });
      }
    }

    // Vérifier si l'email existe déjà
    const snapshot = await db.collection('utilisateurs')
      .where('email', '==', email).get();

    if (!snapshot.empty) {
      return res.status(400).json({ message: 'Cet email est déjà utilisé.' });
    }

    // Hacher le mot de passe
    const hash = await bcrypt.hash(motDePasse, 10);

    // Créer l'utilisateur dans Firestore
    const userRef = db.collection('utilisateurs').doc();
    const nouvelUtilisateur = {
      id: userRef.id,
      nom,
      email,
      motDePasse: hash,
      telephone: telephone ? telephone.trim() : '',
      role: roleEffectif, // client | livreur | admin
      creeLe: new Date().toISOString(),
    };

    await userRef.set(nouvelUtilisateur);

    // Supprimer l'OTP email utilisé
    if (roleEffectif === 'client') {
      await db.collection('otps').doc(email.trim()).delete().catch(() => {});
    }

    // Générer le token JWT
    const token = jwt.sign(
      { id: userRef.id, email, role: nouvelUtilisateur.role },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.status(201).json({
      message: 'Compte créé avec succès.',
      token,
      utilisateur: {
        id: userRef.id,
        nom,
        email,
        role: nouvelUtilisateur.role,
      },
    });
  } catch (err) {
    console.error('Erreur inscription:', err);
    res.status(500).json({ message: 'Erreur serveur.' });
  }
};

/**
 * POST /api/auth/login
 * Connexion
 */
const connexion = async (req, res) => {
  try {
    const { email, motDePasse } = req.body;

    // Trouver l'utilisateur
    const snapshot = await db.collection('utilisateurs')
      .where('email', '==', email).get();

    if (snapshot.empty) {
      return res.status(401).json({ message: 'Email ou mot de passe incorrect.' });
    }

    const utilisateur = snapshot.docs[0].data();

    // Vérifier le mot de passe
    const valide = await bcrypt.compare(motDePasse, utilisateur.motDePasse);
    if (!valide) {
      return res.status(401).json({ message: 'Email ou mot de passe incorrect.' });
    }

    // Générer le token
    const token = jwt.sign(
      { id: utilisateur.id, email: utilisateur.email, role: utilisateur.role },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.json({
      message: 'Connexion réussie.',
      token,
      utilisateur: {
        id: utilisateur.id,
        nom: utilisateur.nom,
        email: utilisateur.email,
        telephone: utilisateur.telephone || '',
        role: utilisateur.role,
        photoBase64: utilisateur.photoBase64 || null,
      },
    });
  } catch (err) {
    console.error('Erreur connexion:', err);
    res.status(500).json({ message: 'Erreur serveur.' });
  }
};

/**
 * GET /api/auth/profil
 * Récupérer le profil de l'utilisateur connecté
 */
const profil = async (req, res) => {
  try {
    const doc = await db.collection('utilisateurs').doc(req.utilisateur.id).get();
    if (!doc.exists) {
      return res.status(404).json({ message: 'Utilisateur introuvable.' });
    }

    const { motDePasse, ...data } = doc.data(); // Exclure le mot de passe
    res.json(data);
  } catch (err) {
    console.error('Erreur profil:', err);
    res.status(500).json({ message: 'Erreur serveur.' });
  }
};

/**
 * PUT /api/auth/profil
 * Mettre à jour le profil (nom, téléphone, photoBase64, changement MDP optionnel)
 */
const mettreAJourProfil = async (req, res) => {
  try {
    const { nom, telephone, photoBase64, motDePasseActuel, nouveauMotDePasse } = req.body;
    const ref = db.collection('utilisateurs').doc(req.utilisateur.id);

    // Changement de mot de passe : vérifier l'ancien
    if (nouveauMotDePasse) {
      if (!motDePasseActuel) {
        return res.status(400).json({ message: 'Mot de passe actuel requis.' });
      }
      const doc = await ref.get();
      const valide = await bcrypt.compare(motDePasseActuel, doc.data().motDePasse);
      if (!valide) {
        return res.status(400).json({ message: 'Mot de passe actuel incorrect.' });
      }
      if (nouveauMotDePasse.length < 6) {
        return res.status(400).json({ message: 'Le nouveau mot de passe doit faire au moins 6 caractères.' });
      }
    }

    const miseAJour = { miseAJourLe: new Date().toISOString() };
    if (nom !== undefined && nom !== '')  miseAJour.nom = nom;
    if (telephone !== undefined)          miseAJour.telephone = telephone;
    if (photoBase64 !== undefined)        miseAJour.photoBase64 = photoBase64;
    if (nouveauMotDePasse) {
      miseAJour.motDePasse = await bcrypt.hash(nouveauMotDePasse, 10);
    }

    await ref.update(miseAJour);

    const doc = await ref.get();
    const { motDePasse, ...data } = doc.data();
    res.json({ message: 'Profil mis à jour.', utilisateur: data });
  } catch (err) {
    console.error('Erreur mettreAJourProfil:', err);
    res.status(500).json({ message: 'Erreur serveur.' });
  }
};

/**
 * POST /api/auth/envoyer-otp
 * Génère un code 6 chiffres et l'envoie par email
 */
const envoyerOtp = async (req, res) => {
  try {
    const { email } = req.body;
    if (!email || !email.includes('@')) {
      return res.status(400).json({ message: 'Adresse email invalide.' });
    }

    const code = Math.floor(100000 + Math.random() * 900000).toString();
    const expireAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

    // Stocker en Firestore (clé = email)
    await db.collection('otps').doc(email.trim()).set({
      email: email.trim(),
      code,
      expireAt: expireAt.toISOString(),
      verifie: false,
      creeLe: new Date().toISOString(),
    });

    // Envoyer par email
    await envoyerEmail({
      to: email.trim(),
      subject: '🔐 Votre code de vérification — Livraison Express',
      html: `
        <div style="font-family:Arial,sans-serif;max-width:480px;margin:auto;padding:32px;border:1px solid #eee;border-radius:12px">
          <h2 style="color:#f4a261;margin-bottom:8px">🚚 Livraison Express</h2>
          <p style="color:#555;margin-bottom:24px">Bonjour,<br>Voici votre code de confirmation d'inscription :</p>
          <div style="background:#f8f9fa;border-radius:10px;padding:24px;text-align:center;margin-bottom:24px">
            <span style="font-size:40px;font-weight:bold;letter-spacing:10px;color:#1a1a2e">${code}</span>
          </div>
          <p style="color:#888;font-size:13px">⏱ Ce code expire dans <strong>10 minutes</strong>.</p>
          <p style="color:#888;font-size:13px">⚠️ Ne partagez ce code avec personne.</p>
          <hr style="margin:24px 0;border:none;border-top:1px solid #eee"/>
          <p style="color:#bbb;font-size:11px;text-align:center">Livraison Express — Libreville, Gabon</p>
        </div>
      `,
      text: `Votre code de vérification Livraison Express : ${code}\n\nCe code expire dans 10 minutes.`,
    });

    res.json({ message: 'Code de vérification envoyé par email.' });
  } catch (err) {
    console.error('Erreur envoyerOtp:', err.message);
    res.status(500).json({ message: "Impossible d'envoyer l'email. Vérifiez votre adresse." });
  }
};

/**
 * POST /api/auth/verifier-otp
 * Vérifie le code saisi par l'utilisateur
 */
const verifierOtp = async (req, res) => {
  try {
    const { email, code } = req.body;
    if (!email || !code) {
      return res.status(400).json({ message: 'Email et code requis.' });
    }

    const doc = await db.collection('otps').doc(email.trim()).get();
    if (!doc.exists) {
      return res.status(400).json({ message: 'Aucun code trouvé pour cet email. Demandez un nouveau code.' });
    }

    const otp = doc.data();

    if (new Date() > new Date(otp.expireAt)) {
      return res.status(400).json({ message: 'Code expiré. Demandez un nouveau code.' });
    }
    if (otp.code !== code.trim()) {
      return res.status(400).json({ message: 'Code incorrect.' });
    }

    await db.collection('otps').doc(email.trim()).update({ verifie: true });
    res.json({ message: 'Email confirmé avec succès ✅' });
  } catch (err) {
    console.error('Erreur verifierOtp:', err.message);
    res.status(500).json({ message: 'Erreur serveur.' });
  }
};

module.exports = { inscription, connexion, profil, mettreAJourProfil, envoyerOtp, verifierOtp };
