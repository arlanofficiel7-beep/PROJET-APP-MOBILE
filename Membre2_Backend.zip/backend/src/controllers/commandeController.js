const { db } = require('../config/firebase');

/**
 * POST /api/commandes
 * Créer une nouvelle commande
 */
const creerCommande = async (req, res) => {
  try {
    const { articles, adresseLivraison, latLivraison, lngLivraison, audioBase64, photoRepere } = req.body;
    const clientId = req.utilisateur.id;

    let total = 0;
    const articlesDetails = [];

    for (const article of articles) {
      const prodDoc = await db.collection('produits').doc(article.produitId).get();
      if (!prodDoc.exists) {
        return res.status(400).json({ message: `Produit ${article.produitId} introuvable.` });
      }
      const produit = prodDoc.data();
      total += produit.prix * article.quantite;
      articlesDetails.push({
        produitId: article.produitId,
        nom: produit.nom,
        prix: produit.prix,
        quantite: article.quantite,
        imageUrl: produit.imageUrl,
      });
    }

    const ref = db.collection('commandes').doc();
    const commande = {
      id: ref.id,
      clientId,
      articles: articlesDetails,
      adresseLivraison,
      latLivraison: latLivraison || null,
      lngLivraison: lngLivraison || null,
      total,
      statut: 'en_attente',
      livreurId: null,
      audioBase64: audioBase64 || null,
      photoRepere: photoRepere || null,
      creeLe: new Date().toISOString(),
      miseAJourLe: new Date().toISOString(),
    };

    await ref.set(commande);
    res.status(201).json({ message: 'Commande créée.', commande });
  } catch (err) {
    console.error('Erreur creerCommande:', err);
    res.status(500).json({ message: 'Erreur serveur.' });
  }
};

/**
 * GET /api/commandes/mes-commandes
 * Liste des commandes du client connecté
 */
const mesCommandes = async (req, res) => {
  try {
    const snapshot = await db.collection('commandes')
      .where('clientId', '==', req.utilisateur.id)
      .get();

    const commandes = snapshot.docs.map(doc => doc.data());
    commandes.sort((a, b) => new Date(b.creeLe) - new Date(a.creeLe));

    // Enrichir avec les infos du livreur (nom + note moyenne) si assigné
    const livreurIds = [...new Set(commandes.filter(c => c.livreurId).map(c => c.livreurId))];
    if (livreurIds.length > 0) {
      const livreurDocs = await Promise.all(
        livreurIds.map(id => db.collection('utilisateurs').doc(id).get())
      );
      const livreurMap = {};
      livreurDocs.forEach(d => {
        if (d.exists) {
          const data = d.data();
          livreurMap[d.id] = {
            nom: data.nom,
            noteMoyenne: data.noteMoyenne ?? null,
            nbNotes: data.nbNotes ?? 0,
          };
        }
      });
      commandes.forEach(c => {
        if (c.livreurId && livreurMap[c.livreurId]) {
          c.livreurNom      = livreurMap[c.livreurId].nom;
          c.livreurNoteMoyenne = livreurMap[c.livreurId].noteMoyenne;
          c.livreurNbNotes  = livreurMap[c.livreurId].nbNotes;
        }
      });
    }

    res.json(commandes);
  } catch (err) {
    console.error('Erreur mesCommandes:', err.message);
    res.status(500).json({ message: 'Erreur serveur.', detail: err.message });
  }
};

/**
 * GET /api/commandes/:id
 * Détail d'une commande
 */
const getCommande = async (req, res) => {
  try {
    const doc = await db.collection('commandes').doc(req.params.id).get();
    if (!doc.exists) return res.status(404).json({ message: 'Commande introuvable.' });

    const commande = doc.data();
    if (req.utilisateur.role === 'client' && commande.clientId !== req.utilisateur.id) {
      return res.status(403).json({ message: 'Accès refusé.' });
    }
    res.json(commande);
  } catch (err) {
    res.status(500).json({ message: 'Erreur serveur.' });
  }
};

/**
 * PUT /api/commandes/:id/statut
 * Mettre à jour le statut (admin ou livreur)
 * → Quand statut = livree : décrémenter le stock de chaque article
 */
const mettreAJourStatut = async (req, res) => {
  try {
    const { statut } = req.body;
    const statutsValides = ['confirmee', 'en_preparation', 'en_livraison', 'livree', 'annulee'];

    if (!statutsValides.includes(statut)) {
      return res.status(400).json({ message: 'Statut invalide.' });
    }

    const commandeRef = db.collection('commandes').doc(req.params.id);
    await commandeRef.update({ statut, miseAJourLe: new Date().toISOString() });

    // ── Décrémentation du stock à la livraison ──────────────────────────────
    if (statut === 'livree') {
      const commandeDoc = await commandeRef.get();
      const commande = commandeDoc.data();

      const batch = db.batch();
      for (const article of (commande.articles || [])) {
        const prodRef = db.collection('produits').doc(article.produitId);
        const prodDoc = await prodRef.get();
        if (!prodDoc.exists) continue;

        const stockActuel = prodDoc.data().stock || 0;
        const nouveauStock = Math.max(0, stockActuel - article.quantite);
        const stockFaible = nouveauStock < 10;

        batch.update(prodRef, { stock: nouveauStock, stockFaible });
      }
      await batch.commit();
    }

    res.json({ message: `Statut mis à jour : ${statut}` });
  } catch (err) {
    console.error('Erreur mettreAJourStatut:', err);
    res.status(500).json({ message: 'Erreur serveur.' });
  }
};

/**
 * GET /api/commandes/admin/toutes
 * Toutes les commandes enrichies avec le nom du client (admin uniquement)
 */
const toutesLesCommandes = async (req, res) => {
  try {
    const { statut, dateDebut, dateFin } = req.query;
    let query = db.collection('commandes');

    if (statut) {
      query = query.where('statut', '==', statut);
    }

    const snapshot = await query.get();
    let commandes = snapshot.docs.map(doc => doc.data());

    // Filtrage par date côté serveur
    if (dateDebut) {
      commandes = commandes.filter(c => new Date(c.creeLe) >= new Date(dateDebut));
    }
    if (dateFin) {
      // Inclure tout le jour dateFin
      const fin = new Date(dateFin);
      fin.setHours(23, 59, 59, 999);
      commandes = commandes.filter(c => new Date(c.creeLe) <= fin);
    }

    // Tri par date décroissante
    commandes.sort((a, b) => new Date(b.creeLe) - new Date(a.creeLe));

    // Enrichir avec le nom du client
    const clientIds = [...new Set(commandes.map(c => c.clientId))];
    const userDocs = await Promise.all(
      clientIds.map(id => db.collection('utilisateurs').doc(id).get())
    );
    const userMap = {};
    userDocs.forEach(doc => {
      if (doc.exists) {
        const u = doc.data();
        userMap[doc.id] = { nom: u.nom, email: u.email, telephone: u.telephone || '' };
      }
    });

    commandes.forEach(c => {
      c.client = userMap[c.clientId] || { nom: c.clientId.substring(0, 8) + '...', email: '', telephone: '' };
    });

    res.json(commandes);
  } catch (err) {
    console.error('Erreur toutesLesCommandes:', err);
    res.status(500).json({ message: 'Erreur serveur.' });
  }
};

/**
 * DELETE /api/commandes/admin/historique
 * Supprimer toutes les commandes livrées et annulées (admin uniquement)
 */
const supprimerHistorique = async (req, res) => {
  try {
    const snapshot = await db.collection('commandes')
      .where('statut', 'in', ['livree', 'annulee'])
      .get();

    if (snapshot.empty) {
      return res.json({ message: 'Aucune commande terminée à supprimer.', supprimees: 0 });
    }

    // Firestore batch (max 500 par batch)
    const batches = [];
    let batch = db.batch();
    let count = 0;

    snapshot.docs.forEach(doc => {
      batch.delete(doc.ref);
      count++;
      if (count % 500 === 0) {
        batches.push(batch.commit());
        batch = db.batch();
      }
    });
    batches.push(batch.commit());
    await Promise.all(batches);

    res.json({ message: `${snapshot.docs.length} commande(s) supprimées.`, supprimees: snapshot.docs.length });
  } catch (err) {
    console.error('Erreur supprimerHistorique:', err);
    res.status(500).json({ message: 'Erreur serveur.' });
  }
};

/**
 * PUT /api/commandes/:id/annuler
 * Annuler une commande (client sur la sienne, livreur sur la sienne, admin partout)
 */
const annulerCommande = async (req, res) => {
  try {
    const { motifAnnulation } = req.body;
    const ref = db.collection('commandes').doc(req.params.id);
    const doc = await ref.get();

    if (!doc.exists) return res.status(404).json({ message: 'Commande introuvable.' });

    const commande = doc.data();

    // Vérifier les droits
    const role = req.utilisateur.role;
    if (role === 'client' && commande.clientId !== req.utilisateur.id) {
      return res.status(403).json({ message: 'Accès refusé.' });
    }
    if (role === 'livreur' && commande.livreurId !== req.utilisateur.id) {
      return res.status(403).json({ message: 'Vous n\'êtes pas assigné à cette commande.' });
    }
    if (commande.statut === 'livree') {
      return res.status(400).json({ message: 'Impossible d\'annuler une commande déjà livrée.' });
    }
    if (commande.statut === 'annulee') {
      return res.status(400).json({ message: 'Cette commande est déjà annulée.' });
    }

    // Si c'est le livreur qui annule → la commande revient dans le pool
    if (role === 'livreur') {
      await ref.update({
        statut: 'en_attente',
        livreurId: null,
        derniereAnnulationLivreur: {
          livreurId: req.utilisateur.id,
          motif: motifAnnulation || 'Non précisé',
          date: new Date().toISOString(),
        },
        miseAJourLe: new Date().toISOString(),
      });
      return res.json({ message: 'Livraison annulée. La commande est de nouveau disponible.' });
    }

    // Client ou admin → annulation définitive
    await ref.update({
      statut: 'annulee',
      motifAnnulation: motifAnnulation || 'Non précisé',
      miseAJourLe: new Date().toISOString(),
    });

    res.json({ message: 'Commande annulée.' });
  } catch (err) {
    console.error('Erreur annulerCommande:', err);
    res.status(500).json({ message: 'Erreur serveur.' });
  }
};

/**
 * POST /api/commandes/:id/noter
 * Le client note le livreur (cible='livreur') ou le livreur note le client (cible='client')
 */
const noterCommande = async (req, res) => {
  try {
    const { cible, note } = req.body;
    const role = req.utilisateur.role;

    if (!['livreur', 'client'].includes(cible)) {
      return res.status(400).json({ message: 'Cible invalide (livreur ou client).' });
    }
    const noteInt = parseInt(note, 10);
    if (isNaN(noteInt) || noteInt < 1 || noteInt > 5) {
      return res.status(400).json({ message: 'La note doit être entre 1 et 5.' });
    }

    const ref = db.collection('commandes').doc(req.params.id);
    const doc = await ref.get();
    if (!doc.exists) return res.status(404).json({ message: 'Commande introuvable.' });

    const commande = doc.data();
    if (commande.statut !== 'livree') {
      return res.status(400).json({ message: 'La commande doit être livrée pour être notée.' });
    }

    if (cible === 'livreur') {
      // Le client note le livreur
      if (role !== 'client') return res.status(403).json({ message: 'Accès refusé.' });
      if (commande.clientId !== req.utilisateur.id) return res.status(403).json({ message: 'Accès refusé.' });
      if (commande.noteLivreurParClient) {
        return res.status(400).json({ message: 'Vous avez déjà noté ce livreur.' });
      }
      if (!commande.livreurId) {
        return res.status(400).json({ message: 'Aucun livreur assigné.' });
      }

      await ref.update({ noteLivreurParClient: noteInt });

      // Mettre à jour la note moyenne du livreur
      const livreurRef = db.collection('utilisateurs').doc(commande.livreurId);
      const livreurDoc = await livreurRef.get();
      if (livreurDoc.exists) {
        const l = livreurDoc.data();
        const nbNotes = (l.nbNotes || 0) + 1;
        const noteMoyenne = (((l.noteMoyenne || 0) * (nbNotes - 1)) + noteInt) / nbNotes;
        await livreurRef.update({ noteMoyenne: Math.round(noteMoyenne * 10) / 10, nbNotes });
      }

    } else {
      // Le livreur note le client
      if (role !== 'livreur') return res.status(403).json({ message: 'Accès refusé.' });
      if (commande.livreurId !== req.utilisateur.id) return res.status(403).json({ message: 'Accès refusé.' });
      if (commande.noteClientParLivreur) {
        return res.status(400).json({ message: 'Vous avez déjà noté ce client.' });
      }

      await ref.update({ noteClientParLivreur: noteInt });

      // Mettre à jour la note moyenne du client
      const clientRef = db.collection('utilisateurs').doc(commande.clientId);
      const clientDoc = await clientRef.get();
      if (clientDoc.exists) {
        const c = clientDoc.data();
        const nbNotes = (c.nbNotes || 0) + 1;
        const noteMoyenne = (((c.noteMoyenne || 0) * (nbNotes - 1)) + noteInt) / nbNotes;
        await clientRef.update({ noteMoyenne: Math.round(noteMoyenne * 10) / 10, nbNotes });
      }
    }

    res.json({ message: 'Note enregistrée avec succès.' });
  } catch (err) {
    console.error('Erreur noterCommande:', err);
    res.status(500).json({ message: 'Erreur serveur.' });
  }
};

module.exports = {
  creerCommande,
  mesCommandes,
  getCommande,
  mettreAJourStatut,
  toutesLesCommandes,
  supprimerHistorique,
  annulerCommande,
  noterCommande,
};
