const { db } = require('../config/firebase');

/**
 * GET /api/produits
 * Liste tous les produits (avec filtre par catégorie optionnel)
 */
const listerProduits = async (req, res) => {
  try {
    const { categorie } = req.query;
    let query = db.collection('produits').where('disponible', '==', true);

    if (categorie) {
      query = query.where('categorie', '==', categorie);
    }

    const snapshot = await query.get();
    const produits = snapshot.docs.map(doc => doc.data());

    res.json(produits);
  } catch (err) {
    console.error('Erreur listerProduits:', err);
    res.status(500).json({ message: 'Erreur serveur.' });
  }
};

/**
 * GET /api/produits/:id
 * Détail d'un produit
 */
const getProduit = async (req, res) => {
  try {
    const doc = await db.collection('produits').doc(req.params.id).get();
    if (!doc.exists) return res.status(404).json({ message: 'Produit introuvable.' });
    res.json(doc.data());
  } catch (err) {
    res.status(500).json({ message: 'Erreur serveur.' });
  }
};

/**
 * POST /api/produits
 * Créer un produit (admin uniquement)
 */
const creerProduit = async (req, res) => {
  try {
    const { nom, description, prix, categorie, imageUrl, stock } = req.body;

    const ref = db.collection('produits').doc();
    const produit = {
      id: ref.id,
      nom,
      description,
      prix: parseFloat(prix),
      categorie,
      imageUrl: imageUrl || '',
      stock: parseInt(stock) || 0,
      disponible: true,
      creeLe: new Date().toISOString(),
    };

    await ref.set(produit);
    res.status(201).json({ message: 'Produit créé.', produit });
  } catch (err) {
    res.status(500).json({ message: 'Erreur serveur.' });
  }
};

/**
 * PUT /api/produits/:id
 * Modifier un produit (admin uniquement)
 */
const modifierProduit = async (req, res) => {
  try {
    await db.collection('produits').doc(req.params.id).update(req.body);
    res.json({ message: 'Produit mis à jour.' });
  } catch (err) {
    res.status(500).json({ message: 'Erreur serveur.' });
  }
};

/**
 * DELETE /api/produits/:id
 * Supprimer un produit (admin uniquement)
 */
const supprimerProduit = async (req, res) => {
  try {
    await db.collection('produits').doc(req.params.id).update({ disponible: false });
    res.json({ message: 'Produit désactivé.' });
  } catch (err) {
    res.status(500).json({ message: 'Erreur serveur.' });
  }
};

module.exports = { listerProduits, getProduit, creerProduit, modifierProduit, supprimerProduit };
