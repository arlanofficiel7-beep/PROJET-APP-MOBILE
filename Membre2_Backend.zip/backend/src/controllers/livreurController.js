const { db } = require('../config/firebase');

/**
 * GET /api/livreurs/tous
 * Liste tous les livreurs (admin uniquement)
 */
const tousLesLivreurs = async (req, res) => {
  try {
    const snapshot = await db.collection('utilisateurs')
      .where('role', '==', 'livreur')
      .get();

    const livreurs = snapshot.docs.map(doc => {
      const { motDePasse, ...data } = doc.data();
      return data;
    });
    res.json(livreurs);
  } catch (err) {
    console.error('Erreur tousLesLivreurs:', err.message);
    res.status(500).json({ message: 'Erreur serveur.' });
  }
};

/**
 * GET /api/livreurs/commandes
 * Commandes disponibles ou assignées au livreur connecté
 */
const commandesDisponibles = async (req, res) => {
  try {
    const snapshot = await db.collection('commandes').get();
    const commandes = snapshot.docs.map(doc => doc.data())
      .filter(c => !c.livreurId && ['en_attente', 'confirmee'].includes(c.statut));
    commandes.sort((a, b) => new Date(b.creeLe) - new Date(a.creeLe));

    // Enrichir avec le nom du client
    await _enrichirAvecClient(commandes);
    res.json(commandes);
  } catch (err) {
    console.error('Erreur commandesDisponibles:', err.message);
    res.status(500).json({ message: 'Erreur serveur.' });
  }
};

/**
 * GET /api/livreurs/mes-livraisons
 * Livraisons assignées au livreur connecté
 */
const mesLivraisons = async (req, res) => {
  try {
    const snapshot = await db.collection('commandes')
      .where('livreurId', '==', req.utilisateur.id)
      .get();

    const livraisons = snapshot.docs.map(doc => doc.data());
    livraisons.sort((a, b) => new Date(b.creeLe) - new Date(a.creeLe));

    // Enrichir avec le nom du client
    await _enrichirAvecClient(livraisons);
    res.json(livraisons);
  } catch (err) {
    console.error('Erreur mesLivraisons:', err.message);
    res.status(500).json({ message: 'Erreur serveur.' });
  }
};

/** Utilitaire : ajoute clientNom, clientNoteMoyenne, clientNbNotes à chaque commande */
async function _enrichirAvecClient(commandes) {
  if (!commandes.length) return;
  const clientIds = [...new Set(commandes.map(c => c.clientId))];
  const docs = await Promise.all(
    clientIds.map(id => db.collection('utilisateurs').doc(id).get())
  );
  const map = {};
  docs.forEach(d => {
    if (d.exists) {
      const data = d.data();
      map[d.id] = {
        nom: data.nom,
        noteMoyenne: data.noteMoyenne ?? null,
        nbNotes: data.nbNotes ?? 0,
      };
    }
  });
  commandes.forEach(c => {
    c.clientNom         = map[c.clientId]?.nom ?? '';
    c.clientNoteMoyenne = map[c.clientId]?.noteMoyenne ?? null;
    c.clientNbNotes     = map[c.clientId]?.nbNotes ?? 0;
  });
}

/**
 * PUT /api/livreurs/commandes/:id/accepter
 * Le livreur accepte une commande
 */
const accepterCommande = async (req, res) => {
  try {
    const commandeRef = db.collection('commandes').doc(req.params.id);
    const doc = await commandeRef.get();

    if (!doc.exists) return res.status(404).json({ message: 'Commande introuvable.' });

    const commande = doc.data();
    if (commande.livreurId) {
      return res.status(400).json({ message: 'Cette commande est déjà assignée.' });
    }

    await commandeRef.update({
      livreurId: req.utilisateur.id,
      statut: 'en_livraison',
      miseAJourLe: new Date().toISOString(),
    });

    res.json({ message: 'Commande acceptée.' });
  } catch (err) {
    res.status(500).json({ message: 'Erreur serveur.' });
  }
};

/**
 * PUT /api/livreurs/position
 * Le livreur envoie sa position GPS en temps réel
 */
const mettreAJourPosition = async (req, res) => {
  try {
    const { latitude, longitude, commandeId } = req.body;

    // Stocker la position dans Firestore (sera lue en temps réel par le client)
    await db.collection('positions_livreurs').doc(req.utilisateur.id).set({
      livreurId: req.utilisateur.id,
      commandeId,
      latitude,
      longitude,
      miseAJourLe: new Date().toISOString(),
    });

    res.json({ message: 'Position mise à jour.' });
  } catch (err) {
    res.status(500).json({ message: 'Erreur serveur.' });
  }
};

/**
 * GET /api/livreurs/position/:commandeId
 * Le client récupère la position du livreur
 */
const getPositionLivreur = async (req, res) => {
  try {
    const commandeDoc = await db.collection('commandes').doc(req.params.commandeId).get();
    if (!commandeDoc.exists) return res.status(404).json({ message: 'Commande introuvable.' });

    const { livreurId } = commandeDoc.data();
    if (!livreurId) return res.status(404).json({ message: 'Aucun livreur assigné.' });

    const positionDoc = await db.collection('positions_livreurs').doc(livreurId).get();
    if (!positionDoc.exists) return res.status(404).json({ message: 'Position non disponible.' });

    res.json(positionDoc.data());
  } catch (err) {
    res.status(500).json({ message: 'Erreur serveur.' });
  }
};

module.exports = { tousLesLivreurs, commandesDisponibles, mesLivraisons, accepterCommande, mettreAJourPosition, getPositionLivreur };
