require('dotenv').config();
const express = require('express');
const cors = require('cors');

const authRoutes    = require('./routes/auth');
const produitRoutes = require('./routes/produits');
const commandeRoutes = require('./routes/commandes');
const livreurRoutes = require('./routes/livreurs');
const adminRoutes   = require('./routes/admin');

const app = express();
const PORT = process.env.PORT || 3000;

// Middlewares globaux
app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));
app.options('*', cors());
app.use(express.json());

// Route de test
app.get('/', (req, res) => {
  res.json({ message: '🚚 API Livraison opérationnelle', version: '1.0.0' });
});

// Routes API
app.use('/api/auth', authRoutes);
app.use('/api/produits', produitRoutes);
app.use('/api/commandes', commandeRoutes);
app.use('/api/livreurs', livreurRoutes);
app.use('/api/admin', adminRoutes);

// Gestion des routes inexistantes
app.use((req, res) => {
  res.status(404).json({ message: 'Route introuvable.' });
});

// Démarrage du serveur
app.listen(PORT, () => {
  console.log(`✅ Serveur démarré sur http://localhost:${PORT}`);
});
