const jwt = require('jsonwebtoken');

/**
 * Middleware de vérification du token JWT
 * À utiliser sur toutes les routes protégées
 */
const verifierToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1]; // Format: "Bearer <token>"

  if (!token) {
    return res.status(401).json({ message: 'Token manquant. Accès refusé.' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.utilisateur = decoded; // { id, email, role }
    next();
  } catch (err) {
    return res.status(403).json({ message: 'Token invalide ou expiré.' });
  }
};

/**
 * Middleware de vérification du rôle admin
 */
const verifierAdmin = (req, res, next) => {
  if (req.utilisateur?.role !== 'admin') {
    return res.status(403).json({ message: 'Accès réservé aux administrateurs.' });
  }
  next();
};

/**
 * Middleware de vérification du rôle livreur
 */
const verifierLivreur = (req, res, next) => {
  if (req.utilisateur?.role !== 'livreur' && req.utilisateur?.role !== 'admin') {
    return res.status(403).json({ message: 'Accès réservé aux livreurs.' });
  }
  next();
};

module.exports = { verifierToken, verifierAdmin, verifierLivreur };
