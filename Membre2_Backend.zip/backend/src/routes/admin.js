const express = require('express');
const router  = express.Router();
const { listerUtilisateurs, modifierUtilisateur, supprimerUtilisateur, supprimerPhotoUtilisateur, getAnalytics, promouvoirAdmin, revoquerAdmin } = require('../controllers/adminController');
const { verifierToken, verifierAdmin } = require('../middlewares/auth');

router.get('/utilisateurs',              verifierToken, verifierAdmin, listerUtilisateurs);
router.put('/utilisateurs/:id',          verifierToken, verifierAdmin, modifierUtilisateur);
router.delete('/utilisateurs/:id/photo', verifierToken, verifierAdmin, supprimerPhotoUtilisateur);
router.delete('/utilisateurs/:id',       verifierToken, verifierAdmin, supprimerUtilisateur);
router.get('/analytics',                 verifierToken, verifierAdmin, getAnalytics);
router.post('/promouvoir',               verifierToken, verifierAdmin, promouvoirAdmin);
router.post('/revoquer',                 verifierToken, verifierAdmin, revoquerAdmin);

module.exports = router;
