const express = require('express');
const router = express.Router();
const {
  creerCommande,
  mesCommandes,
  getCommande,
  mettreAJourStatut,
  toutesLesCommandes,
  supprimerHistorique,
  annulerCommande,
  noterCommande,
} = require('../controllers/commandeController');
const { verifierToken, verifierAdmin, verifierLivreur } = require('../middlewares/auth');

router.post('/',                           verifierToken, creerCommande);
router.get('/mes-commandes',               verifierToken, mesCommandes);
router.get('/admin/toutes',                verifierToken, verifierAdmin, toutesLesCommandes);
router.delete('/admin/historique',         verifierToken, verifierAdmin, supprimerHistorique);
router.get('/:id',                         verifierToken, getCommande);
router.put('/:id/annuler',                 verifierToken, annulerCommande);
router.put('/:id/statut',                  verifierToken, verifierLivreur, mettreAJourStatut);
router.post('/:id/noter',                  verifierToken, noterCommande);

module.exports = router;
