const express = require('express');
const router = express.Router();
const { inscription, connexion, profil, mettreAJourProfil, envoyerOtp, verifierOtp } = require('../controllers/authController');
const { verifierToken } = require('../middlewares/auth');

router.post('/envoyer-otp',  envoyerOtp);
router.post('/verifier-otp', verifierOtp);
router.post('/register', inscription);
router.post('/login', connexion);
router.get('/profil', verifierToken, profil);
router.put('/profil', verifierToken, mettreAJourProfil);

module.exports = router;
