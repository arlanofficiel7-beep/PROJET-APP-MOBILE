const express = require('express');
const router = express.Router();
const { listerProduits, getProduit, creerProduit, modifierProduit, supprimerProduit } = require('../controllers/produitController');
const { verifierToken, verifierAdmin } = require('../middlewares/auth');

router.get('/', listerProduits);                                          // Public
router.get('/:id', getProduit);                                           // Public
router.post('/', verifierToken, verifierAdmin, creerProduit);             // Admin
router.put('/:id', verifierToken, verifierAdmin, modifierProduit);        // Admin
router.delete('/:id', verifierToken, verifierAdmin, supprimerProduit);    // Admin

module.exports = router;
