const express = require('express');
const router = express.Router();
const { tousLesLivreurs, commandesDisponibles, mesLivraisons, accepterCommande, mettreAJourPosition, getPositionLivreur } = require('../controllers/livreurController');
const { verifierToken, verifierAdmin, verifierLivreur } = require('../middlewares/auth');

router.get('/tous', verifierToken, verifierAdmin, tousLesLivreurs);
router.get('/commandes', verifierToken, verifierLivreur, commandesDisponibles);
router.get('/mes-livraisons', verifierToken, verifierLivreur, mesLivraisons);
router.put('/commandes/:id/accepter', verifierToken, verifierLivreur, accepterCommande);
router.put('/position', verifierToken, verifierLivreur, mettreAJourPosition);
router.get('/position/:commandeId', verifierToken, getPositionLivreur);

module.exports = router;
