package com.livraison.livraison_livreur

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
