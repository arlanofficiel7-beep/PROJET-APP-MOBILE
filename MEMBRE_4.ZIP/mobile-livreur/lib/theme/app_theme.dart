import 'package:flutter/material.dart';

// ── Palette livreur (Twitch Green Dark) ──────────────────────────────────────
const kLivGreen     = Color(0xFF00C853);
const kLivGreenDark = Color(0xFF00962E);
const kLivGreenGlow = Color(0x3300C853);
const kLivGreenLight= Color(0xFF69F0AE);
const kLivDark      = Color(0xFF0E0E10);
const kLivDarkCard  = Color(0xFF18181B);
const kLivDarkSurf  = Color(0xFF1F1F23);
const kLivWhite     = Color(0xFFEFEFF1);
const kLivMuted     = Color(0xFFADADB8);
const kLivBgLight   = Color(0xFFF0FFF4);
const kLivCardBg    = Color(0xFFFFFFFF);
