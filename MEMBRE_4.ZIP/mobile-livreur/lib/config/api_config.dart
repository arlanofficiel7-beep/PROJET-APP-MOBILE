class ApiConfig {
  static const String baseUrl = 'http://192.168.1.67:3000/api'; // IP locale PC
  static const String auth = '$baseUrl/auth';
  static const String livreurs = '$baseUrl/livreurs';
  static const String commandes = '$baseUrl/commandes';
}
