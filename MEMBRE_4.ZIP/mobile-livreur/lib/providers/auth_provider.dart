import 'package:flutter/material.dart';
import '../services/auth_service.dart';

class AuthProvider extends ChangeNotifier {
  final AuthService _service = AuthService();

  bool _estConnecte = false;
  Map<String, dynamic>? _utilisateur;
  bool _chargement = false;
  String? _erreur;

  bool get estConnecte => _estConnecte;
  Map<String, dynamic>? get utilisateur => _utilisateur;
  bool get chargement => _chargement;
  String? get erreur => _erreur;

  Future<void> verifierSession() async {
    _estConnecte = await _service.estConnecte();
    if (_estConnecte) {
      // Données fraîches déjà sauvegardées par estConnecte() → on les charge
      _utilisateur = await _service.getUtilisateur();
    }
    notifyListeners();
  }

  /// Tire le profil depuis le serveur et met à jour l'UI (appels admin inclus).
  Future<void> rafraichirDepuisServeur() async {
    final data = await _service.rafraichirProfil();
    if (data != null) {
      _utilisateur = _extraireUser(data);
      notifyListeners();
    }
  }

  Future<bool> connexion(String email, String motDePasse) async {
    _chargement = true;
    _erreur = null;
    notifyListeners();

    try {
      final data = await _service.connexion(email, motDePasse);
      if (data['token'] != null) {
        _estConnecte = true;
        _utilisateur = data['utilisateur'];
        _chargement = false;
        notifyListeners();
        return true;
      } else {
        _erreur = data['message'] ?? 'Erreur de connexion.';
        _chargement = false;
        notifyListeners();
        return false;
      }
    } catch (e) {
      _erreur = e.toString().replaceAll('Exception: ', '');
      _chargement = false;
      notifyListeners();
      return false;
    }
  }

  Future<String?> mettreAJourPhoto(String photoBase64) async {
    try {
      final data = await _service.mettreAJourProfil(photoBase64: photoBase64);
      if (data['utilisateur'] != null) {
        _utilisateur = _extraireUser(data['utilisateur']);
        notifyListeners();
        return null;
      }
      return data['message'] ?? 'Erreur inconnue.';
    } catch (e) {
      return 'Erreur réseau.';
    }
  }

  Future<String?> mettreAJourInfos({
    required String nom,
    required String telephone,
    String? motDePasseActuel,
    String? nouveauMotDePasse,
  }) async {
    try {
      final data = await _service.mettreAJourProfil(
        nom: nom,
        telephone: telephone,
        motDePasseActuel: motDePasseActuel,
        nouveauMotDePasse: nouveauMotDePasse,
      );
      if (data['utilisateur'] != null) {
        _utilisateur = _extraireUser(data['utilisateur']);
        notifyListeners();
        return null;
      }
      return data['message'] ?? 'Erreur inconnue.';
    } catch (e) {
      return 'Erreur réseau.';
    }
  }

  Map<String, dynamic> _extraireUser(Map<String, dynamic> user) => {
    'id': user['id'],
    'nom': user['nom'],
    'email': user['email'],
    'telephone': user['telephone'] ?? '',
    'role': user['role'],
    'photoBase64': user['photoBase64'],
    'noteMoyenne': user['noteMoyenne'],
    'nbNotes': user['nbNotes'] ?? 0,
  };

  Future<void> deconnexion() async {
    await _service.deconnexion();
    _estConnecte = false;
    _utilisateur = null;
    notifyListeners();
  }
}
