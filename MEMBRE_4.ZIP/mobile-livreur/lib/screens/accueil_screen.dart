import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../theme/app_theme.dart';
import 'commandes_disponibles_screen.dart';
import 'mes_livraisons_screen.dart';

class AccueilLivreurScreen extends StatefulWidget {
  const AccueilLivreurScreen({super.key});

  @override
  State<AccueilLivreurScreen> createState() => _AccueilLivreurScreenState();
}

class _AccueilLivreurScreenState extends State<AccueilLivreurScreen> {
  int _onglet = 0;

  final List<Widget> _ecrans = const [
    CommandesDisponiblesScreen(),
    MesLivraisonsScreen(),
    ProfilLivreurScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _ecrans[_onglet],
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          color: kLivDark,
          border: Border(top: BorderSide(color: kLivDarkSurf, width: 1)),
          boxShadow: [BoxShadow(color: Colors.black38, blurRadius: 12, offset: Offset(0, -2))],
        ),
        child: BottomNavigationBar(
          currentIndex: _onglet,
          onTap: (i) => setState(() => _onglet = i),
          backgroundColor: kLivDark,
          selectedItemColor: kLivGreen,
          unselectedItemColor: kLivMuted,
          selectedLabelStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 11),
          unselectedLabelStyle: const TextStyle(fontSize: 11),
          type: BottomNavigationBarType.fixed,
          items: const [
            BottomNavigationBarItem(
              icon: Icon(Icons.list_alt_rounded),
              label: 'Disponibles',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.delivery_dining_rounded),
              label: 'Mes livraisons',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.person_rounded),
              label: 'Profil',
            ),
          ],
        ),
      ),
    );
  }
}

// ── Écran Profil ─────────────────────────────────────────────────────────────

class ProfilLivreurScreen extends StatefulWidget {
  const ProfilLivreurScreen({super.key});

  @override
  State<ProfilLivreurScreen> createState() => _ProfilLivreurScreenState();
}

class _ProfilLivreurScreenState extends State<ProfilLivreurScreen> {
  bool _uploading = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) context.read<AuthProvider>().rafraichirDepuisServeur();
    });
  }

  Future<void> _ouvrirEdition() async {
    final auth = context.read<AuthProvider>();
    final user = auth.utilisateur;

    final nomCtrl       = TextEditingController(text: user?['nom'] ?? '');
    final telCtrl       = TextEditingController(text: user?['telephone'] ?? '');
    final ancienMdpCtrl = TextEditingController();
    final nvMdpCtrl     = TextEditingController();
    final nvMdpConfCtrl = TextEditingController();
    bool changerMdp = false;
    bool saving     = false;
    String? erreur;

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: kLivDarkCard,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setModalState) => Padding(
          padding: EdgeInsets.only(
            left: 24, right: 24, top: 24,
            bottom: MediaQuery.of(ctx).viewInsets.bottom + 32,
          ),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                // Handle
                Center(
                  child: Container(
                    width: 40, height: 4,
                    margin: const EdgeInsets.only(bottom: 20),
                    decoration: BoxDecoration(
                      color: kLivMuted.withOpacity(0.3),
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
                const Text(
                  'Modifier mon profil',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                    color: kLivWhite,
                  ),
                ),
                const SizedBox(height: 20),

                // Champ Nom
                _darkField(
                  controller: nomCtrl,
                  label: 'Nom complet',
                  icon: Icons.person_outline,
                ),
                const SizedBox(height: 14),

                // Champ Téléphone
                _darkField(
                  controller: telCtrl,
                  label: 'Téléphone',
                  icon: Icons.phone_outlined,
                  type: TextInputType.phone,
                ),
                const SizedBox(height: 14),

                // Checkbox changer mdp
                Row(
                  children: [
                    SizedBox(
                      width: 24,
                      height: 24,
                      child: Checkbox(
                        value: changerMdp,
                        activeColor: kLivGreen,
                        checkColor: Colors.white,
                        side: const BorderSide(color: kLivMuted),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(4)),
                        onChanged: (v) =>
                            setModalState(() => changerMdp = v ?? false),
                      ),
                    ),
                    const SizedBox(width: 10),
                    const Text('Changer le mot de passe',
                        style: TextStyle(color: kLivWhite)),
                  ],
                ),

                if (changerMdp) ...[
                  const SizedBox(height: 14),
                  _darkField(
                      controller: ancienMdpCtrl,
                      label: 'Mot de passe actuel',
                      icon: Icons.lock_outline,
                      obscure: true),
                  const SizedBox(height: 12),
                  _darkField(
                      controller: nvMdpCtrl,
                      label: 'Nouveau mot de passe',
                      icon: Icons.lock_reset,
                      obscure: true),
                  const SizedBox(height: 12),
                  _darkField(
                      controller: nvMdpConfCtrl,
                      label: 'Confirmer le nouveau mot de passe',
                      icon: Icons.lock_reset,
                      obscure: true),
                ],

                if (erreur != null) ...[
                  const SizedBox(height: 10),
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: Colors.red.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(erreur!,
                        style: const TextStyle(color: Colors.red, fontSize: 13)),
                  ),
                ],
                const SizedBox(height: 24),

                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: kLivGreen,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                    ),
                    onPressed: saving
                        ? null
                        : () async {
                            final nom = nomCtrl.text.trim();
                            if (nom.isEmpty) {
                              setModalState(() => erreur = 'Le nom est requis.');
                              return;
                            }
                            if (changerMdp) {
                              if (nvMdpCtrl.text != nvMdpConfCtrl.text) {
                                setModalState(() => erreur =
                                    'Les mots de passe ne correspondent pas.');
                                return;
                              }
                              if (nvMdpCtrl.text.length < 6) {
                                setModalState(() => erreur =
                                    'Mot de passe trop court (6 caractères min).');
                                return;
                              }
                            }
                            setModalState(() {
                              saving = true;
                              erreur = null;
                            });
                            final e = await auth.mettreAJourInfos(
                              nom: nom,
                              telephone: telCtrl.text.trim(),
                              motDePasseActuel:
                                  changerMdp ? ancienMdpCtrl.text : null,
                              nouveauMotDePasse:
                                  changerMdp ? nvMdpCtrl.text : null,
                            );
                            setModalState(() => saving = false);
                            if (e != null) {
                              setModalState(() => erreur = e);
                            } else {
                              if (ctx.mounted) Navigator.pop(ctx);
                              if (mounted) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text('Profil mis à jour ✅'),
                                    backgroundColor: kLivGreen,
                                  ),
                                );
                              }
                            }
                          },
                    child: saving
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                                strokeWidth: 2, color: Colors.white))
                        : const Text('Enregistrer',
                            style: TextStyle(fontWeight: FontWeight.w700)),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _darkField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    TextInputType type = TextInputType.text,
    bool obscure = false,
  }) {
    return TextField(
      controller: controller,
      keyboardType: type,
      obscureText: obscure,
      style: const TextStyle(color: kLivWhite),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: const TextStyle(color: kLivMuted, fontSize: 13),
        prefixIcon: Icon(icon, color: kLivGreen, size: 20),
        filled: true,
        fillColor: kLivDarkSurf,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: kLivGreen, width: 1.5),
        ),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      ),
    );
  }

  Future<void> _choisirPhoto() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(
      source: ImageSource.gallery,
      maxWidth: 400,
      maxHeight: 400,
      imageQuality: 75,
    );
    if (picked == null || !mounted) return;

    setState(() => _uploading = true);
    final bytes = await picked.readAsBytes();
    final base64Str = base64Encode(bytes);

    final auth = context.read<AuthProvider>();
    final erreur = await auth.mettreAJourPhoto(base64Str);
    if (!mounted) return;
    setState(() => _uploading = false);

    ScaffoldMessenger.of(context).showSnackBar(
      erreur != null
          ? SnackBar(content: Text(erreur), backgroundColor: Colors.red)
          : const SnackBar(
              content: Text('Photo mise à jour !'),
              backgroundColor: kLivGreen),
    );
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final user = auth.utilisateur;
    final photoB64 = user?['photoBase64'] as String?;
    Uint8List? photoBytes;
    if (photoB64 != null && photoB64.isNotEmpty) {
      try {
        photoBytes = base64Decode(photoB64);
      } catch (_) {}
    }

    return Scaffold(
      backgroundColor: kLivBgLight,
      appBar: AppBar(
        backgroundColor: kLivDark,
        elevation: 0,
        title: RichText(
          text: const TextSpan(children: [
            TextSpan(
              text: 'L',
              style: TextStyle(
                  color: kLivWhite,
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -1),
            ),
            TextSpan(
              text: 'X',
              style: TextStyle(
                  color: kLivGreen,
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -1),
            ),
            TextSpan(
              text: '  Mon profil',
              style: TextStyle(
                  color: kLivWhite, fontSize: 16, fontWeight: FontWeight.w600),
            ),
          ]),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // ── En-tête profil ──────────────────────────────────────────
            Container(
              width: double.infinity,
              color: kLivDark,
              padding: const EdgeInsets.fromLTRB(24, 0, 24, 32),
              child: Column(
                children: [
                  // Avatar
                  GestureDetector(
                    onTap: _uploading ? null : _choisirPhoto,
                    child: Stack(
                      children: [
                        Container(
                          width: 100,
                          height: 100,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: kLivGreen, width: 3),
                            color: kLivDarkCard,
                          ),
                          child: ClipOval(
                            child: photoBytes != null
                                ? Image.memory(photoBytes,
                                    fit: BoxFit.cover,
                                    width: 100,
                                    height: 100)
                                : const Icon(Icons.delivery_dining,
                                    size: 56, color: kLivGreen),
                          ),
                        ),
                        Positioned(
                          bottom: 0,
                          right: 0,
                          child: Container(
                            padding: const EdgeInsets.all(6),
                            decoration: const BoxDecoration(
                              color: kLivGreen,
                              shape: BoxShape.circle,
                            ),
                            child: _uploading
                                ? const SizedBox(
                                    width: 14,
                                    height: 14,
                                    child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                        color: Colors.white))
                                : const Icon(Icons.camera_alt,
                                    size: 14, color: Colors.white),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 6),
                  const Text('Appuyer pour changer',
                      style: TextStyle(fontSize: 11, color: kLivMuted)),
                  const SizedBox(height: 12),
                  Text(
                    user?['nom'] ?? '',
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                      color: kLivWhite,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    user?['email'] ?? '',
                    style: const TextStyle(color: kLivMuted, fontSize: 13),
                  ),
                  if ((user?['telephone'] ?? '').isNotEmpty) ...[
                    const SizedBox(height: 4),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.phone, size: 14, color: kLivMuted),
                        const SizedBox(width: 4),
                        Text(user?['telephone'] ?? '',
                            style: const TextStyle(
                                color: kLivMuted, fontSize: 13)),
                      ],
                    ),
                  ],
                  const SizedBox(height: 10),
                  // Note
                  if (user?['noteMoyenne'] != null)
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 6),
                      decoration: BoxDecoration(
                        color: Colors.amber.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                            color: Colors.amber.withOpacity(0.35)),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.star_rounded,
                              color: Colors.amber, size: 16),
                          const SizedBox(width: 6),
                          Text(
                            '${(user!['noteMoyenne'] as num).toStringAsFixed(1)} '
                            '(${user['nbNotes'] ?? 0} avis)',
                            style: const TextStyle(
                              fontWeight: FontWeight.w600,
                              color: Colors.amber,
                              fontSize: 13,
                            ),
                          ),
                        ],
                      ),
                    )
                  else
                    const Text('Pas encore de note',
                        style: TextStyle(color: kLivMuted, fontSize: 13)),
                  const SizedBox(height: 12),
                  // Badge rôle
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 6),
                    decoration: BoxDecoration(
                      color: kLivGreen.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(20),
                      border:
                          Border.all(color: kLivGreen.withOpacity(0.4)),
                    ),
                    child: const Text(
                      'Livreur',
                      style: TextStyle(
                          color: kLivGreen,
                          fontWeight: FontWeight.w700,
                          fontSize: 13),
                    ),
                  ),
                  const SizedBox(height: 16),
                  // Bouton édition
                  SizedBox(
                    width: double.infinity,
                    height: 44,
                    child: OutlinedButton.icon(
                      onPressed: _ouvrirEdition,
                      icon: const Icon(Icons.edit_rounded,
                          color: kLivGreen, size: 18),
                      label: const Text('Modifier mon profil',
                          style: TextStyle(
                              color: kLivGreen, fontWeight: FontWeight.w600)),
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: kLivGreen),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10)),
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // ── Informations ────────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Informations',
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w800,
                      color: kLivDark,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: kLivGreen.withOpacity(0.06),
                          blurRadius: 12,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        _ligneInfo(Icons.badge_outlined, 'Nom',
                            user?['nom'] ?? '—'),
                        _divider(),
                        _ligneInfo(Icons.email_outlined, 'Email',
                            user?['email'] ?? '—'),
                        _divider(),
                        _ligneInfo(
                          Icons.phone_outlined,
                          'Téléphone',
                          (user?['telephone'] ?? '').isNotEmpty
                              ? user!['telephone']
                              : 'Non renseigné',
                        ),
                        _divider(),
                        _ligneInfo(Icons.verified_user_outlined, 'Rôle',
                            'Livreur'),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),

                  // Bouton déconnexion
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: OutlinedButton.icon(
                      onPressed: () async {
                        await auth.deconnexion();
                        if (!context.mounted) return;
                        Navigator.pushNamedAndRemoveUntil(
                            context, '/login', (route) => false);
                      },
                      icon: const Icon(Icons.logout_rounded,
                          color: Colors.red, size: 20),
                      label: const Text('Se déconnecter',
                          style: TextStyle(
                              color: Colors.red, fontWeight: FontWeight.w600)),
                      style: OutlinedButton.styleFrom(
                        side: BorderSide(color: Colors.red.shade400),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _divider() => const Divider(height: 1, color: Color(0xFFF0FFF4));

  Widget _ligneInfo(IconData icone, String label, String valeur) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
      child: Row(
        children: [
          Icon(icone, size: 20, color: kLivGreen),
          const SizedBox(width: 14),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label,
                  style: const TextStyle(fontSize: 11, color: kLivMuted)),
              const SizedBox(height: 2),
              Text(valeur,
                  style: const TextStyle(
                      fontWeight: FontWeight.w600, color: kLivDark)),
            ],
          ),
        ],
      ),
    );
  }
}
