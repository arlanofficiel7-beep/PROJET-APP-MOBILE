import 'package:flutter/material.dart';
import '../models/commande.dart';
import '../services/livreur_service.dart';
import '../theme/app_theme.dart';
import 'livraison_active_screen.dart';

class MesLivraisonsScreen extends StatefulWidget {
  const MesLivraisonsScreen({super.key});

  @override
  State<MesLivraisonsScreen> createState() => _MesLivraisonsScreenState();
}

class _MesLivraisonsScreenState extends State<MesLivraisonsScreen> {
  final LivreurService _service = LivreurService();
  List<Commande> _livraisons = [];
  bool _chargement = true;

  @override
  void initState() {
    super.initState();
    _charger();
  }

  Future<void> _charger() async {
    if (!mounted) return;
    setState(() => _chargement = true);
    try {
      final livraisons = await _service.mesLivraisons();
      if (!mounted) return;
      setState(() {
        _livraisons = livraisons;
        _chargement = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _chargement = false);
    }
  }

  Color _couleurStatut(String statut) {
    switch (statut) {
      case 'livree':       return kLivGreen;
      case 'en_livraison': return const Color(0xFF1E88E5);
      default:             return kLivMuted;
    }
  }

  IconData _iconeStatut(String statut) {
    switch (statut) {
      case 'livree':       return Icons.check_circle_rounded;
      case 'en_livraison': return Icons.delivery_dining_rounded;
      default:             return Icons.receipt_long_rounded;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kLivBgLight,
      appBar: AppBar(
        backgroundColor: kLivDark,
        elevation: 0,
        title: RichText(
          text: const TextSpan(children: [
            TextSpan(
              text: 'L',
              style: TextStyle(
                  color: kLivWhite,
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -1),
            ),
            TextSpan(
              text: 'X',
              style: TextStyle(
                  color: kLivGreen,
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -1),
            ),
            TextSpan(
              text: '  Mes livraisons',
              style: TextStyle(
                  color: kLivWhite, fontSize: 15, fontWeight: FontWeight.w600),
            ),
          ]),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: kLivWhite),
            onPressed: _charger,
          ),
        ],
      ),
      body: _chargement
          ? const Center(child: CircularProgressIndicator(color: kLivGreen))
          : _livraisons.isEmpty
              ? Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 90,
                        height: 90,
                        decoration: BoxDecoration(
                          color: kLivGreen.withOpacity(0.08),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.history_rounded,
                            size: 48, color: kLivGreen),
                      ),
                      const SizedBox(height: 16),
                      const Text(
                        'Aucune livraison pour l\'instant',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          color: kLivDark,
                        ),
                      ),
                      const SizedBox(height: 6),
                      const Text('Vos livraisons apparaîtront ici',
                          style: TextStyle(color: kLivMuted, fontSize: 13)),
                    ],
                  ),
                )
              : RefreshIndicator(
                  color: kLivGreen,
                  onRefresh: _charger,
                  child: ListView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
                    itemCount: _livraisons.length,
                    itemBuilder: (_, i) {
                      final c = _livraisons[i];
                      final couleur = _couleurStatut(c.statut);
                      return Container(
                        margin: const EdgeInsets.only(bottom: 12),
                        decoration: BoxDecoration(
                          color: kLivCardBg,
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: [
                            BoxShadow(
                              color: kLivGreen.withOpacity(0.07),
                              blurRadius: 10,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: Column(
                          children: [
                            // Barre couleur statut
                            Container(
                              height: 4,
                              decoration: BoxDecoration(
                                color: couleur,
                                borderRadius: const BorderRadius.vertical(
                                    top: Radius.circular(16)),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(16),
                              child: Row(
                                children: [
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          '#${c.id.substring(0, 8).toUpperCase()}',
                                          style: const TextStyle(
                                            fontWeight: FontWeight.w800,
                                            fontSize: 14,
                                            color: kLivDark,
                                            letterSpacing: .5,
                                          ),
                                        ),
                                        if (c.clientNom.isNotEmpty) ...[
                                          const SizedBox(height: 4),
                                          Row(children: [
                                            const Icon(Icons.person_rounded,
                                                size: 13, color: kLivGreen),
                                            const SizedBox(width: 4),
                                            Text(c.clientNom,
                                                style: const TextStyle(
                                                  color: kLivDark,
                                                  fontWeight: FontWeight.w600,
                                                  fontSize: 12,
                                                )),
                                          ]),
                                        ],
                                        const SizedBox(height: 4),
                                        Row(children: [
                                          const Icon(Icons.location_on_outlined,
                                              size: 13, color: kLivMuted),
                                          const SizedBox(width: 4),
                                          Expanded(
                                            child: Text(
                                              c.adresseLivraison,
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                              style: const TextStyle(
                                                  color: kLivMuted,
                                                  fontSize: 12),
                                            ),
                                          ),
                                        ]),
                                        const SizedBox(height: 8),
                                        // Badge statut
                                        Container(
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 10, vertical: 4),
                                          decoration: BoxDecoration(
                                            color: couleur.withOpacity(0.12),
                                            borderRadius:
                                                BorderRadius.circular(12),
                                            border: Border.all(
                                                color:
                                                    couleur.withOpacity(0.3)),
                                          ),
                                          child: Row(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              Icon(_iconeStatut(c.statut),
                                                  size: 12, color: couleur),
                                              const SizedBox(width: 4),
                                              Text(
                                                c.statutLabel,
                                                style: TextStyle(
                                                    color: couleur,
                                                    fontWeight: FontWeight.w700,
                                                    fontSize: 11),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.end,
                                    children: [
                                      Text(
                                        '${c.total.toStringAsFixed(0)}',
                                        style: const TextStyle(
                                          fontWeight: FontWeight.w800,
                                          fontSize: 18,
                                          color: kLivGreen,
                                        ),
                                      ),
                                      const Text('FCFA',
                                          style: TextStyle(
                                              color: kLivMuted,
                                              fontSize: 10,
                                              fontWeight: FontWeight.w600)),
                                      if (c.statut == 'en_livraison') ...[
                                        const SizedBox(height: 8),
                                        SizedBox(
                                          height: 32,
                                          child: ElevatedButton(
                                            onPressed: () => Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder: (_) =>
                                                    LivraisonActiveScreen(
                                                  commandeId: c.id,
                                                  clientNom: c.clientNom,
                                                  adresseLivraison:
                                                      c.adresseLivraison,
                                                  latLivraison:
                                                      c.latLivraison,
                                                  lngLivraison:
                                                      c.lngLivraison,
                                                ),
                                              ),
                                            ).then((_) => _charger()),
                                            style: ElevatedButton.styleFrom(
                                              backgroundColor: kLivGreen,
                                              foregroundColor: Colors.white,
                                              padding:
                                                  const EdgeInsets.symmetric(
                                                      horizontal: 12),
                                              shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          8)),
                                              elevation: 0,
                                            ),
                                            child: const Text('Reprendre',
                                                style: TextStyle(
                                                    fontSize: 11,
                                                    fontWeight:
                                                        FontWeight.w700)),
                                          ),
                                        ),
                                      ],
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                   