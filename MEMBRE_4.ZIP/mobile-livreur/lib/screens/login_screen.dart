import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../theme/app_theme.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _emailCtrl = TextEditingController();
  final _mdpCtrl = TextEditingController();
  bool _mdpVisible = false;

  @override
  void dispose() {
    _emailCtrl.dispose();
    _mdpCtrl.dispose();
    super.dispose();
  }

  Future<void> _seConnecter() async {
    if (!_formKey.currentState!.validate()) return;
    final auth = context.read<AuthProvider>();
    final succes = await auth.connexion(_emailCtrl.text.trim(), _mdpCtrl.text);
    if (!mounted) return;
    if (succes) {
      Navigator.pushReplacementNamed(context, '/accueil');
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(auth.erreur ?? 'Erreur de connexion'),
          backgroundColor: Colors.red.shade700,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();

    return Scaffold(
      backgroundColor: kLivBgLight,
      body: Column(
        children: [
          // ── En-tête sombre ─────────────────────────────────────────────
          Container(
            width: double.infinity,
            color: kLivDark,
            padding: const EdgeInsets.fromLTRB(24, 72, 24, 40),
            child: Column(
              children: [
                // Logo LX
                RichText(
                  text: const TextSpan(children: [
                    TextSpan(
                      text: 'L',
                      style: TextStyle(
                        color: kLivWhite,
                        fontSize: 52,
                        fontWeight: FontWeight.w900,
                        letterSpacing: -3,
                      ),
                    ),
                    TextSpan(
                      text: 'X',
                      style: TextStyle(
                        color: kLivGreen,
                        fontSize: 52,
                        fontWeight: FontWeight.w900,
                        letterSpacing: -3,
                      ),
                    ),
                  ]),
                ),
                const SizedBox(height: 4),
                // Icône moto
                Container(
                  width: 64,
                  height: 64,
                  decoration: BoxDecoration(
                    color: kLivGreen.withOpacity(0.15),
                    shape: BoxShape.circle,
                    border: Border.all(color: kLivGreen.withOpacity(0.4), width: 1.5),
                  ),
                  child: const Icon(Icons.delivery_dining, size: 36, color: kLivGreen),
                ),
                const SizedBox(height: 16),
                const Text(
                  'Espace Livreur',
                  style: TextStyle(
                    color: kLivWhite,
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 6),
                const Text(
                  'Connectez-vous pour voir vos livraisons',
                  style: TextStyle(color: kLivMuted, fontSize: 14),
                ),
              ],
            ),
          ),

          // ── Formulaire ─────────────────────────────────────────────────
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(24, 32, 24, 32),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // Email
                    Container(
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(14),
                        boxShadow: [
                          BoxShadow(
                            color: kLivGreen.withOpacity(0.08),
                            blurRadius: 10,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: TextFormField(
                        controller: _emailCtrl,
                        keyboardType: TextInputType.emailAddress,
                        style: const TextStyle(color: kLivDark, fontWeight: FontWeight.w500),
                        decoration: InputDecoration(
                          labelText: 'Adresse email',
                          labelStyle: const TextStyle(color: kLivMuted),
                          prefixIcon: const Icon(Icons.email_outlined, color: kLivGreen, size: 20),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                            borderSide: BorderSide.none,
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                            borderSide: BorderSide.none,
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                            borderSide: const BorderSide(color: kLivGreen, width: 2),
                          ),
                          filled: true,
                          fillColor: Colors.white,
                          contentPadding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 16),
                        ),
                        validator: (v) =>
                            v!.contains('@') ? null : 'Email invalide',
                      ),
                    ),
                    const SizedBox(height: 16),

                    // Mot de passe
                    Container(
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(14),
                        boxShadow: [
                          BoxShadow(
                            color: kLivGreen.withOpacity(0.08),
                            blurRadius: 10,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: TextFormField(
                        controller: _mdpCtrl,
                        obscureText: !_mdpVisible,
                        style: const TextStyle(color: kLivDark, fontWeight: FontWeight.w500),
                        decoration: InputDecoration(
                          labelText: 'Mot de passe',
                          labelStyle: const TextStyle(color: kLivMuted),
                          prefixIcon: const Icon(Icons.lock_outlined, color: kLivGreen, size: 20),
                          suffixIcon: IconButton(
                            icon: Icon(
                              _mdpVisible ? Icons.visibility_off : Icons.visibility,
                              color: kLivMuted,
                              size: 20,
                            ),
                            onPressed: () =>
                                setState(() => _mdpVisible = !_mdpVisible),
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                            borderSide: BorderSide.none,
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                            borderSide: BorderSide.none,
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                            borderSide: const BorderSide(color: kLivGreen, width: 2),
                          ),
                          filled: true,
                          fillColor: Colors.white,
                          contentPadding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 16),
                        ),
                        validator: (v) =>
                            v!.length >= 6 ? null : 'Minimum 6 caractères',
                      ),
                    ),
                    const SizedBox(height: 32),

                    // Bouton connexion
                    SizedBox(
                      height: 54,
                      child: ElevatedButton(
                        onPressed: auth.chargement ? null : _seConnecter,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: kLivGreen,
                          disabledBackgroundColor: kLivGreen.withOpacity(0.4),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14)),
                          elevation: 0,
                        ),
                        child: auth.chargement
                            ? const SizedBox(
                                width: 22,
                                height: 22,
                                child: CircularProgressIndicator(
                                    color: Colors.white, strokeWidth: 2.5),
                              )
                            : const Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(Icons.login_rounded,
                                      color: Colors.white, size: 20),
                                  SizedBox(width: 10),
                                  Text(
                                    'Se connecter',
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w700,
                                      color: Colors.white,
                                    ),
                                  ),
                                ],
                              ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
