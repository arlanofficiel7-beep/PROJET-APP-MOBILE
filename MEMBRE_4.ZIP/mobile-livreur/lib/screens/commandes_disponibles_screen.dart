import 'package:flutter/material.dart';
import '../models/commande.dart';
import '../services/livreur_service.dart';
import '../theme/app_theme.dart';
import 'livraison_active_screen.dart';

class CommandesDisponiblesScreen extends StatefulWidget {
  const CommandesDisponiblesScreen({super.key});

  @override
  State<CommandesDisponiblesScreen> createState() =>
      _CommandesDisponiblesScreenState();
}

class _CommandesDisponiblesScreenState
    extends State<CommandesDisponiblesScreen> {
  final LivreurService _service = LivreurService();
  List<Commande> _commandes = [];
  bool _chargement = true;

  @override
  void initState() {
    super.initState();
    _charger();
  }

  Future<void> _charger() async {
    if (!mounted) return;
    setState(() => _chargement = true);
    try {
      final commandes = await _service.commandesDisponibles();
      if (!mounted) return;
      setState(() {
        _commandes = commandes;
        _chargement = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _chargement = false);
    }
  }

  Future<void> _accepter(Commande commande) async {
    try {
      await _service.accepterCommande(commande.id);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Commande acceptée ! 🚀'),
          backgroundColor: kLivGreen,
        ),
      );
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => LivraisonActiveScreen(
            commandeId: commande.id,
            clientNom: commande.clientNom,
            adresseLivraison: commande.adresseLivraison,
            latLivraison: commande.latLivraison,
            lngLivraison: commande.lngLivraison,
            audioBase64: commande.audioBase64,
            photoRepere: commande.photoRepere,
          ),
        ),
      ).then((_) => _charger());
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString()), backgroundColor: Colors.red),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kLivBgLight,
      appBar: AppBar(
        backgroundColor: kLivDark,
        elevation: 0,
        title: RichText(
          text: const TextSpan(children: [
            TextSpan(
              text: 'L',
              style: TextStyle(
                  color: kLivWhite,
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -1),
            ),
            TextSpan(
              text: 'X',
              style: TextStyle(
                  color: kLivGreen,
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -1),
            ),
            TextSpan(
              text: '  Disponibles',
              style: TextStyle(
                  color: kLivWhite, fontSize: 15, fontWeight: FontWeight.w600),
            ),
          ]),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: kLivWhite),
            onPressed: _charger,
          ),
        ],
      ),
      body: _chargement
          ? const Center(child: CircularProgressIndicator(color: kLivGreen))
          : _commandes.isEmpty
              ? Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 90,
                        height: 90,
                        decoration: BoxDecoration(
                          color: kLivGreen.withOpacity(0.08),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.inbox_rounded,
                            size: 48, color: kLivGreen),
                      ),
                      const SizedBox(height: 16),
                      const Text(
                        'Aucune commande disponible',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          color: kLivDark,
                        ),
                      ),
                      const SizedBox(height: 6),
                      const Text('Revenez dans quelques minutes',
                          style: TextStyle(color: kLivMuted, fontSize: 13)),
                      const SizedBox(height: 20),
                      OutlinedButton.icon(
                        onPressed: _charger,
                        icon: const Icon(Icons.refresh_rounded,
                            color: kLivGreen, size: 18),
                        label: const Text('Actualiser',
                            style: TextStyle(color: kLivGreen)),
                        style: OutlinedButton.styleFrom(
                          side: const BorderSide(color: kLivGreen),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10)),
                        ),
                      ),
                    ],
                  ),
                )
              : RefreshIndicator(
                  color: kLivGreen,
                  onRefresh: _charger,
                  child: ListView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
                    itemCount: _commandes.length,
                    itemBuilder: (_, i) {
                      final c = _commandes[i];
                      return Container(
                        margin: const EdgeInsets.only(bottom: 14),
                        decoration: BoxDecoration(
                          color: kLivCardBg,
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: [
                            BoxShadow(
                              color: kLivGreen.withOpacity(0.08),
                              blurRadius: 12,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: Column(
                          children: [
                            // Barre verte en haut
                            Container(
                              height: 4,
                              decoration: const BoxDecoration(
                                color: kLivGreen,
                                borderRadius: BorderRadius.vertical(
                                    top: Radius.circular(16)),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(16),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  // ID + total
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        '#${c.id.substring(0, 8).toUpperCase()}',
                                        style: const TextStyle(
                                          fontWeight: FontWeight.w800,
                                          fontSize: 14,
                                          color: kLivDark,
                                          letterSpacing: .5,
                                        ),
                                      ),
                                      Text(
                                        '${c.total.toStringAsFixed(0)} FCFA',
                                        style: const TextStyle(
                                          color: kLivGreen,
                                          fontWeight: FontWeight.w800,
                                          fontSize: 16,
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 8),

                                  // Client + note
                                  if (c.clientNom.isNotEmpty)
                                    Row(
                                      children: [
                                        const Icon(Icons.person_rounded,
                                            size: 15, color: kLivGreen),
                                        const SizedBox(width: 5),
                                        Text(
                                          c.clientNom,
                                          style: const TextStyle(
                                            color: kLivDark,
                                            fontWeight: FontWeight.w600,
                                            fontSize: 13,
                                          ),
                                        ),
                                        if (c.clientNoteMoyenne != null) ...[
                                          const SizedBox(width: 8),
                                          const Icon(Icons.star_rounded,
                                              color: Colors.amber, size: 14),
                                          const SizedBox(width: 2),
                                          Text(
                                            c.clientNoteMoyenne!
                                                .toStringAsFixed(1),
                                            style: const TextStyle(
                                                fontSize: 12,
                                                color: kLivMuted,
                                                fontWeight: FontWeight.w500),
                                          ),
                                          Text(
                                            ' (${c.clientNbNotes})',
                                            style: const TextStyle(
                                                fontSize: 11,
                                                color: kLivMuted),
                                          ),
                                        ],
                                      ],
                                    ),
                                  const SizedBox(height: 6),

                                  // Adresse
                                  Row(
                                    children: [
                                      const Icon(Icons.location_on_outlined,
                                          size: 15, color: kLivMuted),
                                      const SizedBox(width: 5),
                                      Expanded(
                                        child: Text(
                                          c.adresseLivraison,
                                          style: const TextStyle(
                                              color: kLivMuted, fontSize: 13),
                                          maxLines: 2,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 5),

                                  // Articles + badges médias
                                  Row(
                                    children: [
                                      const Icon(Icons.shopping_bag_outlined,
                                          size: 15, color: kLivMuted),
                                      const SizedBox(width: 5),
                                      Text(
                                        '${c.articles.length} article(s)',
                                        style: const TextStyle(
                                            color: kLivMuted, fontSize: 13),
                                      ),
                                      if (c.audioBase64 != null) ...[
                                        const SizedBox(width: 8),
                                        Container(
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 7, vertical: 2),
                                          decoration: BoxDecoration(
                                            color:
                                                kLivGreen.withOpacity(0.12),
                                            borderRadius:
                                                BorderRadius.circular(6),
                                          ),
                                          child: const Row(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              Icon(Icons.mic_rounded,
                                                  size: 12, color: kLivGreen),
                                              SizedBox(width: 3),
                                              Text('Audio',
                                                  style: TextStyle(
                                                      fontSize: 10,
                                                      color: kLivGreen,
                                                      fontWeight:
                                                          FontWeight.w600)),
                                            ],
                                          ),
                                        ),
                                      ],
                                      if (c.photoRepere != null) ...[
                                        const SizedBox(width: 6),
                                        Container(
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 7, vertical: 2),
                                          decoration: BoxDecoration(
                                            color: Colors.blue
                                                .withOpacity(0.12),
                                            borderRadius:
                                                BorderRadius.circular(6),
                                          ),
                                          child: const Row(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              Icon(Icons.photo_rounded,
                                                  size: 12,
                                                  color: Colors.blue),
                                              SizedBox(width: 3),
                                              Text('Photo',
                                                  style: TextStyle(
                                                      fontSize: 10,
                                                      color: Colors.blue,
                                                      fontWeight:
                                                          FontWeight.w600)),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ],
                                  ),
                                  const SizedBox(height: 14),

                                  // Bouton accepter
                                  SizedBox(
                                    width: double.infinity,
                                    height: 46,
                                    child: ElevatedButton.icon(
                                      onPressed: () => _accepter(c),
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: kLivGreen,
                                        foregroundColor: Colors.white,
                                        shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(10)),
                                        elevation: 0,
                                      ),
                                      icon: const Icon(
                                          Icons.check_circle_rounded,
                                          size: 18),
                                      label: const Text(
                                        'Accepter cette livraison',
                                        style: TextStyle(
                                            fontWeight: FontWeight.w700),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                   