import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:path_provider/path_provider.dart';
import 'package:geolocator/geolocator.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:http/http.dart' as http;
import '../services/livreur_service.dart';
import '../config/constantes.dart';
import '../theme/app_theme.dart';

bool _horsGabon(double lat, double lng) =>
    lat < -4 || lat > 4 || lng < 8 || lng > 15;

class LivraisonActiveScreen extends StatefulWidget {
  final String commandeId;
  final String clientNom;
  final String adresseLivraison;
  final double? latLivraison;
  final double? lngLivraison;
  final String? audioBase64;
  final String? photoRepere;

  const LivraisonActiveScreen({
    super.key,
    required this.commandeId,
    this.clientNom = '',
    this.adresseLivraison = '',
    this.latLivraison,
    this.lngLivraison,
    this.audioBase64,
    this.photoRepere,
  });

  @override
  State<LivraisonActiveScreen> createState() => _LivraisonActiveScreenState();
}

class _LivraisonActiveScreenState extends State<LivraisonActiveScreen> {
  final LivreurService _service = LivreurService();
  final MapController _mapController = MapController();
  final AudioPlayer _audioPlayer = AudioPlayer();

  LatLng _positionActuelle = Entrepot.position;
  bool _gpsAcquis = false;
  bool _enCours = false;
  bool _lectureAudio = false;
  Timer? _timer;

  List<LatLng> _routeComplete  = [];
  List<LatLng> _routeParcourue = [];
  List<LatLng> _routeRestante  = [];

  @override
  void initState() {
    super.initState();
    _envoyerPositionEntrepot();
    _demarrerGPS();
    _initialiserRoute();
  }

  // ── Route ────────────────────────────────────────────────────────────────

  void _initialiserRoute() {
    if (widget.latLivraison == null || widget.lngLivraison == null) return;
    final dest = LatLng(widget.latLivraison!, widget.lngLivraison!);
    setState(() {
      _routeComplete  = [Entrepot.position, dest];
      _routeRestante  = [Entrepot.position, dest];
      _routeParcourue = [];
    });
    _chargerOSRM(dest);
  }

  Future<void> _chargerOSRM(LatLng dest) async {
    try {
      final d = Entrepot.position;
      final url =
          'https://router.project-osrm.org/route/v1/driving/'
          '${d.longitude},${d.latitude};'
          '${dest.longitude},${dest.latitude}'
          '?overview=full&geometries=geojson';
      final r = await http.get(Uri.parse(url)).timeout(const Duration(seconds: 8));
      if (r.statusCode != 200) return;
      final data = jsonDecode(r.body);
      final coords = data['routes'][0]['geometry']['coordinates'] as List;
      final pts = coords
          .map<LatLng>((c) => LatLng(c[1].toDouble(), c[0].toDouble()))
          .toList();
      if (!mounted || pts.length < 2) return;
      setState(() {
        _routeComplete = pts;
        _routeRestante = List.from(pts);
        _routeParcourue = [];
      });
      _diviserRoute(_positionActuelle);
    } catch (_) {}
  }

  int _indexPlusProche(LatLng pos) {
    if (_routeComplete.isEmpty) return 0;
    double minD = double.infinity;
    int minI = 0;
    for (int i = 0; i < _routeComplete.length; i++) {
      final dx = _routeComplete[i].latitude  - pos.latitude;
      final dy = _routeComplete[i].longitude - pos.longitude;
      final d  = dx * dx + dy * dy;
      if (d < minD) { minD = d; minI = i; }
    }
    return minI;
  }

  void _diviserRoute(LatLng livreurPos) {
    if (_routeComplete.length < 2) return;
    final idx = _indexPlusProche(livreurPos);
    if (!mounted) return;
    setState(() {
      _routeParcourue = _routeComplete.sublist(0, idx + 1);
      _routeRestante  = _routeComplete.sublist(idx);
    });
  }

  // ── GPS ──────────────────────────────────────────────────────────────────

  Future<void> _envoyerPositionEntrepot() async {
    try {
      await _service.envoyerPosition(
          widget.commandeId, Entrepot.latitude, Entrepot.longitude);
    } catch (_) {}
  }

  Future<void> _demarrerGPS() async {
    LocationPermission p = await Geolocator.checkPermission();
    if (p == LocationPermission.denied) p = await Geolocator.requestPermission();
    if (p == LocationPermission.deniedForever) return;
    _mettreAJourPosition();
    _timer = Timer.periodic(
        const Duration(seconds: 10), (_) => _mettreAJourPosition());
  }

  Future<void> _mettreAJourPosition() async {
    try {
      final pos = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.high);
      if (!mounted) return;
      if (_horsGabon(pos.latitude, pos.longitude)) return;
      final nouvellePos = LatLng(pos.latitude, pos.longitude);
      setState(() { _positionActuelle = nouvellePos; _gpsAcquis = true; });
      _mapController.move(nouvellePos, _mapController.camera.zoom);
      _diviserRoute(nouvellePos);
      await _service.envoyerPosition(
          widget.commandeId, pos.latitude, pos.longitude);
    } catch (_) {}
  }

  // ── Actions ──────────────────────────────────────────────────────────────

  Future<void> _confirmerLivraison() async {
    setState(() => _enCours = true);
    try {
      await _service.marquerLivree(widget.commandeId);
      _timer?.cancel();
      if (!mounted) return;

      final note = await _afficherDialogNotation();
      if (note != null) {
        try {
          await _service.noterCommande(widget.commandeId, 'client', note);
        } catch (_) {}
      }

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Livraison confirmée ! ✅'),
          backgroundColor: kLivGreen));
      Navigator.pop(context);
    } catch (e) {
      setState(() => _enCours = false);
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString()), backgroundColor: Colors.red));
    }
  }

  Future<int?> _afficherDialogNotation() async {
    int stars = 0;
    return showDialog<int>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          backgroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: const Text('Notez votre client',
              style: TextStyle(fontWeight: FontWeight.w800, color: kLivDark)),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            if (widget.clientNom.isNotEmpty)
              Text(widget.clientNom,
                  style: const TextStyle(color: kLivMuted, fontSize: 14)),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(5, (i) => GestureDetector(
                onTap: () => setS(() => stars = i + 1),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: Icon(
                    i < stars ? Icons.star_rounded : Icons.star_outline_rounded,
                    color: Colors.amber, size: 44,
                  ),
                ),
              )),
            ),
            const SizedBox(height: 8),
            Text(
              stars == 0 ? 'Appuyez sur une étoile' :
              stars == 1 ? '😞 Très mauvais' :
              stars == 2 ? '😕 Mauvais' :
              stars == 3 ? '😐 Correct' :
              stars == 4 ? '😊 Bien' : '🤩 Excellent !',
              style: TextStyle(
                  color: stars > 0 ? kLivGreen : kLivMuted,
                  fontWeight: FontWeight.w500),
            ),
          ]),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, null),
              child: const Text('Passer', style: TextStyle(color: kLivMuted)),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                  backgroundColor: kLivGreen,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8))),
              onPressed: stars == 0 ? null : () => Navigator.pop(ctx, stars),
              child: const Text('Envoyer'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _annulerCommande() async {
    final raisons = [
      'Trop de temps d\'attente',
      'Adresse introuvable',
      'Client injoignable',
      'Problème de véhicule',
      'Autre',
    ];
    String? raison;
    final autreCtrl = TextEditingController();

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, set) => AlertDialog(
          backgroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: const Text('Annuler la livraison',
              style: TextStyle(fontWeight: FontWeight.w800, color: kLivDark)),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Motif de l\'annulation :',
                    style: TextStyle(
                        fontWeight: FontWeight.w600, color: kLivMuted)),
                const SizedBox(height: 8),
                ...raisons.map((r) => RadioListTile<String>(
                      value: r,
                      groupValue: raison,
                      dense: true,
                      activeColor: kLivGreen,
                      title: Text(r,
                          style: const TextStyle(
                              fontSize: 14, color: kLivDark)),
                      onChanged: (v) => set(() => raison = v),
                    )),
                if (raison == 'Autre') ...[
                  const SizedBox(height: 8),
                  TextField(
                    controller: autreCtrl,
                    maxLines: 2,
                    decoration: InputDecoration(
                      hintText: 'Précisez…',
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8)),
                      focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                          borderSide:
                              const BorderSide(color: kLivGreen)),
                      contentPadding: const EdgeInsets.all(10),
                    ),
                  ),
                ],
              ],
            ),
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('Retour',
                    style: TextStyle(color: kLivMuted))),
            TextButton(
              onPressed: raison == null
                  ? null
                  : () => Navigator.pop(ctx, true),
              child: const Text('Annuler la livraison',
                  style: TextStyle(
                      color: Colors.red, fontWeight: FontWeight.w700)),
            ),
          ],
        ),
      ),
    );

    if (confirmed != true || raison == null) return;
    final motif = raison == 'Autre'
        ? (autreCtrl.text.trim().isEmpty ? 'Autre' : autreCtrl.text.trim())
        : raison!;

    setState(() => _enCours = true);
    try {
      await _service.annulerCommande(widget.commandeId, motif);
      _timer?.cancel();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Commande annulée'),
          backgroundColor: Colors.orange));
      Navigator.pop(context);
    } catch (e) {
      setState(() => _enCours = false);
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString()), backgroundColor: Colors.red));
    }
  }

  void _zoom(double delta) {
    _mapController.move(
      _mapController.camera.center,
      _mapController.camera.zoom + delta,
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    _audioPlayer.dispose();
    super.dispose();
  }

  Future<void> _toggleAudio() async {
    if (widget.audioBase64 == null) return;
    if (_lectureAudio) {
      await _audioPlayer.stop();
      await _audioPlayer.release();
      if (mounted) setState(() => _lectureAudio = false);
    } else {
      final bytes = base64Decode(widget.audioBase64!);
      final dir  = await getTemporaryDirectory();
      final file = File('${dir.path}/instruction_livraison_play.m4a');
      await file.writeAsBytes(bytes);
      await _audioPlayer.release();
      await _audioPlayer.play(DeviceFileSource(file.path));
      if (mounted) setState(() => _lectureAudio = true);
      _audioPlayer.onPlayerComplete.listen((_) {
        if (mounted) setState(() => _lectureAudio = false);
      });
    }
  }

  // ── UI ───────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    final hasDestination =
        widget.latLivraison != null && widget.lngLivraison != null;
    final destination = hasDestination
        ? LatLng(widget.latLivraison!, widget.lngLivraison!)
        : null;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: kLivDark,
        elevation: 0,
        title: RichText(
          text: TextSpan(children: [
            const TextSpan(
              text: 'L',
              style: TextStyle(
                  color: kLivWhite,
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -1),
            ),
            const TextSpan(
              text: 'X',
              style: TextStyle(
                  color: kLivGreen,
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -1),
            ),
            TextSpan(
              text: '  #${widget.commandeId.substring(0, 8).toUpperCase()}',
              style: const TextStyle(
                  color: kLivWhite,
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  fontFamily: 'monospace'),
            ),
          ]),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.cancel_outlined, color: kLivMuted),
            tooltip: 'Annuler',
            onPressed: _enCours ? null : _annulerCommande,
          ),
        ],
      ),
      body: Column(
        children: [
          // ── Bandeau client + trajet ──────────────────────────────────────
          Container(
            width: double.infinity,
            color: kLivGreenDark,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  const Icon(Icons.person_rounded, color: kLivWhite, size: 15),
                  const SizedBox(width: 6),
                  Text(
                    widget.clientNom.isNotEmpty
                        ? 'Client : ${widget.clientNom}'
                        : 'Client : —',
                    style: const TextStyle(
                        color: kLivWhite,
                        fontWeight: FontWeight.w700,
                        fontSize: 14),
                  ),
                ]),
                const SizedBox(height: 3),
                Row(children: [
                  const Icon(Icons.warehouse_rounded,
                      color: kLivGreenLight, size: 13),
                  const SizedBox(width: 6),
                  const Text('Entrepôt',
                      style: TextStyle(color: kLivGreenLight, fontSize: 12)),
                  const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 6),
                    child: Icon(Icons.arrow_forward_rounded,
                        color: kLivGreenLight, size: 12),
                  ),
                  const Icon(Icons.location_on_rounded,
                      color: kLivGreenLight, size: 13),
                  const SizedBox(width: 4),
                  Expanded(
                    child: Text(
                      widget.adresseLivraison.isNotEmpty
                          ? widget.adresseLivraison
                          : '—',
                      style: const TextStyle(
                          color: kLivGreenLight, fontSize: 12),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ]),
              ],
            ),
          ),

          // ── Carte ────────────────────────────────────────────────────────
          Expanded(
            child: Stack(
              children: [
                FlutterMap(
                  mapController: _mapController,
                  options: MapOptions(
                    initialCenter: Entrepot.position,
                    initialZoom: 13,
                  ),
                  children: [
                    TileLayer(
                      urlTemplate:
                          'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                      userAgentPackageName:
                          'com.livraison.livraison_livreur',
                      errorTileCallback: (tile, error, stackTrace) {},
                    ),
                    // Tracé
                    PolylineLayer(polylines: [
                      if (_routeRestante.length >= 2)
                        Polyline(
                          points: _routeRestante,
                          color: kLivGreen.withOpacity(0.35),
                          strokeWidth: 5,
                        ),
                      if (_routeParcourue.length >= 2)
                        Polyline(
                          points: _routeParcourue,
                          color: kLivGreen,
                          strokeWidth: 5,
                        ),
                    ]),
                    // Marqueurs
                    MarkerLayer(markers: [
                      Marker(
                        point: Entrepot.position,
                        width: 44, height: 44,
                        child: _Pin(
                            color: kLivDark,
                            icon: Icons.warehouse_rounded),
                      ),
                      if (destination != null)
                        Marker(
                          point: destination,
                          width: 44, height: 44,
                          child: Tooltip(
                            message: widget.adresseLivraison,
                            child: _Pin(
                                color: kLivGreenDark,
                                icon: Icons.home_rounded),
                          ),
                        ),
                      Marker(
                        point: _positionActuelle,
                        width: 44, height: 44,
                        child: _Pin(
                            color: kLivGreen,
                            icon: Icons.delivery_dining_rounded),
                      ),
                    ]),
                  ],
                ),

                // Boutons zoom
                Positioned(
                  right: 12, bottom: 12,
                  child: Column(children: [
                    _ZoomButton(icon: Icons.add, onTap: () => _zoom(1)),
                    const SizedBox(height: 6),
                    _ZoomButton(icon: Icons.remove, onTap: () => _zoom(-1)),
                  ]),
                ),

                // Badge GPS
                Positioned(
                  top: 10, left: 10,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: _gpsAcquis ? kLivGreen : Colors.orange.shade700,
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: const [
                        BoxShadow(color: Colors.black26, blurRadius: 4)
                      ],
                    ),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      Icon(
                        _gpsAcquis
                            ? Icons.gps_fixed
                            : Icons.gps_not_fixed,
                        color: Colors.white, size: 13),
                      const SizedBox(width: 5),
                      Text(
                        _gpsAcquis ? 'GPS actif' : 'En attente GPS',
                        style: const TextStyle(
                            color: Colors.white, fontSize: 11)),
                    ]),
                  ),
                ),
              ],
            ),
          ),

          // ── Instructions du client (audio + photo) ────────────────────────
          if (widget.audioBase64 != null || widget.photoRepere != null)
            Container(
              margin: const EdgeInsets.fromLTRB(12, 10, 12, 0),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: kLivGreen.withOpacity(0.07),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: kLivGreen.withOpacity(0.3)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(children: [
                    Icon(Icons.record_voice_over_rounded,
                        color: kLivGreen, size: 16),
                    SizedBox(width: 6),
                    Text('Instructions du client',
                        style: TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 13,
                            color: kLivGreen)),
                  ]),
                  if (widget.audioBase64 != null) ...[
                    const SizedBox(height: 8),
                    Row(children: [
                      GestureDetector(
                        onTap: _toggleAudio,
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: _lectureAudio ? Colors.red : kLivGreen,
                            shape: BoxShape.circle,
                          ),
                          child: Icon(
                            _lectureAudio ? Icons.stop : Icons.play_arrow,
                            color: Colors.white, size: 22,
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          _lectureAudio
                              ? 'En cours de lecture...'
                              : 'Appuyez pour écouter les instructions',
                          style: TextStyle(
                            fontSize: 12,
                            color: _lectureAudio
                                ? Colors.red
                                : kLivMuted,
                            fontStyle: FontStyle.italic,
                          ),
                        ),
                      ),
                    ]),
                  ],
                  if (widget.photoRepere != null) ...[
                    const SizedBox(height: 8),
                    const Row(children: [
                      Icon(Icons.photo_camera_rounded,
                          color: Colors.blue, size: 14),
                      SizedBox(width: 4),
                      Text('Photo du repère :',
                          style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: kLivDark)),
                    ]),
                    const SizedBox(height: 6),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.memory(
                        base64Decode(widget.photoRepere!),
                        height: 130,
                        width: double.infinity,
                        fit: BoxFit.cover,
                      ),
                    ),
                  ],
                ],
              ),
            ),
          const SizedBox(height: 10),

          // ── Panneau bas ───────────────────────────────────────────────────
          Container(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
              boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 10)],
            ),
            child: Row(children: [
              // Bouton annuler
              OutlinedButton.icon(
                onPressed: _enCours ? null : _annulerCommande,
                icon: const Icon(Icons.cancel_outlined,
                    color: Colors.red, size: 18),
                label: const Text('Annuler',
                    style: TextStyle(
                        color: Colors.red, fontWeight: FontWeight.w600)),
                style: OutlinedButton.styleFrom(
                  side: BorderSide(color: Colors.red.shade400),
                  padding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 14),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                ),
              ),
              const SizedBox(width: 12),
              // Bouton livraison confirmée
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: _enCours ? null : _confirmerLivraison,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: kLivGreen,
                    disabledBackgroundColor: kLivGreen.withOpacity(0.4),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                    elevation: 0,
                  ),
                  icon: const Icon(Icons.check_circle_rounded,
                      color: Colors.white),
                  label: _enCours
                      ? const SizedBox(
                          width: 20, height: 20,
                          child: CircularProgressIndicator(
                              color: Colors.white, strokeWidth: 2))
                      : const Text('Confirmer la livraison',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 15,
                              fontWeight: FontWeight.w700)),
                ),
              ),
            ]),
          ),
        ],
      ),
    );
  }
}

// ── Widgets helpers ────────────────────────────────────────────────────────

class _Pin extends StatelessWidget {
  final Color color;
  final IconData icon;
  const _Pin({required this.color, required this.icon});

  @override
  Widget build(BuildContext context) => Container(
        decoration: BoxDecoration(
          color: color,
          shape: BoxShape.circle,
          border: Border.all(color: Colors.white, width: 2),
          boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 5)],
        ),
        child: Icon(icon, color: Colors.white, size: 22),
      );
}

class _ZoomButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _ZoomButton({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Container(
          width: 38, height: 38,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(8),
            boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 4)],
          ),
          child: Icon(icon, size: 22, color: kLivDark),
        ),
      );
}
