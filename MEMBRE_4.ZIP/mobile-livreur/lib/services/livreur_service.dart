import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config/api_config.dart';
import '../models/commande.dart';
import 'auth_service.dart';

class LivreurService {
  final AuthService _auth = AuthService();

  Future<Map<String, String>> _headers() async {
    final token = await _auth.getToken();
    return {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };
  }

  /// Commandes disponibles (confirmées, sans livreur)
  Future<List<Commande>> commandesDisponibles() async {
    final response = await http.get(
      Uri.parse('${ApiConfig.livreurs}/commandes'),
      headers: await _headers(),
    );
    if (response.statusCode == 200) {
      final List data = jsonDecode(response.body);
      return data.map((c) => Commande.fromJson(c)).toList();
    }
    throw Exception('Impossible de charger les commandes.');
  }

  /// Mes livraisons en cours
  Future<List<Commande>> mesLivraisons() async {
    final response = await http.get(
      Uri.parse('${ApiConfig.livreurs}/mes-livraisons'),
      headers: await _headers(),
    );
    if (response.statusCode == 200) {
      final List data = jsonDecode(response.body);
      return data.map((c) => Commande.fromJson(c)).toList();
    }
    throw Exception('Impossible de charger vos livraisons.');
  }

  /// Accepter une commande
  Future<void> accepterCommande(String commandeId) async {
    final response = await http.put(
      Uri.parse('${ApiConfig.livreurs}/commandes/$commandeId/accepter'),
      headers: await _headers(),
    );
    if (response.statusCode != 200) {
      final data = jsonDecode(response.body);
      throw Exception(data['message'] ?? 'Erreur.');
    }
  }

  /// Marquer une commande comme livrée
  Future<void> marquerLivree(String commandeId) async {
    final response = await http.put(
      Uri.parse('${ApiConfig.commandes}/$commandeId/statut'),
      headers: await _headers(),
      body: jsonEncode({'statut': 'livree'}),
    );
    if (response.statusCode != 200) {
      throw Exception('Impossible de mettre à jour le statut.');
    }
  }

  /// Annuler une commande avec un motif
  Future<void> annulerCommande(String commandeId, String motif) async {
    final response = await http.put(
      Uri.parse('${ApiConfig.commandes}/$commandeId/annuler'),
      headers: await _headers(),
      body: jsonEncode({'motifAnnulation': motif}),
    );
    if (response.statusCode != 200) {
      final data = jsonDecode(response.body);
      throw Exception(data['message'] ?? 'Impossible d\'annuler.');
    }
  }

  /// Soumettre une note pour la commande (cible='client')
  Future<void> noterCommande(String commandeId, String cible, int note) async {
    final response = await http.post(
      Uri.parse('${ApiConfig.commandes}/$commandeId/noter'),
      headers: await _headers(),
      body: jsonEncode({'cible': cible, 'note': note}),
    );
    if (response.statusCode != 200) {
      final data = jsonDecode(response.body);
      throw Exception(data['message'] ?? 'Erreur lors de la notation.');
    }
  }

  /// Envoyer la position GPS au serveur
  Future<void> envoyerPosition(String commandeId, double lat, double lng) async {
    await http.put(
      Uri.parse('${ApiConfig.livreurs}/position'),
      headers: await _headers(),
      body: jsonEncode({
        'commandeId': commandeId,
        'latitude': lat,
        'longitude': lng,
      }),
    );
  }
}
