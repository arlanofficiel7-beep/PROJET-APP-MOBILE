import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../config/api_config.dart';

class AuthService {
  static const _tokenKey = 'jwt_token';
  static const _userKey = 'user_data';

  Future<Map<String, dynamic>> connexion(String email, String motDePasse) async {
    final response = await http.post(
      Uri.parse('${ApiConfig.auth}/login'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'email': email, 'motDePasse': motDePasse}),
    );
    final data = jsonDecode(response.body);
    if (response.statusCode == 200) {
      // Vérifier que c'est bien un livreur
      if (data['utilisateur']['role'] != 'livreur') {
        throw Exception('Accès réservé aux livreurs.');
      }
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_tokenKey, data['token']);
      await prefs.setString(_userKey, jsonEncode(data['utilisateur']));
    }
    return data;
  }

  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_tokenKey);
  }

  Future<Map<String, dynamic>?> getUtilisateur() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getString(_userKey);
    if (data == null) return null;
    return jsonDecode(data);
  }

  /// Met à jour le profil : nom, téléphone, photo, et/ou mot de passe
  Future<Map<String, dynamic>> mettreAJourProfil({
    String? nom,
    String? telephone,
    String? photoBase64,
    String? motDePasseActuel,
    String? nouveauMotDePasse,
  }) async {
    final token = await getToken();
    final response = await http.put(
      Uri.parse('${ApiConfig.auth}/profil'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
      body: jsonEncode({
        if (nom != null) 'nom': nom,
        if (telephone != null) 'telephone': telephone,
        if (photoBase64 != null) 'photoBase64': photoBase64,
        if (motDePasseActuel != null) 'motDePasseActuel': motDePasseActuel,
        if (nouveauMotDePasse != null) 'nouveauMotDePasse': nouveauMotDePasse,
      }),
    );
    final data = jsonDecode(response.body);
    if (response.statusCode == 200) {
      final user = data['utilisateur'] as Map<String, dynamic>;
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_userKey, jsonEncode({
        'id': user['id'],
        'nom': user['nom'],
        'email': user['email'],
        'telephone': user['telephone'] ?? '',
        'role': user['role'],
        'photoBase64': user['photoBase64'],
        'noteMoyenne': user['noteMoyenne'],
        'nbNotes': user['nbNotes'] ?? 0,
      }));
    }
    return data;
  }

  Future<void> deconnexion() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_tokenKey);
    await prefs.remove(_userKey);
  }

  Future<bool> estConnecte() async {
    final token = await getToken();
    if (token == null) return false;

    try {
      final response = await http.get(
        Uri.parse('${ApiConfig.auth}/profil'),
        headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer $token'},
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['role'] == 'livreur') {
          // Sauvegarder les données fraîches (inclut les modifs admin)
          await _sauvegarderUtilisateur(data);
          return true;
        }
      }
      await deconnexion();
      return false;
    } catch (_) {
      return true; // Pas de réseau — confiance au token local
    }
  }

  /// Rafraîchit le profil depuis le serveur et met à jour le cache local.
  /// Retourne les données fraîches, ou null si hors ligne.
  Future<Map<String, dynamic>?> rafraichirProfil() async {
    final token = await getToken();
    if (token == null) return null;
    try {
      final response = await http.get(
        Uri.parse('${ApiConfig.auth}/profil'),
        headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer $token'},
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body) as Map<String, dynamic>;
        await _sauvegarderUtilisateur(data);
        return data;
      }
    } catch (_) {}
    return null;
  }

  Future<void> _sauvegarderUtilisateur(Map<String, dynamic> data) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_userKey, jsonEncode({
      'id': data['id'],
      'nom': data['nom'],
      'email': data['email'],
      'telephone': data['telephone'] ?? '',
      'role': data['role'],
      'photoBase64': data['photoBase64'],
      'noteMoyenne': data['noteMoyenne'],
      'nbNotes': data['nbNotes'] ?? 0,
    }));
  }
}
