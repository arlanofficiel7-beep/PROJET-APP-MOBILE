class ArticleCommande {
  final String produitId;
  final String nom;
  final double prix;
  final int quantite;

  ArticleCommande({
    required this.produitId,
    required this.nom,
    required this.prix,
    required this.quantite,
  });

  factory ArticleCommande.fromJson(Map<String, dynamic> json) => ArticleCommande(
    produitId: json['produitId'] ?? '',
    nom: json['nom'] ?? '',
    prix: (json['prix'] ?? 0).toDouble(),
    quantite: json['quantite'] ?? 1,
  );
}

class Commande {
  final String id;
  final String clientId;
  final String clientNom;       // nom du client (enrichi par le backend)
  final List<ArticleCommande> articles;
  final String adresseLivraison;
  final double? latLivraison;
  final double? lngLivraison;
  final double total;
  final String statut;
  final String? livreurId;
  final String creeLe;

  // Instructions vocales + photo repère du client
  final String? audioBase64;
  final String? photoRepere;

  // Notation : le livreur a-t-il déjà noté le client ?
  final int? noteClientParLivreur;
  // Note moyenne du client (enrichie par le backend)
  final double? clientNoteMoyenne;
  final int clientNbNotes;

  Commande({
    required this.id,
    required this.clientId,
    this.clientNom = '',
    required this.articles,
    required this.adresseLivraison,
    this.latLivraison,
    this.lngLivraison,
    required this.total,
    required this.statut,
    this.livreurId,
    required this.creeLe,
    this.audioBase64,
    this.photoRepere,
    this.noteClientParLivreur,
    this.clientNoteMoyenne,
    this.clientNbNotes = 0,
  });

  factory Commande.fromJson(Map<String, dynamic> json) => Commande(
    id: json['id'] ?? '',
    clientId: json['clientId'] ?? '',
    clientNom: json['clientNom'] ?? '',
    articles: (json['articles'] as List? ?? [])
        .map((a) => ArticleCommande.fromJson(a))
        .toList(),
    adresseLivraison: json['adresseLivraison'] ?? '',
    latLivraison: json['latLivraison'] != null
        ? (json['latLivraison'] as num).toDouble()
        : null,
    lngLivraison: json['lngLivraison'] != null
        ? (json['lngLivraison'] as num).toDouble()
        : null,
    total: (json['total'] ?? 0).toDouble(),
    statut: json['statut'] ?? 'en_attente',
    livreurId: json['livreurId'],
    creeLe: json['creeLe'] ?? '',
    audioBase64: json['audioBase64'] as String?,
    photoRepere: json['photoRepere'] as String?,
    noteClientParLivreur: json['noteClientParLivreur'] as int?,
    clientNoteMoyenne: json['clientNoteMoyenne'] != null
        ? (json['clientNoteMoyenne'] as num).toDouble()
        : null,
    clientNbNotes: (json['clientNbNotes'] as int?) ?? 0,
  );

  String get statutLabel {
    const labels = {
      'en_attente':     'En attente',
      'confirmee':      'Confirmée',
      'en_preparation': 'En préparation',
      'en_livraison':   'En livraison',
      'livree':         'Livrée ✅',
      'annulee':        'Annulée ❌',
    };
    return labels[statut] ?? statut;
  }
}
