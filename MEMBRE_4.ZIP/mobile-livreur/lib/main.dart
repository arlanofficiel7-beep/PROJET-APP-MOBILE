import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'providers/auth_provider.dart';
import 'screens/login_screen.dart';
import 'screens/accueil_screen.dart';

export 'screens/accueil_screen.dart';
export 'screens/login_screen.dart';

// ── Couleurs livreur (Twitch green + dark) ───────────────────────────────────
const kLivGreen     = Color(0xFF00C853);
const kLivGreenDark = Color(0xFF00962E);
const kLivDark      = Color(0xFF0E0E10);
const kLivDarkCard  = Color(0xFF18181B);
const kLivDarkSurf  = Color(0xFF1F1F23);
const kLivWhite     = Color(0xFFEFEFF1);
const kLivMuted     = Color(0xFFADADB8);
const kLivBgLight   = Color(0xFFF0FFF4);

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
  ));
  runApp(
    ChangeNotifierProvider(
      create: (_) => AuthProvider(),
      child: const MonApp(),
    ),
  );
}

class MonApp extends StatelessWidget {
  const MonApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Livreur Express',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: kLivGreen, primary: kLivGreen),
        scaffoldBackgroundColor: kLivBgLight,
        appBarTheme: const AppBarTheme(
          backgroundColor: kLivDark,
          foregroundColor: kLivWhite,
          elevation: 0,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: kLivGreen,
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            padding: const EdgeInsets.symmetric(vertical: 16),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: kLivDarkSurf.withOpacity(0.05),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: Colors.grey.shade300)),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: Colors.grey.shade300)),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: kLivGreen, width: 2)),
          prefixIconColor: kLivGreen,
        ),
      ),
      home: const SplashScreen(),
      routes: {
        '/login':   (_) => const LoginScreen(),
        '/accueil': (_) => const AccueilLivreurScreen(),
      },
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _verifier();
  }

  Future<void> _verifier() async {
    final auth = context.read<AuthProvider>();
    await Future.wait([
      auth.verifierSession(),
      Future.delayed(const Duration(seconds: 2)),
    ]);
    if (!mounted) return;
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => auth.estConnecte ? const AccueilLivreurScreen() : const LoginScreen(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(body: _LivreurSplash());
  }
}

// ─── Splash livreur (LX vert + moto) ─────────────────────────────────────────
class _LivreurSplash extends StatefulWidget {
  const _LivreurSplash();
  @override
  State<_LivreurSplash> createState() => _LivreurSplashState();
}

class _LivreurSplashState extends State<_LivreurSplash> with TickerProviderStateMixin {
  late final AnimationController _wheelCtrl;
  late final AnimationController _fadeCtrl;
  late final AnimationController _dotsCtrl;

  @override
  void initState() {
    super.initState();
    _wheelCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..repeat();
    _fadeCtrl  = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..forward();
    _dotsCtrl  = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200))..repeat();
  }

  @override
  void dispose() {
    _wheelCtrl.dispose();
    _fadeCtrl.dispose();
    _dotsCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox.expand(
      child: Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF001A08), kLivDark],
        ),
      ),
      child: FadeTransition(
        opacity: CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Logo LX vert
            Stack(
              alignment: Alignment.center,
              children: [
                Container(
                  width: 160, height: 100,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: [BoxShadow(color: kLivGreen.withOpacity(0.35), blurRadius: 60, spreadRadius: 20)],
                  ),
                ),
                RichText(
                  text: const TextSpan(children: [
                    TextSpan(text: 'L', style: TextStyle(
                        color: kLivWhite, fontSize: 86, fontWeight: FontWeight.w900, letterSpacing: -4, height: 1)),
                    TextSpan(text: 'X', style: TextStyle(
                        color: kLivGreen, fontSize: 86, fontWeight: FontWeight.w900, letterSpacing: -4, height: 1)),
                  ]),
                ),
              ],
            ),
            const SizedBox(height: 10),
            const Text('ESPACE LIVREUR',
              style: TextStyle(color: kLivMuted, fontSize: 12, fontWeight: FontWeight.w600, letterSpacing: 4)),
            const SizedBox(height: 52),

            // Moto (roues vertes)
            AnimatedBuilder(
              animation: _wheelCtrl,
              builder: (_, __) => SizedBox(
                width: 240, height: 110,
                child: CustomPaint(
                  painter: _MotoGreenPainter(wheelAngle: _wheelCtrl.value * 2 * math.pi),
                ),
              ),
            ),
            const SizedBox(height: 48),

            // Points verts
            AnimatedBuilder(
              animation: _dotsCtrl,
              builder: (_, __) => Row(
                mainAxisSize: MainAxisSize.min,
                children: List.generate(3, (i) {
                  final phase = (_dotsCtrl.value - i * 0.25).clamp(0.0, 1.0);
                  final opacity = math.sin(phase * math.pi).clamp(0.2, 1.0);
                  return Container(
                    margin: const EdgeInsets.symmetric(horizontal: 5),
                    width: 8, height: 8,
                    decoration: BoxDecoration(
                      color: kLivGreen.withOpacity(opacity),
                      shape: BoxShape.circle,
                    ),
                  );
                }),
              ),
            ),
          ],
        ),
      ),
    ));
  }
}

// Peintre moto version verte pour le livreur
class _MotoGreenPainter extends CustomPainter {
  final double wheelAngle;
  _MotoGreenPainter({required this.wheelAngle});

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final wr = w * 0.165;
    final rearX = w * 0.235;
    final frtX  = w * 0.765;
    final axleY = h * 0.80;

    final bodyPaint = Paint()
      ..shader = LinearGradient(
        colors: [kLivGreen, kLivGreenDark],
        begin: Alignment.topLeft, end: Alignment.bottomRight,
      ).createShader(Rect.fromLTWH(rearX, 0, frtX - rearX, axleY));

    final body = Path();
    body.moveTo(rearX + wr * 0.45, axleY - wr * 0.85);
    body.quadraticBezierTo(rearX + (frtX - rearX) * 0.28, axleY - wr * 1.58,
        rearX + (frtX - rearX) * 0.50, axleY - wr * 1.45);
    body.lineTo(frtX - wr * 0.48, axleY - wr * 1.05);
    body.lineTo(frtX - wr * 0.22, axleY - wr * 0.30);
    body.lineTo(frtX - wr * 0.35, axleY - wr * 0.05);
    body.lineTo(rearX + wr * 0.35, axleY - wr * 0.05);
    body.close();
    canvas.drawPath(body, bodyPaint);

    final saddle = Path();
    saddle.moveTo(rearX + wr * 0.45, axleY - wr * 0.85);
    saddle.quadraticBezierTo(rearX + (frtX - rearX) * 0.22, axleY - wr * 1.65,
        rearX + (frtX - rearX) * 0.50, axleY - wr * 1.48);
    saddle.lineTo(rearX + (frtX - rearX) * 0.44, axleY - wr * 1.26);
    saddle.quadraticBezierTo(rearX + (frtX - rearX) * 0.20, axleY - wr * 1.15,
        rearX + wr * 0.50, axleY - wr * 0.92);
    saddle.close();
    canvas.drawPath(saddle, Paint()..color = kLivDarkSurf);

    final hp = Paint()..color = const Color(0xFF69F0AE)..strokeWidth = 3.2
      ..strokeCap = StrokeCap.round..style = PaintingStyle.stroke;
    canvas.drawLine(Offset(frtX - wr * 0.48, axleY - wr * 1.05),
        Offset(frtX - wr * 0.15, axleY - wr * 1.42), hp);
    canvas.drawLine(Offset(frtX - wr * 0.05, axleY - wr * 1.35),
        Offset(frtX - wr * 0.28, axleY - wr * 1.48), hp);

    canvas.drawLine(Offset(rearX + wr * 0.10, axleY - wr * 0.22),
        Offset(rearX - wr * 0.30, axleY - wr * 0.22),
        Paint()..color = const Color(0xFF69F0AE)..strokeWidth = 4.5
          ..strokeCap = StrokeCap.round..style = PaintingStyle.stroke);

    _drawWheel(canvas, Offset(rearX, axleY), wr);
    _drawWheel(canvas, Offset(frtX, axleY), wr);
  }

  void _drawWheel(Canvas canvas, Offset c, double r) {
    canvas.drawCircle(c, r, Paint()..color = const Color(0xFF111111));
    canvas.drawCircle(c, r * 0.72, Paint()..color = kLivDarkCard);
    canvas.drawCircle(c, r, Paint()..color = kLivGreen..style = PaintingStyle.stroke..strokeWidth = 3.5);
    canvas.drawCircle(c, r * 0.72,
        Paint()..color = const Color(0xFF69F0AE).withOpacity(0.4)..style = PaintingStyle.stroke..strokeWidth = 1.5);

    final sp = Paint()..color = const Color(0xFF69F0AE)..strokeWidth = 1.8
      ..strokeCap = StrokeCap.round..style = PaintingStyle.stroke;
    for (int i = 0; i < 8; i++) {
      final a = wheelAngle + (i * math.pi / 4);
      canvas.drawLine(
        Offset(c.dx + math.cos(a) * r * 0.14, c.dy + math.sin(a) * r * 0.14),
        Offset(c.dx + math.cos(a) * r * 0.68, c.dy + math.sin(a) * r * 0.68),
        sp,
      );
    }
    canvas.drawCircle(c, r * 0.17, Paint()..color = kLivGreen);
    canvas.drawCircle(c, r * 0.08, Paint()..color = const Color(0xFF69F0AE));
  }

  @override
  bool shouldRepaint(_MotoGreenPainter old) => old.wheelAngle != wheelAngle;
}

